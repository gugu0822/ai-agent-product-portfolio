---
name: forum-scraper
description: 论坛爬虫工具链。用多种方法爬取论坛/社区帖子，寻找潜在客户或目标信息。支持直接爬取（requests+BeautifulSoup）、DuckDuckGo搜索（crawl4ai-skill）、浏览器自动化（xbrowser）、WebFetch四种方式。适用于被屏蔽网站、动态页面、需要登录的论坛等场景。触发词：论坛爬虫、爬取论坛、scrape forum、找帖子、爬帖子、forum scraping。
version: 1.0.0
---

# 论坛爬虫工具链

## 工具选择决策树

按优先级选择爬取方式：

1. **直接爬取**（requests + BeautifulSoup）→ 首选，速度最快
   - 适用：网站不屏蔽VM、静态HTML页面
   - 依赖：`pip install requests beautifulsoup4`
   - 示例脚本：`xineurope_scraper.py`、`asiaxpat_scraper.py`

2. **DuckDuckGo搜索**（crawl4ai-skill）→ 网站被屏蔽时的备选
   - 适用：网站屏蔽VM IP、只需要标题和摘要、不需要详情页
   - 命令：`crawl4ai-skill search "site:目标域名 关键字" --num-results 10`
   - 注意：Windows下输出是GBK编码，需按gbk读取
   - 示例：huaren.us用此方式

3. **WebFetch** → 需要提取页面内容但不需要交互
   - 适用：能正常访问的网站，需要提取正文/摘要
   - 限制：部分网站无法访问

4. **浏览器自动化**（xbrowser技能）→ 需要JS渲染或交互
   - 适用：动态加载页面、需要点击/滚动、需要登录
   - 最慢但最强大

## 工作流程

### Step 1: 确定目标网站和关键字
- 了解用户要找什么类型的帖子/用户
- 确定搜索关键字（中英文、同义词、缩写）
- 多个关键字分别搜索，结果合并去重

### Step 2: 试探网站可访问性
```python
import requests
try:
    r = requests.get("https://目标网站.com", timeout=10,
        headers={"User-Agent": "Mozilla/5.0 ..."})
    print(f"状态: {r.status_code}")
except Exception as e:
    print(f"不可访问: {e}")
    # 切换到crawl4ai-skill DuckDuckGo搜索
```

### Step 3: 分析网站结构
- 找到搜索API或搜索页面URL格式
- 找到帖子列表页和详情页的HTML结构
- 确定分页方式（page参数、AJAX、无限滚动）

### Step 4: 编写/运行爬虫
- 能直接访问 → 写Python脚本（requests + BS4）
- 被屏蔽 → 用crawl4ai-skill search
- 动态页面 → 用xbrowser

### Step 5: 数据清洗和输出
- 去重（按URL或帖子ID）
- 时间过滤（默认只保留最近3个月）
- 相关性过滤（关键字匹配过滤无关帖子）
- 输出CSV（utf-8-sig编码，Excel兼容）

## 输出CSV标准字段

```
title, category, author, date_published, description, url
```

注意：不包含公司、地点、WhatsApp、邮箱、电话、价格字段（用户要求）。

## Windows编码注意事项

- 运行Python脚本前设置：`set PYTHONIOENCODING=utf-8`
- crawl4ai-skill输出在Windows下是GBK编码
- CSV输出用`utf-8-sig`编码（Excel兼容）
- subprocess读取用`errors='replace'`或先写文件再按gbk读取

## 已有爬虫脚本

### xineurope_scraper.py（新欧洲跳蚤市场）
- 直接爬取，支持关键字搜索和首页浏览
- 解析AJAX API返回的HTML片段
- 提取联系人、微信、邮箱、工作地点等
- 用法：`py -3 xineurope_scraper.py --keyword "招聘" --max-pages 5`

### asiaxpat_scraper.py（亚洲外籍人士论坛）
- 通过search.json API搜索
- 支持forums/classifieds/jobs等分类
- 标签过滤（?tags[]=general）
- 时间过滤（filter_recent_posts方法）
- 用法：`py -3 asiaxpat_scraper.py --keyword "学中文" --recent 3`

### huaren.us（北美华人网）
- VM无法直接访问，使用crawl4ai-skill DuckDuckGo搜索
- 搜索命令：`crawl4ai-skill search "site:huaren.us 中文 网课" --num-results 10`
- 帖子URL格式：`https://huaren.us/showtopic.html?topicid=XXXXX`
- topicid越大越新

## 创建新爬虫的模板

```python
"""
[网站名] 论坛爬虫
"""
import requests, re, json, time, csv, os
from bs4 import BeautifulSoup
from datetime import datetime, timedelta

class ForumScraper:
    BASE_URL = "https://example.com"
    HEADERS = {"User-Agent": "Mozilla/5.0 ..."}
    
    def __init__(self, delay=2.0):
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self.delay = delay
    
    def search(self, keyword, max_pages=5):
        """按关键字搜索"""
        # 实现搜索逻辑
        pass
    
    def parse_list(self, html):
        """解析列表页"""
        soup = BeautifulSoup(html, "html.parser")
        items = []
        # 实现解析逻辑
        return items
    
    def parse_detail(self, html):
        """解析详情页"""
        soup = BeautifulSoup(html, "html.parser")
        info = {}
        # 实现解析逻辑
        return info

def export_csv(results, filepath):
    """导出CSV（标准字段）"""
    with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, 
            fieldnames=['title','category','author','date_published','description','url'])
        writer.writeheader()
        for r in results:
            writer.writerow(r)
```

## 常见问题

- **网站屏蔽VM**：用crawl4ai-skill的DuckDuckGo搜索，或xbrowser
- **编码乱码**：Windows下设置PYTHONIOENCODING=utf-8，crawl4ai输出按gbk读
- **动态加载**：用xbrowser技能（Chrome自动化）
- **需要登录**：用xbrowser手动登录后爬取，或cookie注入
- **反爬限速**：增加delay间隔，使用随机User-Agent
