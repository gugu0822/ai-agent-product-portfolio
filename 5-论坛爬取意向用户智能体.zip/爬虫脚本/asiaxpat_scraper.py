"""
Asiaxpat 论坛/分类信息爬虫 (hongkong.asiaxpat.com)
功能：按关键字搜索帖子，提取用户/联系人信息
支持：Forums、Classifieds、Jobs、Properties、Directory、Articles
用法：py -3 asiaxpat_scraper.py --keyword "学中文" [--type forums] [--max-results 20] [--output results.json]
"""

import requests
import re
import json
import time
import argparse
import sys
from bs4 import BeautifulSoup
from dataclasses import dataclass, field, asdict
from typing import Optional
from datetime import datetime


@dataclass
class SearchResult:
    """搜索结果条目"""
    title: str = ""
    snippet: str = ""
    url: str = ""
    category: str = ""           # 来源分组：forums/classifieds/jobs/properties/directory/articles
    author: str = ""             # 作者/发布者
    date_published: str = ""     # 发布日期
    description: str = ""        # 详细描述（正文）
    contact_whatsapp: str = ""   # WhatsApp号码
    contact_email: str = ""      # 邮箱
    contact_phone: str = ""      # 电话
    company: str = ""            # 公司名（招聘类）
    location: str = ""           # 地点（招聘类）
    salary: str = ""             # 薪资（招聘类）
    price: str = ""              # 价格（二手类）
    image_url: str = ""          # 图片URL
    comment_count: int = 0       # 评论数（论坛类）
    upvotes: int = 0             # 点赞数


class AsiaxpatScraper:
    BASE_URL = "https://hongkong.asiaxpat.com"
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
        "Accept-Encoding": "gzip, deflate, br",
    }

    # JSON-LD @type 到 category 的映射
    TYPE_MAP = {
        "DiscussionForumPosting": "forums",
        "Product": "classifieds",
        "JobPosting": "jobs",
        "RealEstateListing": "properties",
    }

    def __init__(self, delay: float = 2.0):
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self.delay = delay

    def _get(self, url: str, params: dict = None) -> Optional[requests.Response]:
        """带重试和延迟的GET请求"""
        for attempt in range(3):
            try:
                time.sleep(self.delay)
                r = self.session.get(url, params=params, timeout=15)
                if r.status_code == 200:
                    return r
                elif r.status_code == 429:
                    wait = int(r.headers.get("Retry-After", 10))
                    print(f"  被限速，等待 {wait}s ...")
                    time.sleep(wait)
                elif r.status_code == 403:
                    print(f"  403 Forbidden (可能被Cloudflare拦截)，等待后重试...")
                    time.sleep(5)
                else:
                    print(f"  HTTP {r.status_code}，重试 {attempt+1}/3")
            except requests.exceptions.RequestException as e:
                print(f"  请求异常: {e}，重试 {attempt+1}/3")
                time.sleep(3)
        return None

    def search(self, keyword: str, type_filter: str = None, max_results: int = 20) -> list:
        """
        按关键字搜索（通过 search.json API）
        type_filter: forums/classifieds/jobs/properties/directory/articles（None=全部）
        注意：API不支持分页（page>=2会被Cloudflare拦截），每次搜索返回固定数量结果
        """
        print(f"搜索关键字: {keyword}" + (f"，类型: {type_filter}" if type_filter else ""))
        all_results = []

        r = self._get(self.BASE_URL + "/search.json", params={"q": keyword})
        if not r:
            print("搜索请求失败")
            return []

        try:
            data = r.json()
        except json.JSONDecodeError:
            print("JSON解析失败")
            return []

        groups = data.get("groups", [])
        for group in groups:
            group_key = group.get("key", "")
            group_label = group.get("label", "")

            # 类型过滤
            if type_filter and group_key != type_filter:
                continue

            results = group.get("results", [])
            print(f"  [{group_label}] 找到 {len(results)} 条")

            for item in results:
                sr = SearchResult()
                sr.title = item.get("title", "")
                sr.snippet = item.get("snippet", "")
                sr.url = self.BASE_URL + item.get("url", "")
                sr.category = group_key
                all_results.append(sr)

        print(f"\n共找到 {len(all_results)} 条结果")

        # 限制数量
        if max_results and len(all_results) > max_results:
            all_results = all_results[:max_results]
            print(f"截取前 {max_results} 条")

        # 获取详情页
        if all_results:
            print(f"\n正在获取详情页...")
            for i, sr in enumerate(all_results):
                if sr.url:
                    print(f"  [{i+1}/{len(all_results)}] {sr.title[:50]}...")
                    r = self._get(sr.url)
                    if r:
                        self._parse_detail_page(r.text, sr)
                        all_results[i] = sr

        return all_results

    def _parse_detail_page(self, html: str, sr: SearchResult):
        """解析详情页，提取结构化信息"""
        soup = BeautifulSoup(html, "html.parser")

        # 1. 优先从 JSON-LD 提取结构化数据
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                data = json.loads(script.string)
                schema_type = data.get("@type", "")

                if schema_type == "DiscussionForumPosting":
                    sr.description = data.get("text", "")
                    sr.author = data.get("author", {}).get("name", "")
                    sr.date_published = data.get("datePublished", "")[:10]
                    sr.comment_count = data.get("commentCount", 0)
                elif schema_type == "JobPosting":
                    sr.description = BeautifulSoup(data.get("description", ""), "html.parser").get_text(strip=True)
                    sr.date_published = data.get("datePosted", "")
                    sr.company = data.get("hiringOrganization", {}).get("name", "")
                    sr.location = data.get("jobLocation", {}).get("address", {}).get("addressLocality", "")
                    emp_types = data.get("employmentType", [])
                    if emp_types:
                        sr.salary = ", ".join(emp_types)
                elif schema_type == "Product":
                    sr.description = data.get("description", "")
                    sr.image_url = data.get("image", "")
                    offers = data.get("offers", {})
                    if offers:
                        price = offers.get("price", "")
                        currency = offers.get("priceCurrency", "")
                        if price:
                            sr.price = f"{price} {currency}".strip()
                    sr.category = data.get("category", sr.category)
            except (json.JSONDecodeError, AttributeError):
                continue

        # 2. 从 HTML 补充作者信息（如果 JSON-LD 没有）
        if not sr.author:
            # 论坛帖子：作者名在 span.font-bold.text-ink-navy 中
            author_el = soup.find("span", class_="font-bold")
            if author_el:
                text = author_el.get_text(strip=True)
                # 排除非作者名（如图片数量"+6"、价格等）
                if text and not text.startswith("+") and not text.startswith("$") and not any(c.isdigit() for c in text[:3]):
                    sr.author = text
            # 分类/房产：从 "Listing Owner" 区域提取（label和value在不同div中）
            if not sr.author:
                for el in soup.find_all(string=lambda t: t and "Listing Owner" in t):
                    label_div = el.find_parent("div")
                    if label_div:
                        value_div = label_div.find_next_sibling("div")
                        if value_div:
                            owner_name = value_div.get_text(strip=True)
                            if owner_name:
                                sr.author = owner_name
                                break
            # 从 "Contact Email/Phone" 区域提取被遮蔽的联系方式
            for el in soup.find_all(string=lambda t: t and "Contact Email" in t):
                container = el.parent.parent if el.parent else None
                if container:
                    ct = container.get_text(strip=True)
                    em = re.search(r"[a-zA-Z0-9]\*+@[a-zA-Z0-9.-]+\.[a-zA-Z]+", ct)
                    if em and not sr.contact_email:
                        sr.contact_email = em.group(0) + " (masked)"
            for el in soup.find_all(string=lambda t: t and "Contact Phone" in t):
                container = el.parent.parent if el.parent else None
                if container:
                    ct = container.get_text(strip=True)
                    pm = re.search(r"\*+\d+", ct)
                    if pm and not sr.contact_phone:
                        sr.contact_phone = pm.group(0) + " (masked)"

        # 3. 从 HTML 提取正文（如果 JSON-LD 没有）
        if not sr.description:
            trix = soup.find(class_="trix-content")
            if trix:
                sr.description = trix.get_text(strip=True)

        # 4. 提取联系方式（仅在主要内容区域，排除页脚等全局元素）
        main_content = soup.find("main") or soup.find("article")
        if main_content:
            # Remove footer from search scope if present
            for footer in main_content.find_all("footer"):
                footer.decompose()
            search_scope = main_content
        else:
            search_scope = soup
        # 正文文本也仅取主要内容范围
        fallback_text = sr.description + " " + sr.snippet
        content_text = search_scope.get_text() if search_scope else fallback_text
        self._extract_contacts(search_scope, content_text, sr)

        # 5. 提取点赞数
        upvote_btn = soup.find(attrs={"data-controller": "upvote"})
        if upvote_btn:
            m = re.search(r"(\d+)", upvote_btn.get_text())
            if m:
                sr.upvotes = int(m.group(1))

    def _extract_contacts(self, soup: BeautifulSoup, text: str, sr: SearchResult):
        """从页面和文本中提取联系方式"""
        # WhatsApp
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if "wa.me/" in href:
                sr.contact_whatsapp = href.split("wa.me/")[-1].split("?")[0]
            elif "whatsapp" in href.lower():
                m = re.search(r"(\d{8,15})", href)
                if m:
                    sr.contact_whatsapp = m.group(1)

        # 从文本中找 WhatsApp
        if not sr.contact_whatsapp:
            m = re.search(r"(?:whatsapp|wa\.me|WhatsApp)[：:\s/]*(\+?\d{8,15})", text, re.IGNORECASE)
            if m:
                sr.contact_whatsapp = m.group(1)

        # 邮箱
        m = re.search(r"[a-zA-Z0-9.+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
        if m:
            sr.contact_email = m.group(0)

        # 也从 mailto 链接找
        if not sr.contact_email:
            for a in soup.find_all("a", href=True):
                if a["href"].startswith("mailto:"):
                    sr.contact_email = a["href"].replace("mailto:", "").split("?")[0]
                    break

        # 电话（香港号码格式：+852-XXXX-XXXX 或 XXXX-XXXX）
        if not sr.contact_phone:
            # 从文本中找电话
            m = re.search(r"(?:tel|phone|电话|致電|联系)[：:\s]*(\+?\d[\d\s\-]{7,20})", text, re.IGNORECASE)
            if m:
                sr.contact_phone = re.sub(r"\s+", " ", m.group(1)).strip()

    def search_multi(self, keywords: list, type_filter: str = None, max_results: int = 20) -> list:
        """
        使用多个关键字搜索，结果按URL去重合并。
        每个关键字最多返回 max_results 条结果。
        """
        print(f"多关键字搜索: {keywords}")
        all_results = []
        seen_urls = set()

        for kw in keywords:
            print(f"\n--- 搜索关键字: {kw} ---")
            kw_results = self.search(keyword=kw, type_filter=type_filter, max_results=max_results)
            for item in kw_results:
                if item.url not in seen_urls:
                    seen_urls.add(item.url)
                    all_results.append(item)
            print(f"  去重后累计: {len(all_results)} 条")

        print(f"\n多关键字搜索完成，共 {len(all_results)} 条不重复结果")
        return all_results

    def browse_forums(self, max_pages: int = 1) -> list:
        """浏览论坛最新帖子（非搜索）"""
        print(f"浏览论坛最新帖子...")
        all_results = []

        for page in range(1, max_pages + 1):
            url = self.BASE_URL + "/forums"
            params = {"page": page} if page > 1 else {}
            print(f"  获取第 {page} 页...")
            r = self._get(url, params=params)
            if not r:
                break

            soup = BeautifulSoup(r.text, "html.parser")
            # 论坛列表页中的帖子链接
            found = 0
            for a in soup.find_all("a", href=True):
                href = a["href"]
                if href.startswith("/forums/") and "/forums/" == href[:8] and len(href) > 8:
                    sr = SearchResult()
                    sr.title = a.get_text(strip=True)
                    sr.url = self.BASE_URL + href
                    sr.category = "forums"
                    if sr.title and sr.url not in [r.url for r in all_results]:
                        all_results.append(sr)
                        found += 1

            print(f"  第 {page} 页: {found} 条帖子")
            if found == 0:
                break

        print(f"\n共找到 {len(all_results)} 条帖子")
        return all_results

    def browse_tag(self, tag: str, max_pages: int = 3) -> list:
        """
        浏览特定论坛标签的帖子
        tag: 标签名，如 'general', 'lifestyle', 'property'
        """
        print(f"浏览论坛标签: {tag}")
        all_results = []

        for page in range(1, max_pages + 1):
            url = self.BASE_URL + "/forums"
            params = {"tags[]": tag}
            if page > 1:
                params["page"] = page
            print(f"  获取第 {page} 页...")
            r = self._get(url, params=params)
            if not r:
                break

            soup = BeautifulSoup(r.text, "html.parser")

            # 查找帖子链接
            found = 0
            for a in soup.find_all("a", href=True):
                href = a["href"]
                # 匹配论坛帖子链接: /forums/some-post-title
                if href.startswith("/forums/") and len(href) > 8 and "?" not in href and "=" not in href:
                    title = a.get_text(strip=True)
                    if title and len(title) > 5:
                        sr = SearchResult()
                        sr.title = title
                        sr.url = self.BASE_URL + href
                        sr.category = f"forums/{tag}"
                        if sr.url not in [r.url for r in all_results]:
                            all_results.append(sr)
                            found += 1

            print(f"  第 {page} 页: {found} 条帖子")
            if found == 0:
                break

        print(f"标签 {tag} 共找到 {len(all_results)} 条帖子")
        return all_results

    def search_categories(self, keywords: list, categories: list = None, max_per_category: int = 3) -> list:
        """
        在指定论坛标签中搜索关键字
        keywords: 搜索关键字列表
        categories: 论坛标签列表，如 ['general', 'lifestyle']
        max_per_category: 每个标签最大浏览页数
        """
        if categories is None:
            categories = ['general']

        print(f"在标签 {categories} 中搜索关键字: {keywords}")
        all_posts = []
        seen_urls = set()

        # 1. 先浏览每个标签的帖子列表
        for cat in categories:
            print(f"\n=== 浏览标签: {cat} ===")
            cat_posts = self.browse_tag(cat, max_pages=max_per_category)

            # 2. 获取每个帖子的详情
            for i, post in enumerate(cat_posts):
                print(f"  [{i+1}/{len(cat_posts)}] 获取详情: {post.title[:50]}...")
                r = self._get(post.url)
                if r:
                    self._parse_detail_page(r.text, post)

                    # 3. 检查帖子标题或内容是否包含关键字
                    text_to_check = (post.title + " " + post.description + " " + post.snippet).lower()
                    matched = False
                    for kw in keywords:
                        if kw.lower() in text_to_check:
                            matched = True
                            break

                    if matched and post.url not in seen_urls:
                        seen_urls.add(post.url)
                        all_posts.append(post)
                        print(f"    ✓ 匹配关键字")

        # 4. 也用API搜索forum_posts类型，扩大覆盖
        print(f"\n=== API搜索 forum_posts ===")
        for kw in keywords:
            print(f"\n--- API搜索: {kw} ---")
            api_results = self.search(keyword=kw, type_filter="forum_posts", max_results=20)
            for item in api_results:
                if item.url not in seen_urls:
                    seen_urls.add(item.url)
                    all_posts.append(item)

        print(f"\n搜索完成，共找到 {len(all_posts)} 条匹配帖子")
        return all_posts

    def export_csv(self, results: list, output_path: str):
        """导出结果为CSV格式"""
        import csv

        if not results:
            print("没有结果可导出")
            return

        # CSV列名（移除不需要的字段）
        fieldnames = [
            'title', 'category', 'author', 'date_published',
            'description', 'url'
        ]

        with open(output_path, 'w', encoding='utf-8-sig', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for item in results:
                writer.writerow({
                    'title': item.title,
                    'category': item.category,
                    'author': item.author,
                    'date_published': item.date_published,
                    'description': item.description[:500] if item.description else "",
                    'url': item.url
                })

        print(f"已导出 {len(results)} 条结果到 {output_path}")

    def filter_recent_posts(self, results: list, months: int = 3) -> list:
        """过滤只保留最近N个月的帖子"""
        from datetime import datetime, timedelta

        cutoff_date = datetime.now() - timedelta(days=months * 30)
        filtered = []

        for item in results:
            if item.date_published:
                try:
                    # 尝试解析日期 (格式: YYYY-MM-DD)
                    post_date = datetime.strptime(item.date_published[:10], "%Y-%m-%d")
                    if post_date >= cutoff_date:
                        filtered.append(item)
                    else:
                        print(f"  跳过旧帖子: {item.title[:40]}... ({item.date_published})")
                except ValueError:
                    # 日期格式不对，保留该帖子
                    filtered.append(item)
            else:
                # 没有日期信息，保留该帖子
                filtered.append(item)

        print(f"过滤后保留 {len(filtered)}/{len(results)} 条最近{months}个月的帖子")
        return filtered


def main():
    parser = argparse.ArgumentParser(description="Asiaxpat 论坛/分类信息爬虫")
    parser.add_argument("--keyword", "-k", type=str, help="搜索关键字（单个）")
    parser.add_argument("--keywords", type=str, nargs="+", help="多个搜索关键字，用空格分隔，结果自动去重合并")
    parser.add_argument("--type", "-t", type=str, default=None,
                        choices=["forum_posts", "classifieds", "job_listings", "properties", "domestic_helpers", "directories", "articles"],
                        help="过滤结果类型 (默认全部)")
    parser.add_argument("--max-results", type=int, default=20, help="每个关键字最大结果数 (默认20)")
    parser.add_argument("--delay", type=float, default=2.0, help="请求间隔秒数 (默认2)")
    parser.add_argument("--output", "-o", type=str, default=None, help="输出JSON文件路径")
    parser.add_argument("--browse", action="store_true", help="浏览论坛最新帖子（而非搜索）")
    parser.add_argument("--categories", type=str, nargs="+", help="限定论坛分类（如 education general），浏览帖子后按关键字过滤")
    parser.add_argument("--csv", type=str, default=None, help="同时导出CSV到指定路径")
    parser.add_argument("--max-pages", type=int, default=3, help="每个分类最大浏览页数 (默认3)")
    parser.add_argument("--recent", action="store_true", help="只保留最近3个月的帖子")

    args = parser.parse_args()

    scraper = AsiaxpatScraper(delay=args.delay)

    if args.categories:
        # 分类浏览+关键字过滤模式
        keywords = args.keywords or args.keyword and [args.keyword] or ["Chinese"]
        results = scraper.search_categories(keywords=keywords, categories=args.categories, max_per_category=args.max_pages)
        kw_label = "+".join(keywords)
    elif args.browse:
        results = scraper.browse_forums()
        kw_label = "BROWSE"
    elif args.keywords:
        results = scraper.search_multi(keywords=args.keywords, type_filter=args.type, max_results=args.max_results)
        kw_label = "+".join(args.keywords)
    elif args.keyword:
        results = scraper.search(keyword=args.keyword, type_filter=args.type, max_results=args.max_results)
        kw_label = args.keyword
    else:
        print("请指定 --keyword 单个关键字、--keywords 多个关键字、--categories 指定分类、或 --browse 浏览最新帖子")
        sys.exit(1)

    # 过滤最近3个月的帖子
    if args.recent:
        results = scraper.filter_recent_posts(results, months=3)

    # 输出JSON
    output_data = {
        "scraped_at": datetime.now().isoformat(),
        "keyword": kw_label,
        "type_filter": args.type,
        "total": len(results),
        "items": [asdict(item) for item in results],
    }

    output_path = args.output or f"asiaxpat_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    print(f"\n完成！共 {len(results)} 条结果，已保存到 {output_path}")

    # 导出CSV
    if args.csv:
        scraper.export_csv(results, args.csv)

    # 打印摘要
    for item in results:
        print(f"\n---")
        print(f"标题: {item.title}")
        print(f"类型: {item.category} | 作者: {item.author} | 日期: {item.date_published}")
        if item.description:
            print(f"概要: {item.description[:150]}...")
        print(f"链接: {item.url}")


if __name__ == "__main__":
    main()
