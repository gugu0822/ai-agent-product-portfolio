"""
新欧洲跳蚤市场 (buy.xineurope.com) 论坛爬虫
功能：按关键字搜索帖子，提取用户/联系人信息
用法：py -3 xineurope_scraper.py --keyword "招聘" [--max-pages 5] [--output results.json]
"""

import requests
import re
import json
import time
import argparse
import sys
from bs4 import BeautifulSoup
from dataclasses import dataclass, field, asdict
from typing import Optional
from datetime import datetime


@dataclass
class ListingItem:
    """帖子/信息条目"""
    title: str = ""
    link: str = ""
    category: str = ""           # 分类，如"求职招聘 · 旅游运输"
    location: str = ""           # 来自哪里，如"法国"
    publish_time: str = ""       # 发布时间
    contact_name: str = ""       # 联系人
    poster_name: str = ""        # 发布者/公司
    description: str = ""        # 详细描述
    structured_info: str = ""    # 结构化信息（薪资/学历/合同等）
    view_count: int = 0          # 浏览量
    avatar_url: str = ""         # 头像URL
    user_id: str = ""            # 从头像URL提取的用户ID
    phone_hidden: bool = False   # 是否有隐藏电话
    wechat: str = ""             # 微信号（如果在正文中）
    email: str = ""              # 邮箱（如果在正文中）
    work_location: str = ""      # 工作地点（如"大巴黎 94省 Villejuif"）
    map_url: str = ""            # Google Maps搜索链接


class XinEuropeScraper:
    BASE_URL = "https://buy.xineurope.com"
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
    }

    def __init__(self, delay: float = 2.0):
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self.delay = delay  # 请求间隔秒数

    def _get(self, url: str, params: dict = None) -> Optional[requests.Response]:
        """带重试和延迟的GET请求"""
        for attempt in range(3):
            try:
                time.sleep(self.delay)
                r = self.session.get(url, params=params, timeout=15)
                r.encoding = "utf-8"
                if r.status_code == 200:
                    return r
                elif r.status_code == 429:
                    wait = int(r.headers.get("Retry-After", 10))
                    print(f"  被限速，等待 {wait}s ...")
                    time.sleep(wait)
                else:
                    print(f"  HTTP {r.status_code}，重试 {attempt+1}/3")
            except requests.exceptions.RequestException as e:
                print(f"  请求异常: {e}，重试 {attempt+1}/3")
                time.sleep(3)
        return None

    def _extract_user_id(self, avatar_url: str) -> str:
        """从头像URL提取用户ID"""
        m = re.search(r"avatar/(\d+)/(\d+)/(\d+)/", avatar_url)
        return m.group(3) if m else ""

    def _extract_contact_wechat_email(self, text: str) -> tuple:
        """从正文中提取微信号和邮箱"""
        wechat = ""
        email = ""
        # 微信号模式（只匹配字母数字和常见ID字符，遇到中文/标点即停止）
        wx_patterns = [
            r"(?:微信|WeChat|wechat|wx|绿泡泡)[：:\s]*([A-Za-z0-9_\-]{5,30})",
            r"(?:微信|WeChat|wechat|wx|绿泡泡)\s*([A-Za-z0-9_\-]{5,30})",
        ]
        for pat in wx_patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                wechat = m.group(1).strip()
                # 去除尾部误抓的标签词
                wechat = re.sub(r"(?:E-?mail|Tel|Phone|电话|联系).*$", "", wechat, flags=re.IGNORECASE).strip()
                break

        # 邮箱模式（纯ASCII，避免匹配中文前缀）
        m = re.search(r"[a-zA-Z0-9.+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
        if m:
            email = m.group(0)

        return wechat, email

    @staticmethod
    def _make_map_url(location: str) -> str:
        """根据地址文本生成Google Maps搜索链接"""
        if not location:
            return ""
        from urllib.parse import quote
        return f"https://www.google.com/maps/search/{quote(location.strip())}"

    def parse_listing_page(self, html: str) -> list:
        """解析首页帖子列表（仅基本信息）"""
        soup = BeautifulSoup(html, "html.parser")
        items = []
        for a_tag in soup.find_all("a", class_="zixun-item"):
            item = ListingItem()
            title_el = a_tag.find("h4")
            item.title = title_el.get_text(strip=True) if title_el else ""
            item.link = self.BASE_URL + "/" + a_tag.get("href", "")

            img = a_tag.find("img")
            if img:
                item.avatar_url = img.get("src", "")
                item.user_id = self._extract_user_id(item.avatar_url)

            # 从标题解析用户名和分类
            # 格式: "username07-17发布了旅游运输信息"
            m = re.match(r"^(.+?)(\d{2}-\d{2})发布了(.+)信息$", item.title)
            if m:
                item.poster_name = m.group(1)
                item.publish_time = m.group(2)
                item.category = m.group(3)

            if item.title:
                items.append(item)
        return items

    def parse_detail_page(self, html: str, item: ListingItem) -> ListingItem:
        """解析详情页，补充完整信息"""
        soup = BeautifulSoup(html, "html.parser")

        # 分类
        el = soup.find(class_="job-name")
        if el:
            item.category = el.get_text(strip=True)

        # 来源地 + 发布时间
        el = soup.find(class_="user-operations")
        if el:
            text = el.get_text(strip=True)
            m = re.search(r"来自(\S+)", text)
            if m:
                item.location = m.group(1)
            m = re.search(r"发布时间\s*([\d-]+\s*[\d:]*)", text)
            if m:
                item.publish_time = m.group(1)

        # 浏览量
        el = soup.find(class_="link-views")
        if el:
            m = re.search(r"(\d+)", el.get_text())
            if m:
                item.view_count = int(m.group(1))

        # 联系人
        el = soup.find(class_="bd-tt")
        if el:
            item.contact_name = el.get_text(strip=True)

        # 发布者/公司
        el = soup.find(class_="gongsi")
        if el:
            item.poster_name = el.get_text(strip=True)

        # 结构化信息
        el = soup.find(class_="job-classfiy")
        if el:
            item.structured_info = el.get_text(strip=True)
            # 提取工作地点
            for p_tag in el.find_all("p"):
                p_text = p_tag.get_text(strip=True)
                if p_text.startswith("工作地点"):
                    loc = p_text.replace("工作地点", "").strip("：: ")
                    if loc:
                        item.work_location = loc
                        item.map_url = self._make_map_url(loc)
                    break

        # 详细描述
        el = soup.find(class_="job-description")
        if el:
            item.description = el.get_text(strip=True)

        # 从描述中提取微信和邮箱
        full_text = (item.description or "") + " " + (item.structured_info or "")
        wechat, email = self._extract_contact_wechat_email(full_text)
        item.wechat = wechat
        item.email = email

        # 是否有隐藏电话
        if soup.find(class_="salary-box") or soup.find(text=re.compile("扫码打电话")):
            item.phone_hidden = True

        return item

    def parse_ajax_listing(self, html_fragment: str) -> list:
        """解析AJAX API返回的HTML片段（a.card_row卡片）"""
        soup = BeautifulSoup(html_fragment, "html.parser")
        items = []
        for a_tag in soup.find_all("a", class_="card_row"):
            item = ListingItem()
            item.title = a_tag.find("h3").get_text(strip=True) if a_tag.find("h3") else ""
            data_id = a_tag.get("data-id", "")
            if data_id:
                item.link = f"{self.BASE_URL}/xinxi_{data_id}.html"
            # 提取标签
            tags = [span.get_text(strip=True) for span in a_tag.find_all("span", class_="mod_lv")]
            if tags:
                item.category = " | ".join(tags)
            # 提取图片
            img = a_tag.find("img")
            if img:
                item.avatar_url = img.get("src", "")
            # 提取工作地点（blue1标签）
            blue1 = a_tag.find("li", class_="blue1")
            if blue1:
                loc = blue1.get_text(strip=True)
                if loc:
                    item.work_location = loc
                    item.map_url = self._make_map_url(loc)
            if item.title and item.link:
                items.append(item)
        return items

    def search(self, keyword: str, max_pages: int = 5) -> list:
        """按关键字搜索帖子（使用AJAX API，无需登录）"""
        print(f"搜索关键字: {keyword}，最多 {max_pages} 页")
        all_items = []

        for page in range(1, max_pages + 1):
            print(f"  正在获取第 {page}/{max_pages} 页...")
            r = self._get(self.BASE_URL + "/plugin.php", params={
                "id": "xigua_hb",
                "cat_id": "",
                "keyword": keyword,
                "province": "",
                "city": "",
                "dist": "",
                "orderby": "",
                "filter": "",
                "ac": "list_item",
                "inajax": "1",
                "pagesize": "20",
                "page": str(page),
            })
            if not r:
                print(f"  第 {page} 页请求失败，停止翻页")
                break

            # AJAX API返回XML，其中CDATA包含HTML片段
            # 提取CDATA内容
            cdata_matches = re.findall(r"<!\[CDATA\[(.*?)\]\]>", r.text, re.DOTALL)
            if not cdata_matches:
                # 可能直接是HTML片段
                page_items = self.parse_ajax_listing(r.text)
            else:
                page_items = []
                for cdata in cdata_matches:
                    page_items.extend(self.parse_ajax_listing(cdata))

            if not page_items:
                print(f"  第 {page} 页无结果，停止翻页")
                break

            print(f"  第 {page} 页: {len(page_items)} 条结果")
            all_items.extend(page_items)

        print(f"\n共找到 {len(all_items)} 条结果")

        # 获取详情页信息
        if all_items:
            print(f"\n正在获取详情页...")
            for i, item in enumerate(all_items):
                if item.link and not item.description:
                    print(f"  [{i+1}/{len(all_items)}] {item.title[:40]}...")
                    r = self._get(item.link)
                    if r:
                        item = self.parse_detail_page(r.text, item)
                        all_items[i] = item

        return all_items

    def crawl_homepage(self, max_items: int = 20) -> list:
        """爬取首页最新帖子"""
        print(f"爬取首页最新帖子 (最多 {max_items} 条)...")
        r = self._get(self.BASE_URL + "/")
        if not r:
            print("首页请求失败")
            return []

        items = self.parse_listing_page(r.text)
        items = items[:max_items]
        print(f"首页找到 {len(items)} 条帖子")

        # 获取详情
        print(f"\n正在获取详情页...")
        for i, item in enumerate(items):
            if item.link:
                print(f"  [{i+1}/{len(items)}] {item.title[:40]}...")
                r = self._get(item.link)
                if r:
                    item = self.parse_detail_page(r.text, item)
                    items[i] = item

        return items

    def filter_by_user(self, items: list, username: str = None, user_id: str = None) -> list:
        """按用户名或ID过滤"""
        results = []
        for item in items:
            if username and username.lower() in (item.poster_name or "").lower():
                results.append(item)
            elif username and username.lower() in (item.contact_name or "").lower():
                results.append(item)
            elif user_id and item.user_id == user_id:
                results.append(item)
        return results


def main():
    parser = argparse.ArgumentParser(description="新欧洲跳蚤市场论坛爬虫")
    parser.add_argument("--keyword", "-k", type=str, help="搜索关键字")
    parser.add_argument("--username", "-u", type=str, help="按用户名过滤")
    parser.add_argument("--user-id", type=str, help="按用户ID过滤")
    parser.add_argument("--max-pages", type=int, default=3, help="最大搜索页数 (默认3)")
    parser.add_argument("--max-items", type=int, default=20, help="最大抓取条数 (默认20)")
    parser.add_argument("--delay", type=float, default=2.0, help="请求间隔秒数 (默认2)")
    parser.add_argument("--output", "-o", type=str, default=None, help="输出JSON文件路径")
    parser.add_argument("--homepage", action="store_true", help="爬取首页最新帖子（而非搜索）")

    args = parser.parse_args()

    scraper = XinEuropeScraper(delay=args.delay)

    if args.homepage:
        items = scraper.crawl_homepage(max_items=args.max_items)
    elif args.keyword:
        items = scraper.search(keyword=args.keyword, max_pages=args.max_pages)
    else:
        print("请指定 --keyword 搜索关键字 或 --homepage 爬取首页")
        sys.exit(1)

    # 按用户名过滤
    if args.username:
        items = scraper.filter_by_user(items, username=args.username)
        print(f"\n按用户名 '{args.username}' 过滤后: {len(items)} 条")
    elif args.user_id:
        items = scraper.filter_by_user(items, user_id=args.user_id)
        print(f"\n按用户ID '{args.user_id}' 过滤后: {len(items)} 条")

    # 输出结果
    output_data = {
        "scraped_at": datetime.now().isoformat(),
        "keyword": args.keyword,
        "total": len(items),
        "items": [asdict(item) for item in items],
    }

    output_path = args.output or f"xineurope_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    print(f"\n完成！共 {len(items)} 条结果，已保存到 {output_path}")

    # 打印摘要
    for item in items:
        print(f"\n---")
        print(f"标题: {item.title}")
        print(f"分类: {item.category}")
        print(f"联系人: {item.contact_name} | 发布者: {item.poster_name}")
        print(f"地点: {item.location} | 工作地点: {item.work_location} | 时间: {item.publish_time}")
        if item.map_url:
            print(f"地图: {item.map_url}")
        if item.wechat:
            print(f"微信: {item.wechat}")
        if item.email:
            print(f"邮箱: {item.email}")
        print(f"链接: {item.link}")


if __name__ == "__main__":
    main()
