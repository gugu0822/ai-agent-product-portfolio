# -*- coding: utf-8 -*-
"""
Email rendering engine.
Reads content from email_data.py, renders HTML from master template, writes campaign files.

Architecture:
  email_data.py  ->  content (titles, blocks, CTA, campaigns)  [edit this]
  generate_emails.py  ->  rendering engine (build functions + I/O)  [don't touch unless changing layout]
"""
import re
import os

from email_data import EMAILS, CAMPAIGNS, UTM_DATE

TEMPLATE_PATH = r"E:\email-marketing\templates\email-template-master.html"
OUTPUT_DIR = r"E:\email-marketing\templates"

# ============================================================
# Block renderers
# ============================================================

def build_intro(text):
    return (
        '<table width="100%" cellpadding="0" cellspacing="0" bgcolor="#f7f8fa" style="background:#f7f8fa"><tr>\n'
        '<td style="padding:22px 30px">\n'
        f'<p style="margin:0;font-size:15px;color:#333;line-height:1.8">{text}</p>\n'
        '</td></tr></table>'
    )


def build_step(num, title, subtitle, body, example=None, warning=None, first=False):
    pad = '26px' if first else '24px'
    html = (
        f'<table width="100%" cellpadding="0" cellspacing="0"><tr>\n'
        f'<td style="padding:{pad} 30px 0">\n'
        f'<table width="100%" cellpadding="0" cellspacing="0"><tr>\n'
        f'<td style="width:32px;vertical-align:top">\n'
        f'<div style="width:28px;height:28px;border-radius:50%;background:#c42424;color:#fff;text-align:center;line-height:28px;font-size:14px;font-weight:700">{num}</div>\n'
        f'</td>\n'
        f'<td style="vertical-align:top;padding-left:10px">\n'
        f'<h2 style="margin:0 0 6px;font-size:17px;font-weight:700;color:#1a1a1a;line-height:1.3">{title}</h2>\n'
        f'<p style="margin:0 0 10px;font-size:14px;color:#888">{subtitle}</p>\n'
        f'<p style="margin:0;font-size:15px;color:#333;line-height:1.8">{body}</p>'
    )
    if example:
        html += (
            f'\n<table width="100%" cellpadding="0" cellspacing="0" style="margin-top:14px"><tr>\n'
            f'<td style="background:#f7f8fa;border-radius:4px;padding:14px 16px">\n'
            f'<p style="margin:0;font-size:14px;color:#555;line-height:1.8">\n'
            f'<strong style="color:#1a1a1a">{example[0]}</strong>{example[1]}\n'
            f'</p>\n'
            f'</td></tr></table>'
        )
    if warning:
        html += (
            f'\n<table width="100%" cellpadding="0" cellspacing="0" style="margin-top:10px"><tr>\n'
            f'<td style="background:#fff5f5;border-radius:4px;border:1px solid #fee0e0;padding:12px 16px">\n'
            f'<p style="margin:0;font-size:13px;color:#c0392b;line-height:1.7">\n'
            f'<strong>{warning[0]}</strong>{warning[1]}\n'
            f'</p>\n'
            f'</td></tr></table>'
        )
    html += '\n</td></tr></table>\n</td></tr></table>'
    return html


def build_summary(text):
    return (
        '<table width="100%" cellpadding="0" cellspacing="0" style="margin-top:24px"><tr>\n'
        '<td style="padding:0 30px">\n'
        '<table width="100%" cellpadding="0" cellspacing="0" bgcolor="#f7f8fa" style="background:#f7f8fa;border-radius:4px">\n'
        '<tr><td style="padding:20px 20px">\n'
        '<p style="margin:0 0 8px;font-size:15px;font-weight:700;color:#1a1a1a">\u5199\u5728\u6700\u540e</p>\n'
        f'<p style="margin:0;font-size:15px;color:#333;line-height:1.8">{text}</p>\n'
        '</td></tr></table>\n'
        '</td></tr></table>'
    )


# ============================================================
# Block dispatcher
# ============================================================

def render_blocks(blocks):
    """Render a list of block dicts into HTML string."""
    html = ""
    for block in blocks:
        btype = block["type"]
        if btype == "intro":
            html += build_intro(block["text"])
        elif btype == "step":
            html += build_step(
                block["num"],
                block["title"],
                block["subtitle"],
                block["body"],
                example=block.get("example"),
                warning=block.get("warning"),
                first=block.get("first", False),
            )
        elif btype == "summary":
            html += build_summary(block["text"])
        else:
            raise ValueError(f"Unknown block type: {btype}")
    return html


# ============================================================
# Pre-checks
# ============================================================

def check_content(brand, data):
    """Check content for common issues before rendering. Returns list of warnings."""
    issues = []
    all_text = data["title"] + data["preview"] + data["cta_text"] + data["hook_text"] + data["related_text"]
    for block in data["blocks"]:
        all_text += block.get("text", "")
        all_text += block.get("title", "")
        all_text += block.get("subtitle", "")
        all_text += block.get("body", "")
        if "example" in block:
            all_text += "".join(block["example"])
        if "warning" in block:
            all_text += "".join(block["warning"])
    if "\u2014\u2014" in all_text:
        issues.append("em dash (--) found in content")
    return issues


# ============================================================
# Main
# ============================================================

def main():
    if not os.path.exists(TEMPLATE_PATH):
        print(f"ERROR: Master template not found at {TEMPLATE_PATH}")
        exit(1)

    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        master = f.read()

    # --- Generate HTML emails ---
    for brand, data in EMAILS.items():
        # Pre-check
        for issue in check_content(brand, data):
            print(f"WARNING [{brand}]: {issue}")

        # Render blocks to HTML
        content_html = render_blocks(data["blocks"])

        # Replace placeholders
        html = master
        html = html.replace("{{PREVIEW_TEXT}}", data["preview"])
        html = html.replace("{{UTM_DATE}}", UTM_DATE)
        html = html.replace("{{TITLE}}", data["title"])
        html = html.replace("{{CONTENT_BLOCKS}}", content_html)
        html = html.replace("{{CTA_TEXT}}", data["cta_text"])
        html = html.replace("{{HOOK_TEXT}}", data["hook_text"])
        html = html.replace("{{RELATED_TEXT}}", data["related_text"])

        # Check for unreplaced placeholders
        remaining = re.findall(r'\{\{[A-Z_]+\}\}', html)
        expected_merge = {"{{SenderInfoLine}}", "{{UnsubscribeURL}}"}
        unexpected = [r for r in remaining if r not in expected_merge]
        if unexpected:
            print(f"WARNING [{brand}]: Unreplaced: {unexpected}")

        # Check for em dashes in rendered HTML
        em_count = html.count("\u2014\u2014")
        if em_count > 0:
            print(f"WARNING [{brand}]: {em_count} em dashes found in HTML!")

        # Save
        out_path = os.path.join(OUTPUT_DIR, data["filename"])
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(html)

        file_size = len(html.encode("utf-8"))
        print(f"[{brand.upper()}] Saved: {data['filename']} ({file_size} bytes)")

    # --- Generate campaign text files ---
    for brand, info in CAMPAIGNS.items():
        out_path = os.path.join(OUTPUT_DIR, info["file"])
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(info["content"])
        print(f"[{brand.upper()}] Campaign saved: {info['file']}")

    print("\n=== All files generated ===")


if __name__ == "__main__":
    main()
