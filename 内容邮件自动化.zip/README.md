# 邮件营销智能体 - 使用说明

## 这个智能体是干什么的

这个智能体帮你把写好的邮件内容自动生成漂亮的 HTML 邮件，然后一键发到企业微信群里。

**一句话说清楚**：你在 `email_data.py` 里填好三条业务线（少儿中文、IB、IGCSE）的邮件内容，跑一下脚本，它就给你生成三份 HTML 邮件文件和三份 Campaign 建议文本，再自动发到对应的企微群里。

---

## 三条业务线

| 业务线 | 代码名 | 说明 |
|--------|--------|------|
| 少儿中文 | `kids` | 面向海外华裔家庭的少儿中文学习内容 |
| IB 中文 | `ib` | 面向 IB 中文考试备考家庭 |
| IGCSE 中文 | `igcse` | 面向 IGCSE 中文考试备考家庭 |

---

## 包里有哪些文件

| 文件 | 作用 |
|------|------|
| `email_data.py` | **内容文件**——你每天改的就是这个，把邮件标题、正文、Campaign 建议写在这里面 |
| `generate_emails.py` | **生成器**——读取 `email_data.py` 的内容，用模板渲染成 HTML 邮件和 Campaign 文本文件 |
| `send_to_wechat.py` | **发送器**——把生成的 HTML 文件和 Campaign 文本发到企微群 |
| `webhook-config.env` | **企微配置**——存了企微群机器人地址，发送时自动读取 |
| `email-template-master.html` | **邮件母版**——HTML 邮件的母版，生成器渲染时用到（已包含在包里） |

---

## 怎么用（大白话版）

### 第一步：改内容

打开 `email_data.py`，找到 `EMAILS` 这个字典，里面有 `kids`、`ib`、`igcse` 三个块。每个块里改这几个地方：

- `title`：邮件标题
- `preview`：邮件预览文字（收件人列表里看到的那行小字）
- `blocks`：正文内容，按 `intro`（开头引子）→ `step`（步骤/段落，可以有多个）→ `summary`（结尾总结）的顺序写
- `cta_text`：按钮上的文字（比如"预约试听课"）
- `hook_text`：底部互动引导语
- `related_text`：相关阅读链接文字
- `filename`：生成的 HTML 文件名

然后改 `CAMPAIGNS` 字典，每个业务线对应一份 Campaign 建议文本，包含：邮件标题 A/B 测试建议、预览文字建议、发送列表、排除列表、最佳发送时间。

最后改 `UTM_DATE`（跟踪链接日期，格式 `YYYYMMDD`）。

### 第二步：生成 HTML

在命令行里运行：

```
py -3 generate_emails.py
```

它会读取 `email_data.py` 的内容，用 `email-template-master.html` 模板渲染出三份 HTML 邮件文件和三份 Campaign 文本文件，全部输出到 `E:\email-marketing\templates\` 目录下。

生成的文件名格式：
- HTML：`newsletter_YYYY-MM-DD_主题.html`
- Campaign：`campaign_YYYY-MM-DD_业务线.txt`

### 第三步：发到企微群

用 `send_to_wechat.py` 发送。有两种方式：

**方式一：用品牌名自动匹配企微群（推荐）**

```
py -3 send_to_wechat.py --brand kids --html "E:\email-marketing\templates\newsletter_2026-09-03_xxx.html" --campaign-file "E:\email-marketing\templates\campaign_2026-09-03_kids.txt"
```

`--brand` 后面填 `kids`、`ib` 或 `igcse`，脚本会自动从 `webhook-config.env` 里找到对应的企微群机器人地址。

**方式二：手动指定 webhook key**

```
py -3 send_to_wechat.py --key 你的webhook_key --html "HTML文件路径" --campaign-file "Campaign文件路径"
```

发送流程：
1. 先把 Campaign 建议文本作为 markdown 消息发到群里
2. 再把 HTML 文件上传到企微，以文件消息形式发到群里

---

## 企微群机器人地址

所有地址存在 `webhook-config.env` 文件里。完整地址格式为：

```
https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=你的key
```

### 三个内容总群

| 群名 | 变量名 | Webhook Key |
|------|--------|-------------|
| 少儿中文（总群） | KIDS_WEBHOOK | `<your-KIDS_WEBHOOK-key>` |
| IB 中文（总群） | IB_WEBHOOK | `<your-IB_WEBHOOK-key>` |
| IGCSE 中文（总群） | IGCSE_WEBHOOK | `<your-IGCSE_WEBHOOK-key>` |

### 三个邮件群（发送器默认用这三个）

| 群名 | 变量名 | Webhook Key |
|------|--------|-------------|
| 少儿中文邮件群 | KIDS_EMAIL_WEBHOOK | `<your-KIDS_EMAIL_WEBHOOK-key>` |
| IB 中文邮件群 | IB_EMAIL_WEBHOOK | `<your-IB_EMAIL_WEBHOOK-key>` |
| IGCSE 中文邮件群 | IGCSE_EMAIL_WEBHOOK | `<your-IGCSE_EMAIL_WEBHOOK-key>` |

> **注意**：`send_to_wechat.py` 的 `--brand` 参数默认匹配的是邮件群（变量名带 `_EMAIL`）。如果你要发到总群或其他群，需要用 `--key` 手动指定 key。

---

## 运行频率

**每天早上 9:20 运行。**

**工作日执行（周一到周五），周末不跑**

实际使用流程：
1. 每天写好三条业务线的邮件内容，填进 `email_data.py`
2. 跑一次 `generate_emails.py` 生成 HTML 和 Campaign 文件
3. 分别跑三次 `send_to_wechat.py`（每个业务线一次），把文件发到对应的企微邮件群

如果你想改成定时自动运行，可以用 DuMate 的定时任务功能，设定 cron 表达式（比如每天上午 9:20 自动跑），但目前还没有配置定时调度。

---

## 前置条件

1. **Python 3**：需要安装 Python 3，命令行能跑 `py -3`
2. **邮件模板**：`email-template-master.html` 必须放在 `E:\email-marketing\templates\` 目录下（已包含在包里，解压后复制过去即可）
3. **输出目录**：`E:\email-marketing\templates\` 目录必须存在（生成器把文件输出到这里）
4. **企微配置**：`webhook-config.env` 必须放在 `~/.qianfan/config/` 目录下（或者修改 `send_to_wechat.py` 里的 `CONFIG_FILE` 路径）

---

## 常见问题

**Q: 生成的 HTML 打开是乱码？**
A: 检查 `email_data.py` 里的中文是否用 UTF-8 编码保存。

**Q: 发送到企微群失败？**
A: 检查 `webhook-config.env` 里的 key 是否正确，以及网络是否能访问 `qyapi.weixin.qq.com`。

**Q: 想加一条新的业务线怎么办？**
A: 在 `email_data.py` 的 `EMAILS` 字典里加一个新 key，在 `CAMPAIGNS` 字典里也加一个对应 key，然后在 `send_to_wechat.py` 的 `BRAND_MAP` 里加上品牌名到变量名的映射，最后在 `webhook-config.env` 里加上对应的 webhook 地址。

**Q: 不想发到企微，只生成 HTML 行不行？**
A: 行。只跑 `generate_emails.py` 就行，不跑 `send_to_wechat.py` 就不会发到企微。

**Q: 邮件模板在哪？**
A: `email-template-master.html` 已经包含在这个包里，解压后复制到 `E:\email-marketing\templates\` 目录下即可使用。
