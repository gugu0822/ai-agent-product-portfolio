#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
企业微信 Webhook 发送工具
支持发送 markdown 消息和上传文件

用法：
  py -3 send_to_wechat.py --key <webhook_key> --html <html文件路径> --campaign-file <campaign文本文件路径>

参数：
  --key           企业微信 webhook key（必填）
  --html          HTML 文件路径（可选，上传并发送文件消息）
  --campaign-file Campaign 建议文本文件路径（可选，作为 markdown 消息发送）

流程：
  1. 如果有 --campaign-file，先发送 Campaign 建议（markdown 消息）
  2. 如果有 --html，上传 HTML 文件获取 media_id，然后发送文件消息
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error

WEBHOOK_BASE = "https://qyapi.weixin.qq.com/cgi-bin/webhook"
# 企微配置路径：优先取环境变量 WEBHOOK_CONFIG_FILE，默认用户目录 ~/.qianfan/config/webhook-config.env
CONFIG_FILE = os.environ.get(
    "WEBHOOK_CONFIG_FILE",
    os.path.join(os.path.expanduser("~"), ".qianfan", "config", "webhook-config.env"),
)

BRAND_MAP = {
    "kids": "KIDS_EMAIL_WEBHOOK",
    "少儿中文": "KIDS_EMAIL_WEBHOOK",
    "少儿": "KIDS_EMAIL_WEBHOOK",
    "ib": "IB_EMAIL_WEBHOOK",
    "IB": "IB_EMAIL_WEBHOOK",
    "IB中文": "IB_EMAIL_WEBHOOK",
    "igcse": "IGCSE_EMAIL_WEBHOOK",
    "IGCSE": "IGCSE_EMAIL_WEBHOOK",
    "IGCSE中文": "IGCSE_EMAIL_WEBHOOK",
}


def load_webhook_config():
    """从本地配置文件读取 webhook 配置，无需询问用户"""
    config = {}
    if not os.path.exists(CONFIG_FILE):
        print(f"[ERROR] 配置文件不存在: {CONFIG_FILE}")
        sys.exit(1)
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                config[key.strip()] = value.strip()
    return config


def resolve_key(args):
    """根据 --key 或 --brand 参数解析最终的 webhook key"""
    if args.key:
        return args.key
    if args.brand:
        config = load_webhook_config()
        var_name = BRAND_MAP.get(args.brand)
        if not var_name:
            print(f"[ERROR] 未知品牌: {args.brand}。支持: {list(BRAND_MAP.keys())}")
            sys.exit(1)
        url = config.get(var_name)
        if not url:
            print(f"[ERROR] 配置中未找到 {var_name}")
            sys.exit(1)
        # 从 URL 中提取 key 部分
        if "key=" in url:
            return url.split("key=")[1]
        print(f"[ERROR] 无法从配置解析 key: {url}")
        sys.exit(1)
    print("[ERROR] 必须提供 --key 或 --brand 参数")
    sys.exit(1)


def send_markdown(key, content):
    """发送 markdown 消息到企业微信群"""
    url = f"{WEBHOOK_BASE}/send?key={key}"
    data = json.dumps({
        "msgtype": "markdown",
        "markdown": {
            "content": content
        }
    }).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            if result.get("errcode") == 0:
                print(f"[OK] Campaign markdown 发送成功")
                return True
            else:
                print(f"[ERROR] 发送失败: errcode={result.get('errcode')}, errmsg={result.get('errmsg')}")
                return False
    except Exception as e:
        print(f"[ERROR] 发送异常: {e}")
        return False


def upload_media(key, file_path):
    """上传文件到企业微信，返回 media_id"""
    url = f"{WEBHOOK_BASE}/upload_media?key={key}&type=file"

    file_name = os.path.basename(file_path)
    file_size = os.path.getsize(file_path)

    # 构建 multipart/form-data 请求体
    boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"

    with open(file_path, "rb") as f:
        file_data = f.read()

    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="media"; filename="{file_name}"\r\n'
        f"Content-Type: application/octet-stream\r\n"
        f"\r\n"
    ).encode("utf-8") + file_data + f"\r\n--{boundary}--\r\n".encode("utf-8")

    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            if result.get("errcode") == 0:
                media_id = result.get("media_id")
                print(f"[OK] 文件上传成功: {file_name} ({file_size} bytes), media_id={media_id}")
                return media_id
            else:
                print(f"[ERROR] 上传失败: errcode={result.get('errcode')}, errmsg={result.get('errmsg')}")
                return None
    except Exception as e:
        print(f"[ERROR] 上传异常: {e}")
        return None


def send_file(key, media_id):
    """发送文件消息到企业微信群"""
    url = f"{WEBHOOK_BASE}/send?key={key}"
    data = json.dumps({
        "msgtype": "file",
        "file": {
            "media_id": media_id
        }
    }).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            if result.get("errcode") == 0:
                print(f"[OK] 文件消息发送成功")
                return True
            else:
                print(f"[ERROR] 文件消息发送失败: errcode={result.get('errcode')}, errmsg={result.get('errmsg')}")
                return False
    except Exception as e:
        print(f"[ERROR] 文件消息发送异常: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="企业微信 Webhook 发送工具")
    parser.add_argument("--key", help="企业微信 webhook key（与 --brand 二选一）")
    parser.add_argument("--brand", help="业务线品牌名，自动从 webhook-config.env 读取 key（如 kids/IB/IGCSE/少儿中文）")
    parser.add_argument("--html", help="HTML 文件路径（上传并发送）")
    parser.add_argument("--campaign-file", help="Campaign 建议文本文件路径（作为 markdown 发送）")

    args = parser.parse_args()

    # 解析最终的 webhook key
    webhook_key = resolve_key(args)

    if not args.campaign_file and not args.html:
        print("[ERROR] 至少需要提供 --campaign-file 或 --html 参数之一")
        sys.exit(1)

    success = True

    # 步骤1：发送 Campaign 建议（markdown 消息）
    if args.campaign_file:
        campaign_path = os.path.abspath(args.campaign_file)
        if not os.path.exists(campaign_path):
            print(f"[ERROR] Campaign 文件不存在: {campaign_path}")
            sys.exit(1)

        print(f"[INFO] 读取 Campaign 文件: {campaign_path}")
        with open(campaign_path, "r", encoding="utf-8") as f:
            campaign_content = f.read()

        if not campaign_content.strip():
            print("[WARN] Campaign 文件为空，跳过发送")
        else:
            print(f"[INFO] 发送 Campaign 建议（{len(campaign_content)} 字符）...")
            if not send_markdown(webhook_key, campaign_content):
                success = False
                print("[WARN] Campaign 发送失败，继续执行文件上传...")

    # 步骤2：上传 HTML 文件并发送文件消息
    if args.html:
        html_path = os.path.abspath(args.html)
        if not os.path.exists(html_path):
            print(f"[ERROR] HTML 文件不存在: {html_path}")
            sys.exit(1)

        print(f"[INFO] 上传 HTML 文件: {html_path}")
        media_id = upload_media(webhook_key, html_path)

        if media_id:
            print("[INFO] 发送文件消息...")
            if not send_file(webhook_key, media_id):
                success = False
        else:
            success = False
            print("[ERROR] 文件上传失败，无法发送文件消息")

    if success:
        print("\n[DONE] 全部发送完成！")
    else:
        print("\n[WARN] 部分发送失败，请检查上方错误信息")
        sys.exit(1)


if __name__ == "__main__":
    main()
