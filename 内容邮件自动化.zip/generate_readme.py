# -*- coding: utf-8 -*-
"""
README.md 生成脚本
把 README 内容参数化，方便后续修改配置后重新生成

用法：
  py -3 generate_readme.py
"""

# ============================================================
# 配置区——改这里，不用手动改 README.md
# ============================================================

# 运行频率
RUN_TIME = "每天早上 9:20"
RUN_DAYS = "工作日执行（周一到周五），周末不跑"

# 企微群列表
WEBHOOK_GROUPS = [
    {
        "category": "三个内容总群",
        "groups": [
            {"name": "少儿中文（总群）", "var": "KIDS_WEBHOOK", "key": "<your-KIDS_WEBHOOK-key>"},
            {"name": "IB 中文（总群）", "var": "IB_WEBHOOK", "key": "<your-IB_WEBHOOK-key>"},
            {"name": "IGCSE 中文（总群）", "var": "IGCSE_WEBHOOK", "key": "<your-IGCSE_WEBHOOK-key>"},
        ]
    },
    {
        "category": "三个邮件群（发送器默认用这三个）",
        "groups": [
            {"name": "少儿中文邮件群", "var": "KIDS_EMAIL_WEBHOOK", "key": "<your-KIDS_EMAIL_WEBHOOK-key>"},
            {"name": "IB 中文邮件群", "var": "IB_EMAIL_WEBHOOK", "key": "<your-IB_EMAIL_WEBHOOK-key>"},
            {"name": "IGCSE 中文邮件群", "var": "IGCSE_EMAIL_WEBHOOK", "key": "<your-IGCSE_EMAIL_WEBHOOK-key>"},
        ]
    },
]

# 业务线
BUSINESS_LINES = [
    {"name": "少儿中文", "code": "kids", "desc": "面向海外华裔家庭的少儿中文学习内容"},
    {"name": "IB 中文", "code": "ib", "desc": "面向 IB 中文考试备考家庭"},
    {"name": "IGCSE 中文", "code": "igcse", "desc": "面向 IGCSE 中文考试备考家庭"},
]

# 输出路径
OUTPUT_PATH = "README.md"


# ============================================================
# 生成逻辑——下面不用改
# ============================================================

def generate():
    lines = []

    # 标题
    lines.append("# 邮件营销智能体 - 使用说明\n")

    # 用途
    lines.append("## 这个智能体是干什么的\n")
    lines.append("这个智能体帮你把写好的邮件内容自动生成漂亮的 HTML 邮件，然后一键发到企业微信群里。\n")
    lines.append("**一句话说清楚**：你在 `email_data.py` 里填好三条业务线（少儿中文、IB、IGCSE）的邮件内容，跑一下脚本，它就给你生成三份 HTML 邮件文件和三份 Campaign 建议文本，再自动发到对应的企微群里。\n")

    # 业务线
    lines.append("---\n")
    lines.append("## 三条业务线\n")
    lines.append("| 业务线 | 代码名 | 说明 |")
    lines.append("|--------|--------|------|")
    for line in BUSINESS_LINES:
        lines.append(f"| {line['name']} | `{line['code']}` | {line['desc']} |")
    lines.append("")

    # 文件清单
    lines.append("---\n")
    lines.append("## 包里有哪些文件\n")
    lines.append("| 文件 | 作用 |")
    lines.append("|------|------|")
    lines.append("| `email_data.py` | **内容文件**——你每天改的就是这个，把邮件标题、正文、Campaign 建议写在这里面 |")
    lines.append("| `generate_emails.py` | **生成器**——读取 `email_data.py` 的内容，用模板渲染成 HTML 邮件和 Campaign 文本文件 |")
    lines.append("| `send_to_wechat.py` | **发送器**——把生成的 HTML 文件和 Campaign 文本发到企微群 |")
    lines.append("| `webhook-config.env` | **企微配置**——存了企微群机器人地址，发送时自动读取 |")
    lines.append("| `email-template-master.html` | **邮件母版**——HTML 邮件的母版，生成器渲染时用到（已包含在包里） |")
    lines.append("")

    # 使用步骤
    lines.append("---\n")
    lines.append("## 怎么用（大白话版）\n")
    lines.append("### 第一步：改内容\n")
    lines.append("打开 `email_data.py`，找到 `EMAILS` 这个字典，里面有 `kids`、`ib`、`igcse` 三个块。每个块里改这几个地方：\n")
    lines.append("- `title`：邮件标题")
    lines.append("- `preview`：邮件预览文字（收件人列表里看到的那行小字）")
    lines.append("- `blocks`：正文内容，按 `intro`（开头引子）→ `step`（步骤/段落，可以有多个）→ `summary`（结尾总结）的顺序写")
    lines.append("- `cta_text`：按钮上的文字（比如\"预约试听课\"）")
    lines.append("- `hook_text`：底部互动引导语")
    lines.append("- `related_text`：相关阅读链接文字")
    lines.append("- `filename`：生成的 HTML 文件名\n")
    lines.append("然后改 `CAMPAIGNS` 字典，每个业务线对应一份 Campaign 建议文本，包含：邮件标题 A/B 测试建议、预览文字建议、发送列表、排除列表、最佳发送时间。\n")
    lines.append("最后改 `UTM_DATE`（跟踪链接日期，格式 `YYYYMMDD`）。\n")

    lines.append("### 第二步：生成 HTML\n")
    lines.append("在命令行里运行：\n")
    lines.append("```")
    lines.append("py -3 generate_emails.py")
    lines.append("```\n")
    lines.append("它会读取 `email_data.py` 的内容，用 `email-template-master.html` 模板渲染出三份 HTML 邮件文件和三份 Campaign 文本文件，全部输出到 `E:\\email-marketing\\templates\\` 目录下。\n")
    lines.append("生成的文件名格式：")
    lines.append("- HTML：`newsletter_YYYY-MM-DD_主题.html`")
    lines.append("- Campaign：`campaign_YYYY-MM-DD_业务线.txt`\n")

    lines.append("### 第三步：发到企微群\n")
    lines.append("用 `send_to_wechat.py` 发送。有两种方式：\n")
    lines.append("**方式一：用品牌名自动匹配企微群（推荐）**\n")
    lines.append("```")
    lines.append('py -3 send_to_wechat.py --brand kids --html "E:\\email-marketing\\templates\\newsletter_2026-09-03_xxx.html" --campaign-file "E:\\email-marketing\\templates\\campaign_2026-09-03_kids.txt"')
    lines.append("```\n")
    lines.append("`--brand` 后面填 `kids`、`ib` 或 `igcse`，脚本会自动从 `webhook-config.env` 里找到对应的企微群机器人地址。\n")
    lines.append("**方式二：手动指定 webhook key**\n")
    lines.append("```")
    lines.append('py -3 send_to_wechat.py --key 你的webhook_key --html "HTML文件路径" --campaign-file "Campaign文件路径"')
    lines.append("```\n")
    lines.append("发送流程：")
    lines.append("1. 先把 Campaign 建议文本作为 markdown 消息发到群里")
    lines.append("2. 再把 HTML 文件上传到企微，以文件消息形式发到群里\n")

    # 企微地址
    lines.append("---\n")
    lines.append("## 企微群机器人地址\n")
    lines.append("所有地址存在 `webhook-config.env` 文件里。完整地址格式为：\n")
    lines.append("```")
    lines.append("https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=你的key")
    lines.append("```\n")

    for section in WEBHOOK_GROUPS:
        lines.append(f"### {section['category']}\n")
        if section['groups'] and 'var' in section['groups'][0]:
            lines.append("| 群名 | 变量名 | Webhook Key |")
            lines.append("|------|--------|-------------|")
            for g in section['groups']:
                lines.append(f"| {g['name']} | {g['var']} | `{g['key']}` |")
        else:
            lines.append("| 群名 | 说明 |")
            lines.append("|------|------|")
            for g in section['groups']:
                lines.append(f"| {g['name']} | {g['note']} |")
        lines.append("")

    lines.append("> **注意**：`send_to_wechat.py` 的 `--brand` 参数默认匹配的是邮件群（变量名带 `_EMAIL`）。如果你要发到总群或其他群，需要用 `--key` 手动指定 key。\n")

    # 运行频率
    lines.append("---\n")
    lines.append("## 运行频率\n")
    lines.append(f"**{RUN_TIME} 运行。**\n")
    lines.append(f"**{RUN_DAYS}**\n")
    lines.append("实际使用流程：")
    lines.append("1. 每天写好三条业务线的邮件内容，填进 `email_data.py`")
    lines.append("2. 跑一次 `generate_emails.py` 生成 HTML 和 Campaign 文件")
    lines.append("3. 分别跑三次 `send_to_wechat.py`（每个业务线一次），把文件发到对应的企微邮件群\n")
    lines.append("如果你想改成定时自动运行，可以用 DuMate 的定时任务功能，设定 cron 表达式（比如每天上午 9:20 自动跑），但目前还没有配置定时调度。\n")

    # 前置条件
    lines.append("---\n")
    lines.append("## 前置条件\n")
    lines.append("1. **Python 3**：需要安装 Python 3，命令行能跑 `py -3`")
    lines.append("2. **邮件模板**：`email-template-master.html` 必须放在 `E:\\email-marketing\\templates\\` 目录下（已包含在包里，解压后复制过去即可）")
    lines.append("3. **输出目录**：`E:\\email-marketing\\templates\\` 目录必须存在（生成器把文件输出到这里）")
    lines.append("4. **企微配置**：`webhook-config.env` 必须放在 `~/.qianfan/config/` 目录下（或者修改 `send_to_wechat.py` 里的 `CONFIG_FILE` 路径）\n")

    # 常见问题
    lines.append("---\n")
    lines.append("## 常见问题\n")
    lines.append("**Q: 生成的 HTML 打开是乱码？**")
    lines.append("A: 检查 `email_data.py` 里的中文是否用 UTF-8 编码保存。\n")
    lines.append("**Q: 发送到企微群失败？**")
    lines.append("A: 检查 `webhook-config.env` 里的 key 是否正确，以及网络是否能访问 `qyapi.weixin.qq.com`。\n")
    lines.append("**Q: 想加一条新的业务线怎么办？**")
    lines.append("A: 在 `email_data.py` 的 `EMAILS` 字典里加一个新 key，在 `CAMPAIGNS` 字典里也加一个对应 key，然后在 `send_to_wechat.py` 的 `BRAND_MAP` 里加上品牌名到变量名的映射，最后在 `webhook-config.env` 里加上对应的 webhook 地址。\n")
    lines.append("**Q: 不想发到企微，只生成 HTML 行不行？**")
    lines.append("A: 行。只跑 `generate_emails.py` 就行，不跑 `send_to_wechat.py` 就不会发到企微。\n")
    lines.append("**Q: 邮件模板在哪？**")
    lines.append("A: `email-template-master.html` 已经包含在这个包里，解压后复制到 `E:\\email-marketing\\templates\\` 目录下即可使用。\n")

    # 写入
    content = "\n".join(lines)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[OK] README.md 已生成: {OUTPUT_PATH}")


if __name__ == "__main__":
    generate()
