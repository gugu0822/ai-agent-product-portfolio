@echo off
chcp 65001 >nul
title 面试提醒Agent - 一键启动

echo ════════════════════════════════════════════════════════════
echo   面试提醒Agent - 一键安装并运行
echo ════════════════════════════════════════════════════════════
echo.

:: 检查 Python
echo [1/3] 检查 Python 环境...
python --version >nul 2>&1
if errorlevel 1 (
    echo [FAIL] 未检测到 Python，请先安装 Python 3.10+
    echo        下载地址: https://www.python.org/downloads/
    echo        安装时务必勾选 "Add Python to PATH"
    pause
    exit /b 1
)
echo [OK] Python 已安装

:: 安装依赖
echo.
echo [2/3] 检查并安装依赖包...
pip install aliyun-python-sdk-core aliyun-python-sdk-outboundbot -q 2>nul
if errorlevel 1 (
    echo [WARN] 依赖安装可能失败，尝试用 --user 参数重试...
    pip install aliyun-python-sdk-core aliyun-python-sdk-outboundbot --user -q 2>nul
)
echo [OK] 依赖包已就绪

:: 运行程序
echo.
echo [3/3] 启动面试提醒Agent...
echo.
cd /d "%~dp0.dumate\scripts"
python main.py %*

echo.
echo ════════════════════════════════════════════════════════════
echo  执行完毕。日志文件在 .dumate\output\ 目录下
echo ════════════════════════════════════════════════════════════
pause
