---
name: interview-reminder-agent
description: >-
  面试预约外呼机器人。通过阿里云智能外呼(大模型对话场景)自动拨打候选人电话，
  AI多轮对话完成面试时间预约，支持串行拨打、时段去重、防重复拨打、结果查询和Excel报告导出。
  触发词：面试外呼、面试预约、拨打候选人电话、批量面试通知、外呼面试、面试提醒、interview call。
  当用户提到"给候选人打电话""拨面试电话""外呼面试预约""今天的名单拨打了吗"时使用此技能。
---

# 面试预约外呼机器人

自动批量拨打候选人电话，通过阿里云大模型对话场景完成面试预约。

## 能力概览

- **批量串行外呼**：逐个拨打候选人电话，每人通话结束后再拨下一个
- **AI多轮对话**：大模型驱动对话，自动确认身份、筛选意向、协商面试时间
- **时段去重**：前一人预约的时段自动传给后一人，不会重复分配
- **防重复拨打**：基于 `called_history.json` 记录已拨打号码，同一号码不会重复拨打
- **人工占位**：HR手动约的时段写入 `manual_booked_slots.json` 后自动避开
- **结果查询**：查询通话记录，提取预约时段、实习时长、到岗时间、通勤情况等
- **Excel报告**：一键导出外呼结果明细表，含12列结构化数据

## 前置条件

### 阿里云凭证

凭证文件位于以下路径之一（脚本自动查找）：

1. 项目目录：`.dumate/scripts/alibabacloud.properties`
2. 用户目录：`~/.alibabacloud/alibabacloud.properties`

文件格式（JSON）：

```json
{"access_key_id": "xxx", "access_key_secret": "xxx"}
```

### 阿里云智能外呼配置

以下参数在 `batch_call.py` 顶部硬编码（也可改到 config.py）：

| 参数 | 值 | 说明 |
|------|-----|------|
| INSTANCE_ID | 环境变量 `ALIYUN_INSTANCE_ID` | 阿里云外呼实例ID |
| SCRIPT_ID | 环境变量 `ALIYUN_SCRIPT_ID` | 大模型场景脚本ID |
| CALLING_NUMBER | 环境变量 `ALIYUN_CALLER_NUMBER` | 主叫号码（需在控制台绑定） |

### Python 依赖

```bash
pip install aliyun-python-sdk-core aliyun-python-sdk-outboundbot openpyxl
```

## 目录结构

```
interview-reminder-agent/
├── SKILL.md                          ← 本文件（技能描述）
├── .dumate/
│   ├── candidates_batch.json         ← 【输入】候选人名单
│   ├── called_history.json           ← 【自动】已拨打号码历史（防重复）
│   ├── manual_booked_slots.json      ← 【输入】人工已占用时段（可选）
│   ├── output/
│   │   ├── batch_call_results.json   ← 【输出】外呼结果JSON
│   │   └── 外呼结果报告.xlsx          ← 【输出】Excel报告
│   └── scripts/
│       ├── batch_call.py             ← 批量外呼主脚本（含数据清洗、.get容错、中文数字解析）
│       ├── result_query.py           ← 结果查询+Excel导出
│       ├── aliyun_caller.py          ← 阿里云外呼API封装
│       ├── config.py                 ← 配置文件
│       ├── slot_generator.py         ← 面试时段生成
│       ├── validator.py              ← 输入校验（支持10种HR口述变体）
│       ├── test_simulation.py        ← 模拟测试（10组HR数据场景，自动化回归测试）
│       └── alibabacloud.properties   ← 阿里云凭证
├── run.bat                           ← Windows一键执行
└── 使用说明.txt                       ← 人类可读说明
```

## 候选人名单格式

文件：`.dumate/candidates_batch.json`

```json
[
  {
    "name": "张三",
    "phone": "13800138000",
    "position": "产品实习生",
    "city": "城市A"
  },
  {
    "name": "李四",
    "phone": "13900139000",
    "position": "产品实习生",
    "city": "城市B"
  }
]
```

字段说明：

| 字段 | 必填 | 说明 |
|------|------|------|
| name | 是 | 候选人姓名，1-30字符，支持空格（少数民族姓名） |
| phone | 是 | 11位手机号，以1开头。自动处理：`+86 `前缀、`-`分隔符会被自动剥离 |
| position | 是 | 投递岗位名称，最多100字符 |
| city | 是 | 面试城市，限"城市A"或"城市B" |

**HR口述数据兼容性说明**：

脚本已内置数据清洗和容错，支持以下HR常见口述变体：

| 场景 | 原始输入 | 处理后结果 | 状态 |
|------|---------|-----------|------|
| 手机号带分隔符 | `138-0013-8000` | `13800138000` | ✅ 自动清洗 |
| 手机号带+86前缀 | `+86 13900139000` | `13900139000` | ✅ 自动清洗 |
| 少数民族姓名含空格 | `买买提 依明` | 保留空格 | ✅ 正常通过 |
| 缺city字段 | `{name, phone, position}` | city默认空字符串 | ✅ 不崩溃（但城市规则不生效） |
| 缺phone字段 | `{name, position, city}` | 跳过不打 | ✅ 打印SKIP，不崩溃 |
| 岗位名超长 | 101字符 | 校验拒绝 | ❌ 需HR缩短后重传 |
| 手机号10位 | `1380013800` | 校验拒绝 | ❌ 需核对号码重传 |
| 姓名含特殊字符 | `吴十${hack}` | 校验拒绝 | ❌ 去除特殊符号后重传 |
| 城市=城市C | `城市C` | 不阻断 | ⚠️ 仍会拨打，但无城市专属时段规则 |

## 执行清单

复制此清单并在执行时逐项确认：

- [ ] 步骤 0: 检查前置条件
  - [ ] 0.1 阿里云凭证文件存在且有效
  - [ ] 0.2 主叫号码（`ALIYUN_CALLER_NUMBER`）已绑定到实例
  - [ ] 0.3 Python 依赖已安装
- [ ] 步骤 1: 读取候选人名单
  - [ ] 1.1 读取 `.dumate/candidates_batch.json`
  - [ ] 1.2 如果文件不存在或为空数组 `[]`，不发起外呼，提醒用户
- [ ] 步骤 2: 执行外呼
  - [ ] 2.1 运行 `batch_call.py --wait`（串行模式，等待每人通话结束）
  - [ ] 2.2 脚本自动过滤已拨打号码（基于 `called_history.json`）
  - [ ] 2.3 脚本自动加载人工占用时段（基于 `manual_booked_slots.json`）
  - [ ] 2.4 脚本自动生成可用时段、推荐日期，传给大模型对话
  - [ ] 2.5 每人通话提交后自动写入 `called_history.json`
- [ ] 步骤 3: 查询结果并导出报告
  - [ ] 3.1 从步骤2输出中获取 JobGroupId
  - [ ] 3.2 运行 `result_query.py <JobGroupId> --export-excel`
  - [ ] 3.3 汇总：成功几人、各预约什么时间、失败几人及原因
- [ ] 步骤 4: 向用户汇报结果

---

### 步骤 0: 检查前置条件

确认以下条件全部满足，否则停止并告知用户：

1. 凭证文件存在：检查 `.dumate/scripts/alibabacloud.properties` 或 `~/.alibabacloud/alibabacloud.properties`
2. 主叫号码已绑定：如脚本输出 `Number not bound`，提示用户去阿里云控制台绑定
3. 依赖已安装：`aliyunsdkcore`、`aliyunsdkoutboundbot`、`openpyxl`

---

### 步骤 1: 读取候选人名单

读取 `.dumate/candidates_batch.json`：

- 如果文件不存在或内容为 `[]`：**不发起外呼**，直接提醒用户"今天没有候选人名单，外呼已跳过。如果需要拨打，请告诉我名单。"
- 如果有候选人：继续步骤2

---

### 步骤 2: 执行外呼

**工作目录**：技能根目录（即 `interview-reminder-agent/`）

**执行命令**：

```bash
python .dumate/scripts/batch_call.py --wait
```

**参数说明**：

| 参数 | 说明 |
|------|------|
| `--wait` | 等待每个候选人通话结束后再拨下一个（串行模式，推荐） |
| `--dry-run` | 空跑，只打印候选人列表不实际拨打 |
| `--force` | 跳过防重复检查，强制拨打（需要对已拨打的人重拨时使用） |
| `--clear-history` | 清空 `called_history.json` 后退出（需要重置时使用） |
| `--candidates <path>` | 指定其他候选人文件路径（默认读取 `candidates_batch.json`） |

**脚本行为**：

1. 加载候选人名单（缺字段用 `.get()` 容错，缺 phone 自动跳过）
2. 加载 `called_history.json`，过滤已拨打号码（打印跳过信息）
3. 加载 `manual_booked_slots.json`，加载人工占用时段
4. 逐个候选人：
   - 数据清洗：自动剥离 `+86 `前缀和 `-`分隔符
   - 输入校验：姓名1-30字符、手机11位、岗位≤100字符
   - 动态计算可用时段（15个工作日 x 6时段，排除已占用）
   - 动态计算推荐日期（3个有空闲的日期）
   - 创建阿里云任务组 + 分配外呼任务（缺字段不 KeyError）
   - 拨打提交成功后写入 `called_history.json`
   - 等待通话完成（`--wait` 模式，超时300秒）
   - 从对话记录提取预约时段（支持阿拉伯数字和中文数字格式）
   - 将预约时段加入已占用列表，传给下一个候选人
   - 间隔30秒再拨下一个
5. 保存结果到 `.dumate/output/batch_call_results.json`
6. 打印汇总：总人数、已预约时段、冲突、未预约

**关键输出**：

```
[1/2] 张三 | 13800138000 | 城市A
  JobGroupId: xxx
  JobId: xxx
  Status: Succeeded
  Booked slot: 8月6日14:30

[2/2] 李四 | 13900139000 | 城市B
  ...
```

---

### 步骤 3: 查询结果并导出报告

**执行命令**（将 `<JobGroupId>` 替换为步骤2中输出的任务组ID）：

```bash
python .dumate/scripts/result_query.py <JobGroupId> --candidates-file .dumate/candidates_batch.json --export-excel
```

**参数说明**：

| 参数 | 说明 |
|------|------|
| `job_group_id` | 位置参数，步骤2输出的任务组ID |
| `--candidates-file` | 候选人文件路径，用于关联姓名 |
| `--export-excel` | 导出Excel报告 |
| `--output-path` | 自定义Excel输出路径（可选） |
| `--screening` | 使用筛选模式解析（大模型对话场景，推荐加上） |

**Excel报告**：`.dumate/output/外呼结果报告.xlsx`

12列结构化数据：

| 列 | 内容 |
|----|------|
| A: 初试时间 | 外呼日期 |
| B: 职位 | 投递岗位 |
| C: 名字 | 候选人姓名 |
| D: 电话 | 手机号 |
| E: 地区 | 意向城市 |
| F: 渠道 | 默认"招聘平台" |
| G: 复试邀约时间 | 已预约显示时段，未预约显示情况说明 |
| H: 是否改约 | 是/否 |
| I: 复试日期 | 日期格式 |
| J: 实习时长 | 从对话中提取 |
| K: 到岗时间 | 从对话中提取 |
| L: 通勤情况 | 方便/不方便/线上面试 |

行颜色：

- 绿色：已预约
- 黄色：未预约
- 红色：时段冲突

---

### 步骤 4: 向用户汇报结果

汇报模板：

```
外呼完成，共拨打 N 人：
- 成功预约：M 人
  - 张三：8月6日 14:30（城市A，线下）
  - 李四：8月7日 15:00（城市B，线上）
- 未预约：K 人
  - 王五：未接通
  - 赵六：号码错误

Excel报告已生成：.dumate/output/外呼结果报告.xlsx
```

## 状态说明

| 状态码 | 中文 | 说明 |
|--------|------|------|
| BOOKED | 已预约 | 成功预约面试时间 |
| WRONG_NUMBER | 号码错误 | 候选人否认身份 |
| NO_INTEREST | 无意向 | 已找到工作/已入职 |
| NEED_HR | 需HR协调 | 提供的时间都不方便 |
| CONSIDERING | 考虑中 | 候选人需要考虑 |
| INTERNSHIP_FAIL | 实习不足 | 实习时长不满足要求 |
| COMMUTE_FAIL | 通勤不便 | 通勤不方便，放弃面试 |
| UNREACHABLE | 未接通 | 电话无人接听/停机/关机 |
| CALLBACK_NEEDED | 需回拨 | 候选人表示不方便接听 |

## 防重复拨打机制

- 每次拨打提交成功后，候选人信息自动写入 `.dumate/called_history.json`
- 下次运行 `batch_call.py` 时自动过滤已拨打号码
- 需要**重拨某人**：`python .dumate/scripts/batch_call.py --force`
- 需要**清空历史**：`python .dumate/scripts/batch_call.py --clear-history`

## 定时任务

当前已配置定时任务（每天 14:00 Asia/Shanghai 自动执行）：

1. 读取 `candidates_batch.json`
2. 如果名单为空，跳过并提醒用户
3. 如果有名单，运行 `batch_call.py --wait`
4. 运行 `result_query.py` 查询结果
5. 汇报外呼结果

用户在前一天口述名单，写入 `candidates_batch.json`，次日14:00自动拨打。

## 注意事项

1. 拨打时间建议在工作日 10:00-17:00，避免打扰候选人
2. 每次拨打前确认 `candidates_batch.json` 格式正确（JSON语法）
3. 导出报告前确保通话已全部结束（脚本输出所有候选人都已处理完）
4. 通话结束后阿里云后台需要1-2分钟同步数据，如查询不到结果请稍等重试
5. 城市A周五只能预约 14:00 和 14:30 两个时段
6. 时段规则：仅工作日，每天 14:00/14:30/15:00/15:30/16:00/16:30
