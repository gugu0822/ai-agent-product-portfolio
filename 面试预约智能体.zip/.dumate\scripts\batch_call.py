# -*- coding: utf-8 -*-
"""
批量外呼脚本 - 二面预约（串行模式）
串行拨打：一个候选人打完 → 解析预约时段 → 传给下一个候选人
确保时段不重复
"""

import json
import os
import sys
import time
import random
import re
from datetime import datetime, timedelta

from aliyunsdkcore.client import AcsClient
from aliyunsdkoutboundbot.request.v20191226 import (
    CreateJobGroupRequest,
    AssignJobsRequest,
    ListJobsRequest,
    DescribeJobGroupRequest,
)

# ========== 配置 ==========
# 阿里云资源ID通过环境变量配置（未设置时为空，运行时会提示配置）
# 凭证文件默认位置：~/.alibabacloud/alibabacloud.properties
CRED_PATH = os.path.join(os.path.expanduser("~"), ".alibabacloud", "alibabacloud.properties")
INSTANCE_ID = os.environ.get("ALIYUN_INSTANCE_ID", "")
SCRIPT_ID = os.environ.get("ALIYUN_SCRIPT_ID", "")
CALLING_NUMBER = os.environ.get("ALIYUN_CALLING_NUMBER", "")
SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
CANDIDATES_FILE = os.path.join(SCRIPTS_DIR, "..", "candidates_batch.json")
MANUAL_BOOKED_FILE = os.path.join(SCRIPTS_DIR, "..", "manual_booked_slots.json")
CALLED_HISTORY_FILE = os.path.join(SCRIPTS_DIR, "..", "called_history.json")
OUTPUT_DIR = os.path.join(SCRIPTS_DIR, "..", "output")

# 每天的标准时段
BASE_SLOT_TIMES = ["14:00", "14:30", "15:00", "15:30", "16:00", "16:30"]

# 2026年法定节假日（不可预约）
HOLIDAYS_2026 = {
    # 元旦
    "2026-01-01",
    # 春节
    "2026-02-15",
    "2026-02-16",
    "2026-02-17",
    "2026-02-18",
    "2026-02-19",
    "2026-02-20",
    "2026-02-21",
    # 清明
    "2026-04-04",
    "2026-04-05",
    "2026-04-06",
    # 劳动节
    "2026-04-30",
    "2026-05-01",
    "2026-05-02",
    "2026-05-03",
    "2026-05-04",
    "2026-05-05",
    # 端午
    "2026-06-19",
    "2026-06-20",
    "2026-06-21",
    # 中秋
    "2026-09-25",
    "2026-09-26",
    "2026-09-27",
    # 国庆
    "2026-10-01",
    "2026-10-02",
    "2026-10-03",
    "2026-10-04",
    "2026-10-05",
    "2026-10-06",
    "2026-10-07",
}

# 2027年法定节假日（年初可能用到的跨年日期）
HOLIDAYS_2027 = {
    # 元旦
    "2027-01-01",
}


def is_holiday(d):
    """检查日期是否是节假日"""
    date_str = d.strftime("%Y-%m-%d")
    if d.year == 2026:
        return date_str in HOLIDAYS_2026
    elif d.year == 2027:
        return date_str in HOLIDAYS_2027
    return False


def is_workday(d):
    """检查是否是工作日（非周末且非节假日）"""
    return d.weekday() < 5 and not is_holiday(d)


def generate_available_dates(num_days=3):
    """
    动态生成可预约日期（和控制台规则一致）：
    跳过当天和下一个工作日，从再下一个工作日起往后推算num个工作日（跳过周末和节假日）。
    """
    today = datetime.now().date()
    dates = []
    current = today

    # 跳过下一个工作日（当天自然不可选，再往后数1个工作日也不可选）
    skipped = 0
    while skipped < 1:
        current = current + timedelta(days=1)
        if is_workday(current):
            skipped += 1

    # 从current的下一个日期开始找num_days个可选工作日
    current = current + timedelta(days=1)
    while len(dates) < num_days:
        if is_workday(current):
            dates.append(current)
        current = current + timedelta(days=1)

    return dates


def generate_available_dates_extended(num_days=15):
    """
    生成从明天起往后num_days个工作日的日期列表（跳过周末和节假日）。
    用于availableSlots变量，作为大模型的后台时段参考池。
    """
    today = datetime.now().date()
    dates = []
    current = today + timedelta(days=1)
    while len(dates) < num_days:
        if is_workday(current):
            dates.append(current)
        current = current + timedelta(days=1)
    return dates


def generate_all_slots():
    """根据当前日期动态生成ALL_SLOTS字典"""
    dates = generate_available_dates()
    slots = {}
    for d in dates:
        date_key = f"{d.month}月{d.day}日"
        slots[date_key] = list(BASE_SLOT_TIMES)
    return slots


# 运行时动态生成
ALL_SLOTS = generate_all_slots()


def is_friday(date_str):
    """检查日期字符串（如'7月18日'）是否是周五"""
    now = datetime.now()
    for year in [now.year, now.year + 1]:
        try:
            d = datetime.strptime(f"{year}年{date_str}", "%Y年%m月%d日").date()
            return d.weekday() == 4  # 周五
        except ValueError:
            continue
    return False


def get_available_slots_for_city(city, date, booked_slots):
    """获取指定城市+日期的可用时段（排除已占用）"""
    base_slots = ALL_SLOTS.get(date, list(BASE_SLOT_TIMES))

    # 城市A周五只能14:00和14:30
    if city == "城市A" and is_friday(date):
        base_slots = ["14:00", "14:30"]

    # 排除已占用的
    available = []
    for slot in base_slots:
        slot_key = f"{date}{slot}"
        if slot_key not in booked_slots:
            available.append(slot)

    return available


def compute_available_slots_str(city, booked_slots):
    """
    动态计算当前可用时段字符串，传给大模型作为 availableSlots 变量。
    生成从明天起往后15个工作日 × 每天时段 → 城市A周五砍到2个 → 排除已占用 → 格式化输出
    """
    dates = generate_available_dates_extended(15)
    parts = []
    for d in dates:
        date_key = f"{d.month}月{d.day}日"
        slots = list(BASE_SLOT_TIMES)

        # 城市A周五只能14:00和14:30
        if city == "城市A" and d.weekday() == 4:
            slots = ["14:00", "14:30"]

        # 排除已占用
        for slot in list(slots):
            slot_key = f"{date_key}{slot}"
            if slot_key in booked_slots:
                slots.remove(slot)

        # 只保留还有空闲时段的日期
        if slots:
            parts.append(f"{date_key}（{'、'.join(slots)}）")

    if parts:
        return "；".join(parts)
    else:
        return "暂无"


def compute_recommended_dates_str(city, booked_slots):
    """
    计算推荐给候选人的3个可预约日期字符串，传给大模型作为 recommendedDates 变量。
    跳过当天和下一个工作日，从再下一个工作日起往后推算工作日（跳过周末和节假日），
    排除已约满的日期，直到找到3个还有空闲时段的日期。
    """
    dates = generate_available_dates_extended(15)
    result = []
    for d in dates:
        date_key = f"{d.month}月{d.day}日"
        slots = list(BASE_SLOT_TIMES)

        # 城市A周五只能14:00和14:30
        if city == "城市A" and d.weekday() == 4:
            slots = ["14:00", "14:30"]

        # 排除已占用
        for slot in list(slots):
            slot_key = f"{date_key}{slot}"
            if slot_key in booked_slots:
                slots.remove(slot)

        # 只要有空闲时段就加入推荐
        if slots:
            result.append(date_key)
        if len(result) >= 3:
            break

    return "、".join(result) if result else "暂无"


def load_called_history():
    """加载已拨打号码历史记录"""
    if not os.path.exists(CALLED_HISTORY_FILE):
        return []
    try:
        with open(CALLED_HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, TypeError) as e:
        print(f"[WARN] Failed to load called_history.json: {e}")
        return []


def append_called_history(candidate, job_id, jg_id):
    """将已拨打候选人追加到历史记录"""
    history = load_called_history()
    entry = {
        "phone": candidate.get("phone", ""),
        "name": candidate.get("name", ""),
        "position": candidate.get("position", ""),
        "city": candidate.get("city", ""),
        "job_id": job_id,
        "job_group_id": jg_id,
        "called_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    history.append(entry)
    with open(CALLED_HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)


def get_client():
    with open(CRED_PATH, "r") as f:
        creds = json.load(f)
    return AcsClient(creds["access_key_id"], creds["access_key_secret"], "cn-shanghai")


def create_and_call_one(
    client,
    candidate,
    booked_slots_str,
    available_slots_str,
    recommended_dates_str,
    job_name,
):
    """创建单个外呼任务并拨打"""
    # 1. 创建任务组
    req = CreateJobGroupRequest.CreateJobGroupRequest()
    req.set_InstanceId(INSTANCE_ID)
    req.set_ScriptId(SCRIPT_ID)
    req.set_JobGroupName(job_name)
    req.set_ScenarioId(SCRIPT_ID)
    req.set_CallingNumbers([CALLING_NUMBER])
    req.set_RingingDuration(30)
    resp = client.do_action_with_exception(req)
    data = json.loads(resp)
    jg = data.get("JobGroup", {})
    jg_id = jg.get("JobGroupId")
    calling_numbers = jg.get("CallingNumbers", [])

    if not calling_numbers or CALLING_NUMBER not in calling_numbers:
        print(f"  [ERROR] Number not bound!")
        return None, None

    # 2. 分配号码
    c_name = candidate.get("name", "unknown")
    c_phone = candidate.get("phone", "")
    c_position = candidate.get("position", "")
    c_city = candidate.get("city", "")

    if not c_phone:
        print("  [ERROR] Missing phone number, skipping")
        return None, None

    job = {
        "contacts": [
            {
                "phoneNumber": c_phone,
                "name": c_name,
                "referenceId": c_phone,
                "role": "candidate",
                "honorific": "",
            }
        ],
        "extras": [
            {"key": "candidateName", "value": c_name},
            {"key": "positionName", "value": c_position},
            {"key": "candidateCity", "value": c_city},
            {"key": "bookedSlots", "value": booked_slots_str},
            {"key": "currentDate", "value": datetime.now().strftime("%Y年%m月%d日")},
            {"key": "availableSlots", "value": available_slots_str},
            {"key": "recommendedDates", "value": recommended_dates_str},
        ],
    }

    req2 = AssignJobsRequest.AssignJobsRequest()
    req2.set_InstanceId(INSTANCE_ID)
    req2.set_JobGroupId(jg_id)
    req2.set_JobsJsons([json.dumps(job, ensure_ascii=False)])
    resp2 = client.do_action_with_exception(req2)
    data2 = json.loads(resp2)
    job_ids = data2.get("JobsId", [])

    return jg_id, job_ids


def wait_for_job(client, job_id, timeout=300):
    """等待单个任务完成"""
    start = time.time()
    while time.time() - start < timeout:
        req = ListJobsRequest.ListJobsRequest()
        req.set_InstanceId(INSTANCE_ID)
        req.set_JobIds([job_id])
        resp = client.do_action_with_exception(req)
        data = json.loads(resp)
        jobs = data.get("Jobs", [])
        if jobs:
            job = jobs[0]
            status = job.get("Status", "")
            if status in ("Succeeded", "Failed", "Completed"):
                return job
        time.sleep(10)
    return None


def extract_booked_slot(job):
    """从通话记录中提取预约的时段（只匹配最终确认语句）"""
    tasks = job.get("Tasks", [])
    for task in tasks:
        conv = task.get("Conversation", [])

        # 从后往前找，优先匹配最后的确认语句
        for msg in reversed(conv):
            if msg.get("Speaker") != "Robot":
                continue
            text = msg.get("Script", "")

            # 只匹配确认预约的语句，不匹配"可预约"等推荐语句
            if "已为您预约" not in text and "已预约" not in text:
                continue

            # 中文数字映射
            CN_NUM_MAP = {
                "零": 0, "〇": 0, "一": 1, "二": 2, "两": 2,
                "三": 3, "四": 4, "五": 5, "六": 6, "七": 7,
                "八": 8, "九": 9, "十": 10,
            }

            def _cn_to_int(s):
                """中文数字转int，支持'十五''三十''一五'等"""
                if s.isdigit():
                    return int(s)
                if "十" in s:
                    parts = s.split("十")
                    tens = CN_NUM_MAP.get(parts[0], 1) if parts[0] else 1
                    ones = CN_NUM_MAP.get(parts[1], 0) if len(parts) > 1 and parts[1] else 0
                    return tens * 10 + ones
                val = 0
                for ch in s:
                    if ch in CN_NUM_MAP:
                        val = val * 10 + CN_NUM_MAP[ch]
                    elif ch.isdigit():
                        val = val * 10 + int(ch)
                return val

            # 匹配日期：支持阿拉伯数字和中文数字，带年份和不带年份，支持"日"和"号"
            # 先尝试阿拉伯数字
            date_match = re.search(r"(?:\d{4}年)?(\d{1,2})月(\d{1,2})[日号]", text)
            if date_match:
                month = date_match.group(1)
                day = date_match.group(2)
            else:
                # 中文数字兜底：(?:[一二两三四五六七八九十〇零]{1,3})月([一二两三四五六七八九十〇零]{1,3})[日号]
                cn_date_match = re.search(
                    r"(?:\d{4}年)?([一二两三四五六七八九十]{1,3})月([一二两三四五六七八九十]{1,3})[日号]",
                    text,
                )
                if not cn_date_match:
                    continue
                month = str(_cn_to_int(cn_date_match.group(1)))
                day = str(_cn_to_int(cn_date_match.group(2)))

            date_str = f"{month}月{day}日"

            # 匹配时间，按优先级依次尝试：
            #   1. HH:MM 或 H：MM（冒号分隔）
            #   2. H点M分 / H点MM（点+数字）
            #   3. H点半
            #   4. H点（纯小时，无分钟）
            #   5. 中文数字兜底：一五点三零、十四点三十 等
            CN_NUM = {
                "零": 0,
                "〇": 0,
                "一": 1,
                "二": 2,
                "两": 2,
                "三": 3,
                "四": 4,
                "五": 5,
                "六": 6,
                "七": 7,
                "八": 8,
                "九": 9,
                "十": 10,
            }

            def cn_to_int(s):
                """中文数字转int，支持'十五''三十''一五'等"""
                if s.isdigit():
                    return int(s)
                if "十" in s:
                    parts = s.split("十")
                    tens = CN_NUM.get(parts[0], 1) if parts[0] else 1
                    ones = CN_NUM.get(parts[1], 0) if len(parts) > 1 and parts[1] else 0
                    return tens * 10 + ones
                # 逐字转换（一五→15）
                val = 0
                for ch in s:
                    if ch in CN_NUM:
                        val = val * 10 + CN_NUM[ch]
                    elif ch.isdigit():
                        val = val * 10 + int(ch)
                return val

            time_match = re.search(r"(\d{1,2})[:：](\d{1,2})", text)
            if not time_match:
                time_match = re.search(r"(\d{1,2})点(\d{1,2})\s*分?", text)
            if not time_match:
                time_match = re.search(r"(\d{1,2})点半", text)
            if not time_match:
                time_match = re.search(r"(\d{1,2})点(?!\d|半|分)", text)

            # 中文数字兜底
            if not time_match:
                cn_match = re.search(
                    r"([一二两三四五六七八九零〇十]{1,3})点([一二两三四五六七八九零〇十]{1,3})\s*分?",
                    text,
                )
                if cn_match:
                    hour = cn_to_int(cn_match.group(1))
                    minute = cn_to_int(cn_match.group(2))
                    if "下午" in text and hour < 12:
                        hour += 12
                    slot_str = f"{hour:02d}:{minute:02d}"
                    return f"{date_str}{slot_str}"

            # 中文数字 + 整/半
            if not time_match:
                cn_half = re.search(r"([一二两三四五六七八九零〇十]{1,3})点半", text)
                if cn_half:
                    hour = cn_to_int(cn_half.group(1))
                    if "下午" in text and hour < 12:
                        hour += 12
                    slot_str = f"{hour:02d}:30"
                    return f"{date_str}{slot_str}"
                cn_whole = re.search(r"([一二两三四五六七八九零〇十]{1,3})点整", text)
                if cn_whole:
                    hour = cn_to_int(cn_whole.group(1))
                    if "下午" in text and hour < 12:
                        hour += 12
                    slot_str = f"{hour:02d}:00"
                    return f"{date_str}{slot_str}"

            if time_match:
                hour = int(time_match.group(1))
                if (
                    time_match.lastindex >= 2
                    and time_match.group(2)
                    and time_match.group(2).isdigit()
                ):
                    minute = int(time_match.group(2))
                elif "点半" in text:
                    minute = 30
                else:
                    minute = 0

                # 下午补12
                if "下午" in text and hour < 12:
                    hour += 12

                slot_str = f"{hour:02d}:{minute:02d}"
                return f"{date_str}{slot_str}"
            else:
                # 只有日期没有时间也返回
                return date_str

    return None


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Batch outbound call (serial mode)")
    parser.add_argument(
        "--candidates", default=CANDIDATES_FILE, help="Candidates JSON file"
    )
    parser.add_argument(
        "--wait", action="store_true", help="Wait for each call to complete"
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Dry run, no actual calls"
    )
    parser.add_argument(
        "--force", action="store_true", help="Skip dedup check, call even if already called"
    )
    parser.add_argument(
        "--clear-history", action="store_true", help="Clear called_history.json and exit"
    )
    args = parser.parse_args()

    # --clear-history: 清空历史记录后退出
    if args.clear_history:
        if os.path.exists(CALLED_HISTORY_FILE):
            os.remove(CALLED_HISTORY_FILE)
            print(f"Cleared: {CALLED_HISTORY_FILE}")
        else:
            print("No history file to clear.")
        return

    client = get_client()

    # 读取候选人
    with open(args.candidates, "r", encoding="utf-8") as f:
        candidates = json.load(f)

    # 防重复拨打：过滤已拨打号码（--force 跳过）
    called_phones = set()
    if not args.force:
        history = load_called_history()
        called_phones = {h["phone"] for h in history if h.get("phone")}
        if called_phones:
            skipped = [c for c in candidates if c.get("phone") in called_phones]
            candidates = [c for c in candidates if c.get("phone") not in called_phones]
            if skipped:
                print(f"[DEDUP] Skipped {len(skipped)} already-called candidate(s):")
                for c in skipped:
                    print(f"  - {c['name']} | {c['phone']} (already called)")

    print(f"=== Batch Outbound Call (Serial Mode) ===")
    print(f"Candidates: {len(candidates)}")
    if called_phones and not args.force:
        print(f"Already called (in history): {len(called_phones)}")
    print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()

    if not candidates:
        print("[INFO] No candidates to call (all already called or list is empty).")
        return

    if args.dry_run:
        print("[DRY RUN] No actual calls will be made")
        for c in candidates:
            print(f"  {c.get('name','?')} | {c.get('phone','?')} | {c.get('position','?')} | {c.get('city','?')}")
        return

    booked_slots = []  # 已占用时段列表

    # 读取人工已占用时段
    if os.path.exists(MANUAL_BOOKED_FILE):
        try:
            with open(MANUAL_BOOKED_FILE, "r", encoding="utf-8") as f:
                manual_slots = json.load(f)
            if manual_slots:
                booked_slots.extend(manual_slots)
                print(f"Manual booked slots loaded: {len(manual_slots)}")
                for s in manual_slots:
                    print(f"  - {s}")
        except (json.JSONDecodeError, TypeError) as e:
            print(f"[WARN] Failed to load manual_booked_slots.json: {e}")

    results = []  # 所有候选人结果

    for idx, candidate in enumerate(candidates, 1):
        name = candidate.get("name", "unknown")
        phone = candidate.get("phone", "")
        city = candidate.get("city", "")
        position = candidate.get("position", "")

        if not phone:
            print(f"\n[{idx}/{len(candidates)}] SKIP: missing phone")
            results.append({
                "candidate": candidate,
                "status": "Failed",
                "reason": "Missing phone",
                "job_group_id": None,
                "booked_slot": None,
            })
            continue

        print(f"\n{'=' * 50}")
        print(f"[{idx}/{len(candidates)}] {name} | {phone} | {city}")
        print(f"{'=' * 50}")

        # 已占用时段字符串
        if booked_slots:
            booked_str = "、".join(booked_slots)
        else:
            booked_str = "暂无"
        print(f"  Booked slots: {booked_str}")

        # 动态计算可用时段
        available_str = compute_available_slots_str(city, booked_slots)
        print(f"  Available slots: {available_str}")

        # 动态计算推荐日期（排除已约满）
        recommended_str = compute_recommended_dates_str(city, booked_slots)
        print(f"  Recommended dates: {recommended_str}")

        # 创建并拨打
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        jg_name = f"interview-{name}-{timestamp}"

        jg_id, job_ids = create_and_call_one(
            client, candidate, booked_str, available_str, recommended_str, jg_name
        )

        if not jg_id or not job_ids:
            print(f"  [FAIL] Failed to create call")
            results.append(
                {
                    "candidate": candidate,
                    "status": "Failed",
                    "reason": "Create call failed",
                    "job_group_id": jg_id,
                    "booked_slot": None,
                }
            )
            continue

        # 拨打提交成功，写入历史记录
        append_called_history(candidate, job_ids[0], jg_id)

        print(f"  JobGroupId: {jg_id}")
        print(f"  JobId: {job_ids[0]}")
        print(f"  Calling... (waiting for completion)")

        if args.wait:
            # 等待完成
            job = wait_for_job(client, job_ids[0], timeout=300)
            if job:
                status = job.get("Status", "")
                print(f"  Status: {status}")

                # 提取通话详情
                tasks = job.get("Tasks", [])
                call_duration = 0
                conversation = []
                for t in tasks:
                    call_duration = t.get("Duration", 0)
                    conversation = t.get("Conversation", [])
                    print(f"  Duration: {call_duration}ms")
                    print(f"  Conversation turns: {len(conversation)}")

                # 尝试提取预约时段
                booked_slot = extract_booked_slot(job)
                slot_conflict = False
                if booked_slot:
                    # 校验：检查是否和已占用时段重复
                    if booked_slot in booked_slots:
                        slot_conflict = True
                        print(
                            f"  [WARNING] Slot conflict: {booked_slot} already booked!"
                        )
                    else:
                        booked_slots.append(booked_slot)
                        print(f"  Booked slot: {booked_slot}")
                else:
                    print(f"  No slot extracted from conversation")

                results.append(
                    {
                        "candidate": candidate,
                        "status": status,
                        "call_duration": call_duration,
                        "conversation": conversation,
                        "job_group_id": jg_id,
                        "job_id": job_ids[0],
                        "booked_slot": booked_slot,
                        "slot_conflict": slot_conflict,
                    }
                )
            else:
                print(f"  [TIMEOUT] Job not completed in 300s")
                results.append(
                    {
                        "candidate": candidate,
                        "status": "Timeout",
                        "job_group_id": jg_id,
                        "job_id": job_ids[0],
                        "booked_slot": None,
                    }
                )
        else:
            results.append(
                {
                    "candidate": candidate,
                    "status": "Submitted",
                    "job_group_id": jg_id,
                    "job_id": job_ids[0],
                    "booked_slot": None,
                }
            )
            print(f"  Submitted (not waiting)")

        # 间隔30秒再打下一个
        if idx < len(candidates):
            print(f"\n  Waiting 30s before next call...")
            time.sleep(30)

    # 保存结果（固定文件名，每次自动覆盖）
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    result_file = os.path.join(OUTPUT_DIR, "batch_call_results.json")

    # 序列化时去掉conversation（太大）
    summary = []
    for r in results:
        s = {k: v for k, v in r.items() if k != "conversation"}
        s["conversation_turns"] = len(r.get("conversation", []))
        summary.append(s)

    with open(result_file, "w", encoding="utf-8") as f:
        json.dump(
            {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "total": len(candidates),
                "booked_slots": booked_slots,
                "conflicts": [
                    {
                        "name": r["candidate"]["name"],
                        "phone": r["candidate"]["phone"],
                        "slot": r["booked_slot"],
                    }
                    for r in results
                    if r.get("slot_conflict")
                ],
                "no_slot": [
                    {
                        "name": r["candidate"]["name"],
                        "phone": r["candidate"]["phone"],
                        "status": r["status"],
                    }
                    for r in results
                    if not r.get("booked_slot")
                ],
                "results": summary,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    print(f"\n{'=' * 50}")
    print(f"=== Summary ===")
    print(f"{'=' * 50}")
    print(f"Total: {len(candidates)}")
    print(f"Booked slots: {booked_slots}")

    # 校验报告
    conflicts = [r for r in results if r.get("slot_conflict")]
    no_slot = [r for r in results if not r.get("booked_slot")]
    if conflicts:
        print(f"\n[WARNING] Slot conflicts ({len(conflicts)}):")
        for r in conflicts:
            c = r["candidate"]
            print(f"  - {c['name']} | {c['phone']} | {r['booked_slot']} (DUPLICATE)")
    if no_slot:
        print(f"\n[WARNING] No slot booked ({len(no_slot)}):")
        for r in no_slot:
            c = r["candidate"]
            print(f"  - {c['name']} | {c['phone']} | status={r['status']}")

    print(f"\nResults saved: {result_file}")


if __name__ == "__main__":
    main()
