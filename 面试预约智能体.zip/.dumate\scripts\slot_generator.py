# -*- coding: utf-8 -*-
"""
面试提醒Agent - 预设时段表生成模块

生成可用于面试预约的时间段列表。
时段规则：
  - 仅工作日（周一到周五）
  - 下午时段：14:00、15:00、16:00（每天3个）
  - 从明天开始往后生成 num_days 个工作日
  - 跳过周末

生成结果作为变量传入阿里云大模型对话流，LLM从中匹配候选人的面试时间。
"""
import os
import sys
from datetime import datetime, timedelta
from typing import List, Dict

_current_dir = os.path.dirname(os.path.abspath(__file__))
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)

from config import SCREENING_SLOT_TIMES

# 星期名称映射
WEEKDAY_NAMES = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
WEEKDAY_SHORT = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]


def generate_slots(
    num_days: int = 5,
    start_date: str = None,
    slot_times: List[str] = None
) -> List[Dict]:
    """
    生成可用面试时段列表
    
    Args:
        num_days: 生成多少个工作日的时段（默认5天）
        start_date: 起始日期 "YYYY-MM-DD"（默认从明天开始）
        slot_times: 每天的时段列表（默认从config读取）
    
    Returns:
        [
            {
                "date": "2026-07-16",
                "weekday": "周四",
                "weekday_full": "星期四",
                "slots": ["14:00", "15:00", "16:00"],
                "slots_cn": ["下午2点", "下午3点", "下午4点"]
            },
            ...
        ]
    """
    if slot_times is None:
        slot_times = SCREENING_SLOT_TIMES
    
    if start_date:
        try:
            current = datetime.strptime(start_date, "%Y-%m-%d").date()
        except ValueError:
            current = datetime.now().date() + timedelta(days=1)
    else:
        current = datetime.now().date() + timedelta(days=1)
    
    slots_data = []
    days_found = 0
    max_attempts = num_days * 3  # 防止无限循环
    
    for _ in range(max_attempts):
        if days_found >= num_days:
            break
        
        weekday = current.weekday()
        if weekday < 5:  # 周一到周五
            slots_data.append({
                "date": current.strftime("%Y-%m-%d"),
                "weekday": WEEKDAY_SHORT[weekday],
                "weekday_full": WEEKDAY_NAMES[weekday],
                "slots": list(slot_times),
                "slots_cn": [_time_to_cn(s) for s in slot_times],
            })
            days_found += 1
        
        current += timedelta(days=1)
    
    return slots_data


def _time_to_cn(time_str: str) -> str:
    """
    将 "14:00" 转为 "下午2点"，"15:30" 转为 "下午3点30分"
    """
    try:
        parts = time_str.split(":")
        hour = int(parts[0])
        minute = int(parts[1]) if len(parts) > 1 else 0
        
        if hour >= 12:
            period = "下午"
            display_hour = hour - 12 if hour > 12 else 12
        else:
            period = "上午"
            display_hour = hour if hour > 0 else 12
        
        if minute == 0:
            return f"{period}{display_hour}点"
        else:
            return f"{period}{display_hour}点{minute}分"
    except (ValueError, IndexError):
        return time_str


def format_slots_for_display(slots_data: List[Dict]) -> str:
    """
    格式化为人类可读的文本（用于控制台打印）
    
    示例：
    7月16日(周四): 下午2点、下午3点、下午4点
    7月17日(周五): 下午2点、下午3点、下午4点
    """
    lines = []
    for day in slots_data:
        date_parts = day["date"].split("-")
        month = int(date_parts[1])
        day_num = int(date_parts[2])
        slots_text = "、".join(day["slots_cn"])
        lines.append(f"{month}月{day_num}日({day['weekday']}): {slots_text}")
    return "\n".join(lines)


def format_slots_for_prompt(slots_data: List[Dict]) -> str:
    """
    格式化为阿里云大模型prompt中使用的文本
    与 system_prompt.format_available_slots 功能相同
    """
    return format_slots_for_display(slots_data)


def count_total_slots(slots_data: List[Dict]) -> int:
    """统计总时段数"""
    return sum(len(day["slots"]) for day in slots_data)


# ========== 测试 ==========

if __name__ == "__main__":
    print("=" * 60)
    print("  预设时段表生成模块测试")
    print("=" * 60)
    
    slots_data = generate_slots(num_days=5)
    
    print(f"\n生成 {len(slots_data)} 个工作日的时段:")
    print(f"总时段数: {count_total_slots(slots_data)}")
    print()
    print(format_slots_for_display(slots_data))
    
    # 测试指定起始日期
    print(f"\n--- 指定起始日期 2026-07-20(周一) ---")
    slots2 = generate_slots(num_days=3, start_date="2026-07-20")
    print(format_slots_for_display(slots2))
    
    # 测试自定义时段
    print(f"\n--- 自定义时段 ['10:00', '14:00', '15:00'] ---")
    slots3 = generate_slots(num_days=2, slot_times=["10:00", "14:00", "15:00"])
    print(format_slots_for_display(slots3))
    
    # 测试时间转中文
    print(f"\n--- 时间转中文测试 ---")
    test_times = ["10:00", "11:30", "12:00", "14:00", "15:30", "17:00", "09:00"]
    for t in test_times:
        print(f"  {t} -> {_time_to_cn(t)}")
    
    print(f"\n{'='*60}")
