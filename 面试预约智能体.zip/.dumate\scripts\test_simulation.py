# -*- coding: utf-8 -*-
"""
模拟10组HR给数据的场景测试
不实际拨打，测试：数据校验、防重复、时段生成、时段解析、去重逻辑
"""
import json
import os
import sys
import re
from datetime import datetime, timedelta

SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPTS_DIR)

from validator import (
    validate_phone, validate_name, validate_position,
    CandidateValidationError, validate_screening_candidate,
)
from batch_call import (
    generate_available_dates, generate_available_dates_extended,
    compute_available_slots_str, compute_recommended_dates_str,
    extract_booked_slot, is_friday, is_holiday, is_workday,
    BASE_SLOT_TIMES, ALL_SLOTS,
)

# ========== 10组HR口述场景 ==========
TEST_SCENARIOS = [
    {
        "id": 1,
        "desc": "标准数据 - 城市A",
        "data": {"name": "张三", "phone": "13800138000", "position": "产品实习生", "city": "城市A"},
        "expect": "pass",
    },
    {
        "id": 2,
        "desc": "标准数据 - 城市B",
        "data": {"name": "李四", "phone": "15912345678", "position": "新媒体运营实习生", "city": "城市B"},
        "expect": "pass",
    },
    {
        "id": 3,
        "desc": "手机号带分隔符",
        "data": {"name": "王五", "phone": "138-0013-8000", "position": "前端开发实习生", "city": "城市A"},
        "expect": "pass",
    },
    {
        "id": 4,
        "desc": "手机号带+86前缀",
        "data": {"name": "赵六", "phone": "+86 13900139000", "position": "数据分析实习生", "city": "城市B"},
        "expect": "pass",
    },
    {
        "id": 5,
        "desc": "姓名含空格(少数民族名)",
        "data": {"name": "买买提 依明", "phone": "13700137000", "position": "测试实习生", "city": "城市A"},
        "expect": "pass",
    },
    {
        "id": 6,
        "desc": "岗位名超长(101字符)",
        "data": {"name": "钱七", "phone": "13600136000", "position": "A" * 101, "city": "城市A"},
        "expect": "fail",
    },
    {
        "id": 7,
        "desc": "手机号10位(过短)",
        "data": {"name": "孙八", "phone": "1380013800", "position": "产品实习生", "city": "城市B"},
        "expect": "fail",
    },
    {
        "id": 8,
        "desc": "城市不是城市A/城市B(但batch_call不校验城市)",
        "data": {"name": "周九", "phone": "13500135000", "position": "运营实习生", "city": "城市C"},
        "expect": "pass_with_warn",
    },
    {
        "id": 9,
        "desc": "姓名含特殊字符${}",
        "data": {"name": "吴十${hack}", "phone": "13400134000", "position": "开发实习生", "city": "城市A"},
        "expect": "fail",
    },
    {
        "id": 10,
        "desc": "重复手机号(防重复测试)",
        "data": {"name": "郑十一", "phone": "13800138000", "position": "设计实习生", "city": "城市B"},
        "expect": "dedup",
    },
]

# ========== 模拟对话记录(测试extract_booked_slot) ==========
MOCK_CONVERSATIONS = [
    {
        "id": "conv1",
        "desc": "标准确认: 已为您预约8月6日14:30",
        "conversation": [
            {"Speaker": "Robot", "Script": "您好，请问是张三吗？"},
            {"Speaker": "Contact", "Script": "是我"},
            {"Speaker": "Robot", "Script": "好的，已为您预约8月6日14:30，请准时参加。"},
        ],
        "expect_slot": "8月6日14:30",
    },
    {
        "id": "conv2",
        "desc": "中文数字: 已为您预约八月六日下午两点半",
        "conversation": [
            {"Speaker": "Robot", "Script": "已为您预约八月六日下午两点半"},
        ],
        "expect_slot": "8月6日14:30",
    },
    {
        "id": "conv3",
        "desc": "带年份: 已预约2026年8月6日14:00",
        "conversation": [
            {"Speaker": "Robot", "Script": "已为您预约2026年8月6日14:00"},
        ],
        "expect_slot": "8月6日14:00",
    },
    {
        "id": "conv4",
        "desc": "用'号'不用'日': 已预约8月6号15:00",
        "conversation": [
            {"Speaker": "Robot", "Script": "已预约8月6号15:00"},
        ],
        "expect_slot": "8月6日15:00",
    },
    {
        "id": "conv5",
        "desc": "下午3点(无分钟): 已预约8月7日下午3点",
        "conversation": [
            {"Speaker": "Robot", "Script": "已为您预约8月7日下午3点"},
        ],
        "expect_slot": "8月7日15:00",
    },
    {
        "id": "conv6",
        "desc": "未预约(号码错误)",
        "conversation": [
            {"Speaker": "Robot", "Script": "您好，请问是张三吗？"},
            {"Speaker": "Contact", "Script": "打错了"},
            {"Speaker": "Robot", "Script": "抱歉打扰了，再见。"},
        ],
        "expect_slot": None,
    },
    {
        "id": "conv7",
        "desc": "十六点三零(中文数字逐字)",
        "conversation": [
            {"Speaker": "Robot", "Script": "已为您预约8月7日十六点三零"},
        ],
        "expect_slot": "8月7日16:30",
    },
    {
        "id": "conv8",
        "desc": "两点半(中文数字+下午)",
        "conversation": [
            {"Speaker": "Robot", "Script": "已预约8月8日下午两点半"},
        ],
        "expect_slot": "8月8日14:30",
    },
    {
        "id": "conv9",
        "desc": "只有日期没有时间",
        "conversation": [
            {"Speaker": "Robot", "Script": "已为您预约8月8日"},
        ],
        "expect_slot": "8月8日",
    },
    {
        "id": "conv10",
        "desc": "推荐语句误匹配测试(不应匹配)",
        "conversation": [
            {"Speaker": "Robot", "Script": "您可以预约8月9日14:00或15:00，请问哪个时间方便？"},
            {"Speaker": "Contact", "Script": "14点吧"},
            {"Speaker": "Robot", "Script": "好的，已为您预约8月9日14:00。"},
        ],
        "expect_slot": "8月9日14:00",
    },
]


def print_header(title):
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}")


def run_scenario_tests():
    """测试10组HR数据的校验"""
    print_header("Part 1: HR数据校验测试 (10组)")
    
    passed = 0
    failed = 0
    warned = 0
    
    seen_phones = set()
    
    for s in TEST_SCENARIOS:
        sid = s["id"]
        desc = s["desc"]
        data = s["data"]
        expect = s["expect"]
        
        print(f"\n--- Scenario {sid}: {desc} ---")
        print(f"  Input: name={data.get('name', 'N/A')}, phone={data.get('phone', 'N/A')}, "
              f"position={data.get('position', 'N/A')[:20]}, city={data.get('city', 'N/A')}")
        
        # 防重复检测
        phone_clean = re.sub(r'[^\d]', '', str(data.get("phone", "")))
        if len(phone_clean) > 11 and phone_clean.startswith("86"):
            phone_clean = phone_clean[2:]
        
        if phone_clean in seen_phones and expect == "dedup":
            print(f"  [PASS] Dedup: phone {phone_clean} already seen, would be skipped")
            passed += 1
            continue
        
        # 校验
        try:
            validated = validate_screening_candidate(data)
            
            # 检查城市
            city = validated.get("city", "")
            if city not in ("城市A", "城市B"):
                print(f"  [WARN] City '{city}' is not Xi'an or Changsha - batch_call will still call but city-specific rules won't apply")
                warned += 1
            else:
                print(f"  [PASS] Validated: name={validated['name']}, phone={validated['phone']}, "
                      f"position={validated['position'][:20]}, city={city}")
                passed += 1
            
            seen_phones.add(validated["phone"])
            
        except CandidateValidationError as e:
            if expect == "fail":
                print(f"  [PASS] Expected validation error: {str(e)[:80]}")
                passed += 1
            else:
                print(f"  [FAIL] Unexpected validation error: {str(e)[:80]}")
                failed += 1
    
    print(f"\n--- Summary: {passed} passed, {warned} warned, {failed} failed ---")
    return passed, warned, failed


def run_conversation_tests():
    """测试对话记录中提取预约时段"""
    print_header("Part 2: 对话记录时段提取测试 (10组)")
    
    passed = 0
    failed = 0
    
    for mc in MOCK_CONVERSATIONS:
        mid = mc["id"]
        desc = mc["desc"]
        conv = mc["conversation"]
        expect_slot = mc["expect_slot"]
        
        print(f"\n--- {mid}: {desc} ---")
        
        # 构造模拟job
        mock_job = {"Tasks": [{"Conversation": conv}]}
        
        try:
            result = extract_booked_slot(mock_job)
            
            if result == expect_slot:
                print(f"  [PASS] Extracted: '{result}'")
                passed += 1
            else:
                print(f"  [FAIL] Expected: '{expect_slot}', Got: '{result}'")
                failed += 1
        except Exception as e:
            if expect_slot is None:
                print(f"  [PASS] No slot extracted (expected None): {e}")
                passed += 1
            else:
                print(f"  [FAIL] Exception: {e}")
                failed += 1
    
    print(f"\n--- Summary: {passed} passed, {failed} failed ---")
    return passed, failed


def run_slot_generation_tests():
    """测试时段生成逻辑"""
    print_header("Part 3: 时段生成与去重测试")
    
    # 3.1 基本时段生成
    print("\n--- 3.1 推荐日期生成(跳过当天+下一工作日) ---")
    dates = generate_available_dates(3)
    today = datetime.now().date()
    for d in dates:
        wd = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][d.weekday()]
        print(f"  {d} ({wd}) - is_workday={is_workday(d)}, is_holiday={is_holiday(d)}")
        if d <= today + timedelta(days=1):
            print(f"  [WARN] Date {d} should be skipped (too soon)")
    
    # 3.2 availableSlots生成
    print("\n--- 3.2 availableSlots (城市A, 无已占用) ---")
    slots_str = compute_available_slots_str("城市A", [])
    print(f"  {slots_str[:200]}...")
    
    # 3.3 availableSlots生成 - 城市B
    print("\n--- 3.3 availableSlots (城市B, 无已占用) ---")
    slots_str_cs = compute_available_slots_str("城市B", [])
    print(f"  {slots_str_cs[:200]}...")
    
    # 3.4 排除已占用时段
    print("\n--- 3.4 availableSlots (城市A, 已占用第一个日期的第一个时段) ---")
    first_date_key = f"{dates[0].month}月{dates[0].day}日"
    booked = [f"{first_date_key}14:00"]
    slots_str_booked = compute_available_slots_str("城市A", booked)
    if f"{first_date_key}（14:00" in slots_str_booked:
        print(f"  [FAIL] Booked slot {first_date_key}14:00 still appears in available slots!")
    else:
        print(f"  [PASS] Booked slot {first_date_key}14:00 correctly excluded")
    print(f"  First 200 chars: {slots_str_booked[:200]}...")
    
    # 3.5 推荐日期
    print("\n--- 3.5 recommendedDates (城市A, 无已占用) ---")
    rec_str = compute_recommended_dates_str("城市A", [])
    print(f"  {rec_str}")
    
    # 3.6 城市A周五限制
    print("\n--- 3.6 城市A周五时段限制 ---")
    # 找一个周五
    test_date = datetime.now().date() + timedelta(days=1)
    while test_date.weekday() != 4:
        test_date += timedelta(days=1)
    friday_key = f"{test_date.month}月{test_date.day}日"
    is_fri = is_friday(friday_key)
    print(f"  {friday_key} is_friday={is_fri}")
    if is_fri:
        print(f"  [PASS] Friday detected, Xi'an would be limited to 14:00 and 14:30")
    else:
        print(f"  [WARN] Friday detection failed for {friday_key}")
    
    # 3.7 串行去重 - 模拟3人连续预约
    print("\n--- 3.7 串行去重模拟(3人连续预约同一时段) ---")
    booked_slots = []
    test_slots = ["8月6日14:00", "8月6日14:00", "8月6日14:30"]
    for i, slot in enumerate(test_slots):
        if slot in booked_slots:
            print(f"  Person {i+1}: slot '{slot}' - CONFLICT (already booked)")
        else:
            booked_slots.append(slot)
            print(f"  Person {i+1}: slot '{slot}' - BOOKED OK")
    print(f"  Final booked: {booked_slots}")
    
    print(f"\n--- Part 3 Complete ---")


def run_edge_case_tests():
    """边界情况测试"""
    print_header("Part 4: 边界情况测试")
    
    issues = []
    
    # 4.1 空名单
    print("\n--- 4.1 空名单处理 ---")
    empty_candidates = []
    if not empty_candidates:
        print(f"  [PASS] Empty list detected, would skip calling")
    else:
        print(f"  [FAIL] Empty list not handled")
        issues.append("Empty list not handled")
    
    # 4.2 格式错误的JSON
    print("\n--- 4.2 格式错误的JSON ---")
    bad_json = '{name: "test"}'  # missing quotes
    try:
        json.loads(bad_json)
        print(f"  [FAIL] Bad JSON parsed without error")
        issues.append("Bad JSON not caught")
    except json.JSONDecodeError:
        print(f"  [PASS] Bad JSON correctly rejected")
    
    # 4.3 缺少city字段 - batch_call.py已全部改为.get()
    print("\n--- 4.3 缺少city字段 ---")
    no_city = {"name": "测试", "phone": "13800138000", "position": "实习生"}
    try:
        validated = validate_screening_candidate(no_city)
        city = validated.get("city", "")
        if not city:
            # 验证 batch_call.py 中 create_and_call_one 和主循环都用 .get()
            import inspect
            from batch_call import create_and_call_one
            source = inspect.getsource(create_and_call_one)
            main_loop_uses_get = "candidate.get(" in source
            if main_loop_uses_get:
                print(f"  [PASS] city field missing but batch_call uses .get(), no KeyError risk")
            else:
                print(f"  [WARN] city field missing and batch_call may use candidate['city']")
                issues.append("Missing city field causes KeyError in batch_call.py")
        else:
            print(f"  [PASS] city field present: {city}")
    except CandidateValidationError as e:
        print(f"  [PASS] Validation error: {e}")
    
    # 4.4 phone为整数而非字符串
    print("\n--- 4.4 phone为整数(非字符串) ---")
    int_phone = {"name": "测试", "phone": 13800138000, "position": "实习生", "city": "城市A"}
    try:
        validated = validate_screening_candidate(int_phone)
        print(f"  [PASS] Integer phone converted: {validated['phone']}")
    except CandidateValidationError as e:
        print(f"  [FAIL] Integer phone rejected: {e}")
        issues.append(f"Integer phone rejected: {e}")
    
    # 4.5 极长姓名(31字符)
    print("\n--- 4.5 极长姓名(31字符) ---")
    long_name = {"name": "A" * 31, "phone": "13800138000", "position": "实习生", "city": "城市A"}
    try:
        validate_screening_candidate(long_name)
        print(f"  [FAIL] 31-char name accepted (max is 30)")
        issues.append("31-char name accepted")
    except CandidateValidationError:
        print(f"  [PASS] 31-char name rejected")
    
    # 4.6 2026年节假日覆盖
    print("\n--- 4.6 节假日覆盖检查 ---")
    holiday_checks = [
        ("2026-02-16", True, "春节"),
        ("2026-04-04", True, "清明"),
        ("2026-10-01", True, "国庆"),
        ("2026-08-06", False, "普通工作日"),
    ]
    for date_str, expect_holiday, label in holiday_checks:
        d = datetime.strptime(date_str, "%Y-%m-%d").date()
        actual = is_holiday(d)
        if actual == expect_holiday:
            print(f"  [PASS] {date_str} ({label}): holiday={actual}")
        else:
            print(f"  [FAIL] {date_str} ({label}): expected holiday={expect_holiday}, got {actual}")
            issues.append(f"Holiday check failed for {date_str}")
    
    # 4.7 result_query.py中CRED_PATH路径不一致
    print("\n--- 4.7 凭证路径一致性检查 ---")
    batch_cred = os.path.join(os.path.expanduser("~"), ".alibabacloud", "alibabacloud.properties")
    # result_query通过aliyun_caller的_get_client获取凭证
    # aliyun_caller的_get_client可能使用不同路径
    print(f"  batch_call.py CRED_PATH: {batch_cred}")
    print(f"  NOTE: result_query.py uses aliyun_caller._get_client() - need to verify path consistency")
    
    # 4.8 定时任务路径检查 - 已通过 scheduler_action 修复
    print("\n--- 4.8 定时任务路径检查 ---")
    # 定时任务已通过 scheduler_action update 修正路径 typo
    # 此处仅做代码层面验证：确认 batch_call.py 和 result_query.py 存在且路径一致
    bc_path = os.path.join(SCRIPTS_DIR, "batch_call.py")
    rq_path = os.path.join(SCRIPTS_DIR, "result_query.py")
    if os.path.exists(bc_path) and os.path.exists(rq_path):
        print(f"  [PASS] Both scripts exist at {SCRIPTS_DIR}")
    else:
        bc_ok = os.path.exists(bc_path)
        rq_ok = os.path.exists(rq_path)
        print(f"  [FAIL] Script missing: batch_call.py={bc_ok}, result_query.py={rq_ok}")
        issues.append("Script file missing")
    
    print(f"\n--- Part 4: {len(issues)} issues found ---")
    return issues


def main():
    print_header("面试预约外呼机器人 - 模拟测试 (10组HR数据)")
    print(f"测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    all_issues = []
    
    p1_pass, p1_warn, p1_fail = run_scenario_tests()
    if p1_fail > 0:
        all_issues.append(f"Part1: {p1_fail} validation test failures")
    
    p2_pass, p2_fail = run_conversation_tests()
    if p2_fail > 0:
        all_issues.append(f"Part2: {p2_fail} conversation extraction failures")
    
    run_slot_generation_tests()
    
    p4_issues = run_edge_case_tests()
    all_issues.extend(p4_issues)
    
    # 最终报告
    print_header("FINAL REPORT")
    if not all_issues:
        print("  ALL TESTS PASSED - No issues found")
    else:
        print(f"  {len(all_issues)} issue(s) found:")
        for i, issue in enumerate(all_issues, 1):
            print(f"    {i}. {issue}")
    
    print(f"\n  Total: {p1_pass + p2_pass} passed, {p1_fail + p2_fail} failed, {p1_warn} warnings")


if __name__ == "__main__":
    main()
