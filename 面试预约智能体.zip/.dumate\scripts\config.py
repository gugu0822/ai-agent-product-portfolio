# -*- coding: utf-8 -*-
"""
面试提醒Agent - 配置文件

三种外呼模式：
1. 提醒模式(--call)：单轮播报面试时间（原有功能）
2. 预约模式(--booking)：多轮交互对话，与候选人协商预约面试时间（新增）
3. 筛选模式(--screening)：大模型驱动多轮对话招聘筛选，含城市/实习/通勤/预约（新增）
"""
import os

# ========== 公司信息 ==========
# 配置方式：环境变量 COMPANY_NAME，未设置时使用占位符
COMPANY_NAME = os.environ.get("COMPANY_NAME", "YOUR_COMPANY_NAME")

# ========== 邮件SMTP配置 ==========
# 发件邮箱和授权码通过首次运行引导配置，保存在 .email_config.json 中
# 默认QQ邮箱配置，实际运行会根据邮箱后缀自动识别
SMTP_SERVER = "smtp.qq.com"
SMTP_PORT = 465  # SSL端口

# 支持的邮箱服务商自动映射（根据邮箱后缀）
EMAIL_PROVIDERS = {
    "@qq.com": {"server": "smtp.qq.com", "port": 465, "name": "QQ邮箱"},
    "@163.com": {"server": "smtp.163.com", "port": 465, "name": "网易163邮箱"},
    "@126.com": {"server": "smtp.126.com", "port": 465, "name": "网易126邮箱"},
    "@yeah.net": {"server": "smtp.yeah.net", "port": 465, "name": "网易Yeah邮箱"},
    "@sina.com": {"server": "smtp.sina.com", "port": 465, "name": "新浪邮箱"},
    "@gmail.com": {"server": "smtp.gmail.com", "port": 465, "name": "Gmail"},
    "@outlook.com": {"server": "smtp-mail.outlook.com", "port": 587, "name": "Outlook"},
    "@hotmail.com": {"server": "smtp-mail.outlook.com", "port": 587, "name": "Hotmail"},
    "@aliyun.com": {"server": "smtp.aliyun.com", "port": 465, "name": "阿里云邮箱"},
    "@foxmail.com": {"server": "smtp.qq.com", "port": 465, "name": "Foxmail邮箱"},
}

# ========== 邮件模板 ==========
EMAIL_SUBJECT = "{company} - 面试提醒：{position}"

EMAIL_BODY_HTML = """\
<html>
<body style="font-family: 'Microsoft YaHei', Arial, sans-serif; line-height: 1.8; color: #333;">
  <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 10px 10px 0 0;">
      <h2 style="color: #fff; margin: 0;">面试提醒通知</h2>
    </div>
    <div style="border: 1px solid #e0e0e0; border-top: none; padding: 30px; border-radius: 0 0 10px 10px;">
      <p>尊敬的 <strong>{name}</strong> 您好，</p>
      <p>这里是 <strong>{company}</strong> HR部门，温馨提醒您已预约以下面试：</p>
      <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
        <tr>
          <td style="padding: 10px; border: 1px solid #e0e0e0; background: #f8f9fa; font-weight: bold; width: 120px;">面试岗位</td>
          <td style="padding: 10px; border: 1px solid #e0e0e0;">{position}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #e0e0e0; background: #f8f9fa; font-weight: bold;">面试日期</td>
          <td style="padding: 10px; border: 1px solid #e0e0e0;">{interview_date}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #e0e0e0; background: #f8f9fa; font-weight: bold;">面试时间</td>
          <td style="padding: 10px; border: 1px solid #e0e0e0;">{interview_time}</td>
        </tr>
      </table>
      <p>请安排好时间准时参加面试，如有疑问请联系我们。</p>
      <p>祝您面试顺利！</p>
      <hr style="border: none; border-top: 1px solid #e0e0e0; margin: 20px 0;">
      <p style="color: #888; font-size: 12px;">此邮件由 {company} 面试提醒系统自动发送，请勿直接回复。</p>
    </div>
  </div>
</body>
</html>
"""

# ========== 路径配置 ==========
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(SCRIPT_DIR)
CANDIDATES_FILE = os.path.join(BASE_DIR, "candidates.json")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

# ========== 阿里云智能外呼配置 ==========

# 实例ID（环境变量 ALIYUN_INSTANCE_ID 配置）
ALIYUN_INSTANCE_ID = os.environ.get("ALIYUN_INSTANCE_ID", "")

# 阿里云Region（智能外呼服务在cn-shanghai）
ALIYUN_REGION_ID = "cn-shanghai"

# 主叫号码（需要先在阿里云控制台→智能外呼→外呼号码管理中配置）
# 如果为空，则使用系统默认号码
ALIYUN_CALLER_NUMBER = os.environ.get("ALIYUN_CALLER_NUMBER", "")

# --- 场景1：面试提醒（单轮播报，原有功能） ---
# 场景ID = 脚本ID（环境变量 ALIYUN_SCENE_ID_REMINDER 配置）
ALIYUN_SCENE_ID_REMINDER = os.environ.get("ALIYUN_SCENE_ID_REMINDER", "")

# --- 场景2：面试时间预约（多轮交互对话，新增） ---
# 需要在阿里云控制台创建新的对话流场景，配置4步交互流程
# 创建后将场景ID填入下方
# 对话流配置指南见 项目根目录/对话流配置指南.md
ALIYUN_SCENE_ID_BOOKING = ""  # TODO: 创建对话流后填入场景ID

# 当前使用的场景（由main.py根据模式选择）
# 提醒模式使用 ALIYUN_SCENE_ID_REMINDER
# 预约模式使用 ALIYUN_SCENE_ID_BOOKING
ALIYUN_SCENE_ID = ALIYUN_SCENE_ID_REMINDER  # 默认为提醒模式

# ========== 预约模式 - 全局变量名映射 ==========
# 这些变量名必须与阿里云对话流中配置的全局变量名完全一致
# 对话流中通过 ${变量名} 引用
BOOKING_VARIABLES = {
    "candidatename": "candidate_name",       # 候选人姓名
    "positionname": "position_name",         # 面试岗位
    "companyname": "company_name",            # 公司名称
    "slotatime": "slot_a_time",              # 时间段A
    "slotbtime": "slot_b_time",              # 时间段B
    "slotctime": "slot_c_time",              # 时间段C
}

# 预约结果标记值（与对话流中分支结束节点的标记值对应）
# 这些值出现在外呼结果的 summary 或 intent 中
BOOKING_RESULT_TAGS = {
    "WRONG_NUMBER": "号码错误",       # 第一步：候选人确认不是本人
    "NO_INTEREST": "无意向",           # 第二步：已找到工作/已入职
    "BOOKED": "已预约",                # 第三步：成功预约时间段
    "NEED_HR": "需HR协调",            # 第三步：所有时间段都不行
    "CONSIDERING": "考虑中",          # 第三步：候选人需要考虑一下
    "UNREACHABLE": "未接通",           # 电话未接通
}


# ========== 筛选模式 - 大模型对话外呼 ==========

# --- 场景3：招聘筛选（大模型对话，新增） ---
# 需要在阿里云控制台→大模型场景管理→新建场景→文本填写模式
# 将 system_prompt.py 中的 SCREENING_PROMPT_TEMPLATE 配置为机器人提示词
# 在变量配置中添加：candidatename、positionname、availableslots
# 创建后将场景ID（即scriptId）填入下方
ALIYUN_SCENE_ID_SCREENING = ""  # TODO: 创建大模型场景后填入场景ID

# 筛选模式 - 预设面试时段（每天可用的时段）
# 人设文档要求：工作日下午，系统按优先级自动匹配
SCREENING_SLOT_TIMES = ["14:00", "15:00", "16:00"]

# 筛选模式 - 生成的时段天数
SCREENING_NUM_DAYS = 5

# 筛选模式 - 全局变量名映射
# 这些变量名必须与阿里云大模型场景中配置的变量名完全一致
SCREENING_VARIABLES = {
    "candidatename": "candidate_name",      # 候选人姓名
    "positionname": "position_name",        # 投递岗位名称
    "availableslots": "available_slots",    # 可用面试时段（多行文本）
}

# 筛选模式 - 结果标记值
# 大模型对话的结果通过summary/intent返回，根据对话内容判断
SCREENING_RESULT_TAGS = {
    "WRONG_NUMBER": "号码错误",          # 候选人否认身份
    "NO_INTEREST": "无意向",              # 候选人无意向（已入职等）
    "BOOKED": "已预约",                   # 成功预约面试
    "NEED_HR": "需HR协调",               # 需要HR后续协调
    "INTERNSHIP_FAIL": "实习不足不接受",   # 实习时长不足且不接受3个月
    "COMMUTE_FAIL": "通勤不便",           # 通勤不方便
    "UNREACHABLE": "未接通",              # 电话未接通
}
