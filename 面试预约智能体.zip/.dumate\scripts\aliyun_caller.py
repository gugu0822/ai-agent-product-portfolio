# -*- coding: utf-8 -*-
"""
面试提醒Agent - 阿里云智能外呼API对接模块

调用阿里云智能外呼机器人(OutboundBot) API实现自动外呼
API流程: CreateJobGroup -> AssignJobs

两种模式：
  1. 提醒模式（单轮）：播报固定面试时间
  2. 预约模式（多轮）：4步交互对话，协商预约面试时间

错误处理策略:
  - API调用失败: 自动重试3次，间隔递增（5s/10s/20s）
  - 凭证错误: 直接报错，不重试
  - 参数错误: 直接报错，不重试
  - 网络超时: 自动重试
  - 额度不足: 报错并提示解决方案
"""
import os
import sys
import json
import uuid
import time
import traceback
from datetime import datetime
from typing import Dict, List, Optional

from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.acs_exception.exceptions import ClientException, ServerException
from aliyunsdkoutboundbot.request.v20191226.CreateJobGroupRequest import CreateJobGroupRequest
from aliyunsdkoutboundbot.request.v20191226.AssignJobsRequest import AssignJobsRequest
from aliyunsdkoutboundbot.request.v20191226.ListInstancesRequest import ListInstancesRequest

_current_dir = os.path.dirname(os.path.abspath(__file__))
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)

from config import (
    ALIYUN_SCENE_ID, ALIYUN_SCENE_ID_REMINDER, ALIYUN_SCENE_ID_BOOKING,
    ALIYUN_SCENE_ID_SCREENING,
    ALIYUN_REGION_ID, ALIYUN_INSTANCE_ID, ALIYUN_CALLER_NUMBER, COMPANY_NAME,
    BOOKING_VARIABLES, BOOKING_RESULT_TAGS,
    SCREENING_VARIABLES, SCREENING_RESULT_TAGS,
    SCREENING_SLOT_TIMES, SCREENING_NUM_DAYS,
)
from validator import (
    validate_candidates, validate_booking_candidates,
    validate_screening_candidates,
    format_date_for_tts, format_slot_for_tts,
    CandidateValidationError
)


# ========== 错误分类 ==========

class AliyunCallError(Exception):
    """外呼基础错误"""
    def __init__(self, message, error_type="unknown", retryable=False):
        super().__init__(message)
        self.error_type = error_type
        self.retryable = retryable


class CredentialError(AliyunCallError):
    """凭证错误（不可重试）"""
    def __init__(self, message):
        super().__init__(message, error_type="credential", retryable=False)


class ParameterError(AliyunCallError):
    """参数错误（不可重试）"""
    def __init__(self, message):
        super().__init__(message, error_type="parameter", retryable=False)


class QuotaError(AliyunCallError):
    """额度不足错误（不可重试，需等待重置或提升额度）"""
    def __init__(self, message):
        super().__init__(message, error_type="quota", retryable=False)


class NetworkError(AliyunCallError):
    """网络错误（可重试）"""
    def __init__(self, message):
        super().__init__(message, error_type="network", retryable=True)


class APIError(AliyunCallError):
    """API返回错误"""
    def __init__(self, message, retryable=True):
        super().__init__(message, error_type="api", retryable=retryable)


# ========== 重试装饰器 ==========

def retry_on_failure(max_retries=3, base_delay=5):
    """
    自动重试装饰器
    
    重试策略:
      - 第1次重试: 等待 5秒
      - 第2次重试: 等待 10秒
      - 第3次重试: 等待 20秒
      - 只重试 retryable=True 的错误
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            last_error = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except AliyunCallError as e:
                    last_error = e
                    if not e.retryable or attempt >= max_retries:
                        raise
                    delay = base_delay * (2 ** attempt)
                    print(f"[WARN] 第{attempt+1}次重试（{e.error_type}），等待{delay}秒... ({e})")
                    time.sleep(delay)
                except Exception as e:
                    last_error = e
                    if attempt >= max_retries:
                        raise APIError(f"未知错误: {e}", retryable=False)
                    delay = base_delay * (2 ** attempt)
                    print(f"[WARN] 第{attempt+1}次重试（未知错误），等待{delay}秒... ({e})")
                    time.sleep(delay)
            raise last_error
        return wrapper
    return decorator


# ========== 错误解析 ==========

def _parse_api_error(exception) -> AliyunCallError:
    """
    解析阿里云API错误，分类返回对应的错误类型
    
    常见错误码:
      - InvalidAccessKeyId: 凭证错误
      - SignatureDoesNotMatch: 凭证错误
      - Permission.Instance: 权限不足
      - NotExist.Instance: 实例不存在
      - NotExist.JobGroup: 任务组不存在
      - ParameterFormat.JobJson: 参数格式错误
      - ParameterNull: 参数为空
      - 超过每日上限: 额度不足
      - Throttling: 限流（可重试）
    """
    err_str = str(exception)
    
    # 凭证类错误
    if "InvalidAccessKeyId" in err_str or "SignatureDoesNotMatch" in err_str:
        return CredentialError(f"阿里云凭证错误: {err_str}")
    
    # 权限错误
    if "Permission" in err_str or "Forbidden" in err_str:
        return CredentialError(f"权限不足: {err_str}")
    
    # 实例/资源不存在
    if "NotExist" in err_str:
        return ParameterError(f"资源不存在: {err_str}")
    
    # 参数格式错误
    if "ParameterFormat" in err_str or "ParameterNull" in err_str:
        return ParameterError(f"参数错误: {err_str}")
    
    # 额度不足
    if "超过每日上限" in err_str or "Quota" in err_str or "LimitExceeded" in err_str:
        return QuotaError(f"额度不足: {err_str}")
    
    # 限流（可重试）
    if "Throttling" in err_str or "ServiceUnavailable" in err_str or "InternalError" in err_str:
        return NetworkError(f"服务暂时不可用: {err_str}")
    
    # 网络超时
    if "timeout" in err_str.lower() or "connection" in err_str.lower() or "timed out" in err_str.lower():
        return NetworkError(f"网络错误: {err_str}")
    
    # 其他API错误
    return APIError(f"API错误: {err_str}", retryable=True)


# ========== 客户端管理 ==========

_client_instance = None


def _get_client():
    """
    创建阿里云SDK客户端（单例模式）
    自动从用户目录下的 .alibabacloud/alibabacloud.properties 读取凭证
    
    Raises:
        CredentialError: 凭证未配置或无效
    """
    global _client_instance
    if _client_instance is not None:
        return _client_instance
    
    try:
        # 优先从项目目录读取凭证（开箱即用）
        config_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "alibabacloud.properties"
        )
        if not os.path.exists(config_path):
            # 回退到用户目录
            config_path = os.path.join(
                os.path.expanduser("~"),
                ".alibabacloud",
                "alibabacloud.properties"
            )
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
            access_key_id = config.get("access_key_id", "")
            access_key_secret = config.get("access_key_secret", "")
        else:
            access_key_id = os.environ.get("ALIYUN_ACCESS_KEY_ID", "")
            access_key_secret = os.environ.get("ALIYUN_ACCESS_KEY_SECRET", "")
        
        if not access_key_id or not access_key_secret:
            raise CredentialError(
                "阿里云AccessKey未配置\n"
                "请将凭证文件放到 ~/.alibabacloud/alibabacloud.properties\n"
                "格式: {\"access_key_id\": \"xxx\", \"access_key_secret\": \"xxx\"}"
            )
        
        client = AcsClient(
            access_key_id,
            access_key_secret,
            ALIYUN_REGION_ID,
        )
        
        from aliyunsdkcore.profile import region_provider
        region_provider.add_endpoint(
            "OutboundBot",
            ALIYUN_REGION_ID,
            f"outboundbot.{ALIYUN_REGION_ID}.aliyuncs.com"
        )
        
        _client_instance = client
        return client
        
    except CredentialError:
        raise
    except Exception as e:
        raise CredentialError(f"创建阿里云客户端失败: {e}")


def get_instance_id() -> Optional[str]:
    """获取实例ID（直接从配置读取）"""
    if ALIYUN_INSTANCE_ID:
        return ALIYUN_INSTANCE_ID
    return None


# ========== 核心API调用 ==========

@retry_on_failure(max_retries=3, base_delay=5)
def create_job_group(instance_id: str, job_group_name: str = None, scene_id: str = None) -> str:
    """
    创建外呼任务组
    
    Args:
        instance_id: 阿里云实例ID
        job_group_name: 任务组名称（可选，自动生成）
        scene_id: 场景ID（可选，默认使用 config.ALIYUN_SCENE_ID）
                  提醒模式用 ALIYUN_SCENE_ID_REMINDER
                  预约模式用 ALIYUN_SCENE_ID_BOOKING
    
    Returns:
        JobGroupId 字符串
    
    Raises:
        CredentialError: 凭证错误
        ParameterError: 参数错误（场景ID不存在等）
        QuotaError: 额度不足
        NetworkError: 网络错误（自动重试）
        APIError: 其他API错误
    """
    client = _get_client()
    
    if scene_id is None:
        scene_id = ALIYUN_SCENE_ID
    
    if not scene_id:
        raise ParameterError(
            "场景ID未配置\n"
            "提醒模式: config.py 中 ALIYUN_SCENE_ID_REMINDER 已配置\n"
            "预约模式: 需要在阿里云控制台创建对话流后，将场景ID填入 ALIYUN_SCENE_ID_BOOKING"
        )
    
    if not job_group_name:
        job_group_name = f"interview-reminder_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    try:
        request = CreateJobGroupRequest()
        request.set_accept_format("json")
        request.set_protocol_type("https")
        request.set_InstanceId(instance_id)
        request.set_JobGroupName(job_group_name)
        request.set_JobGroupDescription("面试提醒自动外呼")
        request.set_ScenarioId(scene_id)
        request.set_ScriptId(scene_id)
        
        if ALIYUN_CALLER_NUMBER:
            request.set_CallingNumbers([ALIYUN_CALLER_NUMBER])
            print(f"[INFO] 使用主叫号码: {ALIYUN_CALLER_NUMBER}")
        
        response = client.do_action_with_exception(request)
        result = json.loads(response)
        
        job_group_id = result.get("JobGroup", {}).get("JobGroupId", "")
        if job_group_id:
            print(f"[OK] 任务组创建成功: {job_group_id}")
            return job_group_id
        else:
            code = result.get("Code", "Unknown")
            raise APIError(f"任务组创建失败: Code={code}, Response={result}", retryable=False)
            
    except AliyunCallError:
        raise
    except ServerException as e:
        raise _parse_api_error(e)
    except ClientException as e:
        raise NetworkError(f"网络错误: {e}")
    except Exception as e:
        raise APIError(f"创建任务组时发生未知错误: {e}", retryable=False)


@retry_on_failure(max_retries=3, base_delay=5)
def assign_jobs(
    instance_id: str,
    job_group_id: str,
    candidates: List[Dict]
) -> Dict:
    """
    分配外呼任务
    
    Returns:
        {"success": bool, "job_ids": list, "job_group_id": str, "assigned": int, "message": str}
    
    Raises:
        CredentialError: 凭证错误
        ParameterError: 参数错误
        QuotaError: 额度不足
        NetworkError: 网络错误（自动重试）
    """
    client = _get_client()
    
    try:
        jobs_jsons = []
        for candidate in candidates:
            cn_date = candidate.get('_tts_date')
            if not cn_date:
                cn_date = format_date_for_tts(candidate["interview_date"])

            job_json = json.dumps({
                "extras": [
                    {"key": "candidatename", "value": candidate["name"]},
                    {"key": "positionname", "value": candidate["position"]},
                    {"key": "interviewdate", "value": cn_date},
                    {"key": "interviewtime", "value": candidate["interview_time"]},
                ],
                "contacts": [
                    {
                        "phoneNumber": candidate["phone"],
                        "name": candidate["name"],
                        "referenceId": str(uuid.uuid4())[:8],
                        "role": "candidate",
                        "honorific": candidate["name"],
                    }
                ]
            }, ensure_ascii=False)
            jobs_jsons.append(job_json)
        
        request = AssignJobsRequest()
        request.set_accept_format("json")
        request.set_protocol_type("https")
        request.set_InstanceId(instance_id)
        request.set_JobGroupId(job_group_id)
        request.set_JobsJsons(jobs_jsons)
        request.set_IsAsynchrony(True)
        
        if ALIYUN_CALLER_NUMBER:
            request.set_CallingNumbers([ALIYUN_CALLER_NUMBER])
        
        response = client.do_action_with_exception(request)
        result = json.loads(response)
        
        job_ids = result.get("JobsId", [])
        success = result.get("Success", False)
        code = result.get("Code", "")
        
        if success or code == "OK":
            print(f"[OK] 外呼任务分配成功: {len(job_ids)} 个任务")
            for jid in job_ids:
                print(f"     JobId: {jid}")
            return {
                "success": True,
                "job_ids": job_ids,
                "job_group_id": job_group_id,
                "assigned": len(job_ids),
                "message": f"成功分配 {len(job_ids)} 个外呼任务"
            }
        else:
            raise APIError(f"AssignJobs返回失败: Code={code}", retryable=False)
        
    except AliyunCallError:
        raise
    except ServerException as e:
        raise _parse_api_error(e)
    except ClientException as e:
        raise NetworkError(f"网络错误: {e}")
    except Exception as e:
        raise APIError(f"分配外呼任务时发生未知错误: {e}", retryable=False)


# ========== 对外统一入口 ==========

def call_candidates(candidates: List[Dict]) -> Dict:
    """
    一键外呼：校验输入 → 创建任务组 → 分配任务
    
    完整错误处理:
      1. 输入校验失败 → 跳过错误数据，继续处理合法数据
      2. 凭证错误 → 直接返回，提示配置方法
      3. 参数错误 → 直接返回，提示检查配置
      4. 额度不足 → 返回，提示等待重置或提升额度
      5. 网络错误 → 自动重试3次
      6. API错误 → 自动重试3次
    
    Returns:
        {"success": bool, "job_group_id": str, "job_ids": list, 
         "message": str, "errors": list, "skipped": int}
    """
    print("=" * 60)
    print("  阿里云智能外呼 - 面试提醒")
    print(f"  场景ID: {ALIYUN_SCENE_ID}")
    print(f"  主叫号码: {ALIYUN_CALLER_NUMBER or '未配置'}")
    print(f"  候选人: {len(candidates)} 位")
    print(f"  执行时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 0. 输入校验
    try:
        valid_candidates, errors = validate_candidates(candidates)
    except Exception as e:
        return {
            "success": False,
            "message": f"输入校验发生异常: {e}",
            "errors": [{"error": str(e)}],
            "skipped": len(candidates)
        }
    
    if errors:
        print(f"\n[WARN] 输入校验发现 {len(errors)} 个错误:")
        for err in errors:
            print(f"  第{err['index']+1}条 - {err['name']}: {err['error']}")
        print()
    
    if not valid_candidates:
        return {
            "success": False,
            "message": f"所有候选人数据校验失败（{len(errors)}个错误），请修正后重试",
            "errors": errors,
            "skipped": len(candidates)
        }
    
    if errors:
        print(f"[INFO] 校验通过 {len(valid_candidates)} 位，跳过 {len(errors)} 位\n")
    
    # 日期转中文格式（TTS播报用）
    for c in valid_candidates:
        c['_tts_date'] = format_date_for_tts(c['interview_date'])
    
    # 1. 获取实例ID
    instance_id = get_instance_id()
    if not instance_id:
        return {
            "success": False,
            "message": "实例ID未配置，请在 config.py 中设置 ALIYUN_INSTANCE_ID",
            "errors": errors,
            "skipped": len(errors)
        }
    
    # 2. 创建任务组
    try:
        print(f"\n[步骤1/2] 创建任务组...")
        job_group_id = create_job_group(instance_id)
    except CredentialError as e:
        return {
            "success": False,
            "message": f"凭证错误: {e}\n请检查 ~/.alibabacloud/alibabacloud.properties 配置",
            "errors": errors,
            "skipped": len(errors)
        }
    except ParameterError as e:
        return {
            "success": False,
            "message": f"参数错误: {e}\n请检查 config.py 中 ALIYUN_SCENE_ID 和 ALIYUN_INSTANCE_ID 是否正确",
            "errors": errors,
            "skipped": len(errors)
        }
    except QuotaError as e:
        return {
            "success": False,
            "message": f"额度不足: {e}\n请等待次日0点额度重置，或联系阿里云提升额度",
            "errors": errors,
            "skipped": len(errors)
        }
    except NetworkError as e:
        return {
            "success": False,
            "message": f"网络错误（已重试3次）: {e}\n请检查网络连接后重试",
            "errors": errors,
            "skipped": len(errors)
        }
    except AliyunCallError as e:
        return {
            "success": False,
            "message": f"创建任务组失败: {e}",
            "errors": errors,
            "skipped": len(errors)
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"创建任务组时发生未知错误: {e}",
            "errors": errors,
            "skipped": len(errors)
        }
    
    # 3. 分配外呼任务
    try:
        print(f"\n[步骤2/2] 分配外呼任务（{len(valid_candidates)} 位候选人）...")
        result = assign_jobs(instance_id, job_group_id, valid_candidates)
        
        # 合并校验错误到返回结果
        if errors:
            result["errors"] = errors
            result["skipped"] = len(errors)
            result["message"] += f"（跳过 {len(errors)} 位校验失败的候选人）"
        else:
            result["errors"] = []
            result["skipped"] = 0
        
        return result
        
    except CredentialError as e:
        return {
            "success": False,
            "message": f"凭证错误: {e}",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except ParameterError as e:
        return {
            "success": False,
            "message": f"参数错误: {e}\n任务组已创建但任务分配失败，请检查候选人数据",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except QuotaError as e:
        return {
            "success": False,
            "message": f"额度不足: {e}\n任务组已创建但无法外呼，请等待额度重置",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except NetworkError as e:
        return {
            "success": False,
            "message": f"网络错误（已重试3次）: {e}\n任务组已创建但任务分配失败，请稍后重试",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except AliyunCallError as e:
        return {
            "success": False,
            "message": f"分配外呼任务失败: {e}",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"分配外呼任务时发生未知错误: {e}",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }


# ========== 预约模式 - 多轮对话外呼 ==========

@retry_on_failure(max_retries=3, base_delay=5)
def assign_booking_jobs(
    instance_id: str,
    job_group_id: str,
    candidates: List[Dict]
) -> Dict:
    """
    分配预约模式的外呼任务
    
    与提醒模式的区别：
    - 传递更多变量：公司名称、3个时间段
    - 时间段使用TTS友好格式（中文日期+上午/下午时间）
    
    变量映射（extras key -> 阿里云对话流中的变量名）：
    - candidatename: 候选人姓名
    - positionname: 面试岗位
    - companyname: 公司名称
    - slotatime: 时间段A（中文格式）
    - slotbtime: 时间段B（中文格式）
    - slotctime: 时间段C（中文格式）
    """
    client = _get_client()
    
    try:
        jobs_jsons = []
        for candidate in candidates:
            # 转换时间段为TTS友好格式
            slot_a_tts = format_slot_for_tts(candidate["slot_a_time"])
            slot_b_tts = format_slot_for_tts(candidate["slot_b_time"])
            slot_c_tts = format_slot_for_tts(candidate["slot_c_time"])
            
            job_json = json.dumps({
                "extras": [
                    {"key": "candidatename", "value": candidate["name"]},
                    {"key": "positionname", "value": candidate["position"]},
                    {"key": "companyname", "value": COMPANY_NAME},
                    {"key": "slotatime", "value": slot_a_tts},
                    {"key": "slotbtime", "value": slot_b_tts},
                    {"key": "slotctime", "value": slot_c_tts},
                ],
                "contacts": [
                    {
                        "phoneNumber": candidate["phone"],
                        "name": candidate["name"],
                        "referenceId": str(uuid.uuid4())[:8],
                        "role": "candidate",
                        "honorific": candidate["name"],
                    }
                ]
            }, ensure_ascii=False)
            jobs_jsons.append(job_json)
        
        request = AssignJobsRequest()
        request.set_accept_format("json")
        request.set_protocol_type("https")
        request.set_InstanceId(instance_id)
        request.set_JobGroupId(job_group_id)
        request.set_JobsJsons(jobs_jsons)
        request.set_IsAsynchrony(True)
        
        if ALIYUN_CALLER_NUMBER:
            request.set_CallingNumbers([ALIYUN_CALLER_NUMBER])
        
        response = client.do_action_with_exception(request)
        result = json.loads(response)
        
        job_ids = result.get("JobsId", [])
        success = result.get("Success", False)
        code = result.get("Code", "")
        
        if success or code == "OK":
            print(f"[OK] 预约外呼任务分配成功: {len(job_ids)} 个任务")
            for jid in job_ids:
                print(f"     JobId: {jid}")
            return {
                "success": True,
                "job_ids": job_ids,
                "job_group_id": job_group_id,
                "assigned": len(job_ids),
                "message": f"成功分配 {len(job_ids)} 个预约外呼任务"
            }
        else:
            raise APIError(f"AssignJobs返回失败: Code={code}", retryable=False)
    
    except AliyunCallError:
        raise
    except ServerException as e:
        raise _parse_api_error(e)
    except ClientException as e:
        raise NetworkError(f"网络错误: {e}")
    except Exception as e:
        raise APIError(f"分配预约外呼任务时发生未知错误: {e}", retryable=False)


def call_candidates_booking(candidates: List[Dict]) -> Dict:
    """
    预约模式一键外呼：校验输入 -> 创建任务组 -> 分配任务
    
    与提醒模式的区别：
    1. 使用 BOOKING_REQUIRED_FIELDS 校验（需要 slot_a/b/c_time）
    2. 使用 ALIYUN_SCENE_ID_BOOKING 场景
    3. 传递6个变量（含公司名称和3个时间段）
    
    Returns:
        {"success": bool, "job_group_id": str, "job_ids": list, 
         "message": str, "errors": list, "skipped": int}
    """
    print("=" * 60)
    print("  阿里云智能外呼 - 面试时间预约（多轮对话）")
    print(f"  场景ID: {ALIYUN_SCENE_ID_BOOKING or '未配置'}")
    print(f"  主叫号码: {ALIYUN_CALLER_NUMBER or '未配置'}")
    print(f"  候选人: {len(candidates)} 位")
    print(f"  执行时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 0. 检查预约场景ID是否已配置
    if not ALIYUN_SCENE_ID_BOOKING:
        return {
            "success": False,
            "message": (
                "预约模式场景ID未配置\n"
                "请先在阿里云控制台创建面试预约对话流，\n"
                "然后将场景ID填入 config.py 的 ALIYUN_SCENE_ID_BOOKING\n"
                "对话流配置指南见项目根目录的 对话流配置指南.md"
            ),
            "errors": [],
            "skipped": len(candidates)
        }
    
    # 1. 输入校验（预约模式）
    try:
        valid_candidates, errors = validate_booking_candidates(candidates)
    except Exception as e:
        return {
            "success": False,
            "message": f"输入校验发生异常: {e}",
            "errors": [{"error": str(e)}],
            "skipped": len(candidates)
        }
    
    if errors:
        print(f"\n[WARN] 输入校验发现 {len(errors)} 个错误:")
        for err in errors:
            print(f"  第{err['index']+1}条 - {err['name']}: {err['error']}")
        print()
    
    if not valid_candidates:
        return {
            "success": False,
            "message": f"所有候选人数据校验失败（{len(errors)}个错误），请修正后重试",
            "errors": errors,
            "skipped": len(candidates)
        }
    
    if errors:
        print(f"[INFO] 校验通过 {len(valid_candidates)} 位，跳过 {len(errors)} 位\n")
    
    # 打印将要外呼的候选人信息
    for c in valid_candidates:
        print(f"  {c['name']} | {c['phone']} | {c['position']}")
        print(f"    A: {c['slot_a_time']} -> {format_slot_for_tts(c['slot_a_time'])}")
        print(f"    B: {c['slot_b_time']} -> {format_slot_for_tts(c['slot_b_time'])}")
        print(f"    C: {c['slot_c_time']} -> {format_slot_for_tts(c['slot_c_time'])}")
        print()
    
    # 2. 获取实例ID
    instance_id = get_instance_id()
    if not instance_id:
        return {
            "success": False,
            "message": "实例ID未配置，请在 config.py 中设置 ALIYUN_INSTANCE_ID",
            "errors": errors,
            "skipped": len(errors)
        }
    
    # 3. 创建任务组（使用预约场景）
    try:
        print(f"\n[步骤1/2] 创建任务组（预约模式）...")
        job_group_id = create_job_group(instance_id, scene_id=ALIYUN_SCENE_ID_BOOKING)
    except CredentialError as e:
        return {
            "success": False,
            "message": f"凭证错误: {e}\n请检查 ~/.alibabacloud/alibabacloud.properties 配置",
            "errors": errors,
            "skipped": len(errors)
        }
    except ParameterError as e:
        return {
            "success": False,
            "message": f"参数错误: {e}\n请检查 config.py 中 ALIYUN_SCENE_ID_BOOKING 和 ALIYUN_INSTANCE_ID 是否正确",
            "errors": errors,
            "skipped": len(errors)
        }
    except QuotaError as e:
        return {
            "success": False,
            "message": f"额度不足: {e}\n请等待次日0点额度重置，或联系阿里云提升额度",
            "errors": errors,
            "skipped": len(errors)
        }
    except (NetworkError, AliyunCallError, Exception) as e:
        err_type = type(e).__name__
        return {
            "success": False,
            "message": f"创建任务组失败（{err_type}）: {e}",
            "errors": errors,
            "skipped": len(errors)
        }
    
    # 4. 分配外呼任务（预约模式）
    try:
        print(f"\n[步骤2/2] 分配预约外呼任务（{len(valid_candidates)} 位候选人）...")
        result = assign_booking_jobs(instance_id, job_group_id, valid_candidates)
        
        if errors:
            result["errors"] = errors
            result["skipped"] = len(errors)
            result["message"] += f"（跳过 {len(errors)} 位校验失败的候选人）"
        else:
            result["errors"] = []
            result["skipped"] = 0
        
        return result
        
    except CredentialError as e:
        return {
            "success": False,
            "message": f"凭证错误: {e}",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except ParameterError as e:
        return {
            "success": False,
            "message": f"参数错误: {e}\n任务组已创建但任务分配失败，请检查候选人数据",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except QuotaError as e:
        return {
            "success": False,
            "message": f"额度不足: {e}\n任务组已创建但无法外呼，请等待额度重置",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except (NetworkError, AliyunCallError, Exception) as e:
        err_type = type(e).__name__
        return {
            "success": False,
            "message": f"分配预约外呼任务失败（{err_type}）: {e}",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }


# ========== 筛选模式 - 大模型对话外呼 ==========

@retry_on_failure(max_retries=3, base_delay=5)
def assign_screening_jobs(
    instance_id: str,
    job_group_id: str,
    candidates: List[Dict],
    available_slots_str: str
) -> Dict:
    """
    分配筛选模式的外呼任务（大模型对话）
    
    与预约模式的区别：
    - 不传 slot_a/b/c_time，改为传 availableslots（多行文本）
    - 时段由 slot_generator 动态生成，所有候选人共享同一份时段表
    - 对话逻辑由阿里云大模型场景中的prompt驱动
    
    变量映射（extras key -> 阿里云大模型场景中的变量名）：
    - candidatename: 候选人姓名
    - positionname: 投递岗位名称
    - availableslots: 可用面试时段（多行文本）
    """
    client = _get_client()
    
    try:
        jobs_jsons = []
        for candidate in candidates:
            job_json = json.dumps({
                "extras": [
                    {"key": "candidatename", "value": candidate["name"]},
                    {"key": "positionname", "value": candidate["position"]},
                    {"key": "availableslots", "value": available_slots_str},
                ],
                "contacts": [
                    {
                        "phoneNumber": candidate["phone"],
                        "name": candidate["name"],
                        "referenceId": str(uuid.uuid4())[:8],
                        "role": "candidate",
                        "honorific": candidate["name"],
                    }
                ]
            }, ensure_ascii=False)
            jobs_jsons.append(job_json)
        
        request = AssignJobsRequest()
        request.set_accept_format("json")
        request.set_protocol_type("https")
        request.set_InstanceId(instance_id)
        request.set_JobGroupId(job_group_id)
        request.set_JobsJsons(jobs_jsons)
        request.set_IsAsynchrony(True)
        
        if ALIYUN_CALLER_NUMBER:
            request.set_CallingNumbers([ALIYUN_CALLER_NUMBER])
        
        response = client.do_action_with_exception(request)
        result = json.loads(response)
        
        job_ids = result.get("JobsId", [])
        success = result.get("Success", False)
        code = result.get("Code", "")
        
        if success or code == "OK":
            print(f"[OK] 筛选外呼任务分配成功: {len(job_ids)} 个任务")
            for jid in job_ids:
                print(f"     JobId: {jid}")
            return {
                "success": True,
                "job_ids": job_ids,
                "job_group_id": job_group_id,
                "assigned": len(job_ids),
                "message": f"成功分配 {len(job_ids)} 个筛选外呼任务"
            }
        else:
            raise APIError(f"AssignJobs返回失败: Code={code}", retryable=False)
    
    except AliyunCallError:
        raise
    except ServerException as e:
        raise _parse_api_error(e)
    except ClientException as e:
        raise NetworkError(f"网络错误: {e}")
    except Exception as e:
        raise APIError(f"分配筛选外呼任务时发生未知错误: {e}", retryable=False)


def call_candidates_screening(candidates: List[Dict]) -> Dict:
    """
    筛选模式一键外呼：校验输入 -> 生成时段 -> 创建任务组 -> 分配任务
    
    大模型驱动多轮对话招聘筛选，完整流程由阿里云大模型场景中的prompt控制。
    
    Returns:
        {"success": bool, "job_group_id": str, "job_ids": list, 
         "message": str, "errors": list, "skipped": int}
    """
    from slot_generator import generate_slots, format_slots_for_display, format_slots_for_prompt, count_total_slots
    
    print("=" * 60)
    print("  阿里云智能外呼 - 招聘筛选（大模型对话）")
    print(f"  场景ID: {ALIYUN_SCENE_ID_SCREENING or '未配置'}")
    print(f"  主叫号码: {ALIYUN_CALLER_NUMBER or '未配置'}")
    print(f"  候选人: {len(candidates)} 位")
    print(f"  执行时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 0. 检查筛选场景ID是否已配置
    if not ALIYUN_SCENE_ID_SCREENING:
        return {
            "success": False,
            "message": (
                "筛选模式场景ID未配置\n"
                "请先在阿里云控制台创建大模型场景（文本填写模式），\n"
                "将 system_prompt.py 中的提示词配置到场景中，\n"
                "然后将场景ID填入 config.py 的 ALIYUN_SCENE_ID_SCREENING\n"
                "配置指南见项目根目录的 筛选模式配置指南.md"
            ),
            "errors": [],
            "skipped": len(candidates)
        }
    
    # 1. 输入校验（筛选模式）
    try:
        valid_candidates, errors = validate_screening_candidates(candidates)
    except Exception as e:
        return {
            "success": False,
            "message": f"输入校验发生异常: {e}",
            "errors": [{"error": str(e)}],
            "skipped": len(candidates)
        }
    
    if errors:
        print(f"\n[WARN] 输入校验发现 {len(errors)} 个错误:")
        for err in errors:
            print(f"  第{err['index']+1}条 - {err['name']}: {err['error']}")
        print()
    
    if not valid_candidates:
        return {
            "success": False,
            "message": f"所有候选人数据校验失败（{len(errors)}个错误），请修正后重试",
            "errors": errors,
            "skipped": len(candidates)
        }
    
    if errors:
        print(f"[INFO] 校验通过 {len(valid_candidates)} 位，跳过 {len(errors)} 位\n")
    
    # 2. 生成可用面试时段
    slots_data = generate_slots(num_days=SCREENING_NUM_DAYS)
    available_slots_str = format_slots_for_prompt(slots_data)
    total_slots = count_total_slots(slots_data)
    
    print(f"[INFO] 已生成 {len(slots_data)} 个工作日、{total_slots} 个可用时段:")
    print(format_slots_for_display(slots_data))
    print()
    
    # 打印将要外呼的候选人信息
    for c in valid_candidates:
        print(f"  {c['name']} | {c['phone']} | {c['position']}")
    print()
    
    # 3. 获取实例ID
    instance_id = get_instance_id()
    if not instance_id:
        return {
            "success": False,
            "message": "实例ID未配置，请在 config.py 中设置 ALIYUN_INSTANCE_ID",
            "errors": errors,
            "skipped": len(errors)
        }
    
    # 4. 创建任务组（使用筛选场景）
    try:
        print(f"\n[步骤1/2] 创建任务组（筛选模式）...")
        job_group_id = create_job_group(instance_id, scene_id=ALIYUN_SCENE_ID_SCREENING)
    except CredentialError as e:
        return {
            "success": False,
            "message": f"凭证错误: {e}\n请检查 ~/.alibabacloud/alibabacloud.properties 配置",
            "errors": errors,
            "skipped": len(errors)
        }
    except ParameterError as e:
        return {
            "success": False,
            "message": f"参数错误: {e}\n请检查 config.py 中 ALIYUN_SCENE_ID_SCREENING 和 ALIYUN_INSTANCE_ID 是否正确",
            "errors": errors,
            "skipped": len(errors)
        }
    except (QuotaError, NetworkError, AliyunCallError, Exception) as e:
        err_type = type(e).__name__
        return {
            "success": False,
            "message": f"创建任务组失败（{err_type}）: {e}",
            "errors": errors,
            "skipped": len(errors)
        }
    
    # 5. 分配外呼任务（筛选模式）
    try:
        print(f"\n[步骤2/2] 分配筛选外呼任务（{len(valid_candidates)} 位候选人）...")
        result = assign_screening_jobs(instance_id, job_group_id, valid_candidates, available_slots_str)
        
        if errors:
            result["errors"] = errors
            result["skipped"] = len(errors)
            result["message"] += f"（跳过 {len(errors)} 位校验失败的候选人）"
        else:
            result["errors"] = []
            result["skipped"] = 0
        
        return result
        
    except CredentialError as e:
        return {
            "success": False,
            "message": f"凭证错误: {e}",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except ParameterError as e:
        return {
            "success": False,
            "message": f"参数错误: {e}\n任务组已创建但任务分配失败，请检查候选人数据",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }
    except (QuotaError, NetworkError, AliyunCallError, Exception) as e:
        err_type = type(e).__name__
        return {
            "success": False,
            "message": f"分配筛选外呼任务失败（{err_type}）: {e}",
            "job_group_id": job_group_id,
            "errors": errors,
            "skipped": len(errors)
        }


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--screening":
        # 筛选模式测试
        test_candidates = [
            {
                "name": "张三",
                "phone": "13800138000",
                "position": "产品实习生",
            }
        ]
        result = call_candidates_screening(test_candidates)
    elif len(sys.argv) > 1 and sys.argv[1] == "--booking":
        # 预约模式测试
        test_candidates = [
            {
                "name": "张三",
                "phone": "13800138000",
                "position": "产品实习生",
                "slot_a_time": "2026-07-16 14:30",
                "slot_b_time": "2026-07-18 10:00",
                "slot_c_time": "2026-07-21 09:00",
            }
        ]
        
        result = call_candidates_booking(test_candidates)
    else:
        # 提醒模式测试（原有）
        test_candidates = [
            {
                "name": "张三",
                "phone": "13800138000",
                "position": "产品实习生",
                "interview_date": "2026-07-09",
                "interview_time": "16:40",
            }
        ]
        
        result = call_candidates(test_candidates)
    
    print(f"\n{'='*60}")
    print(f"最终结果:")
    print(f"  Success: {result['success']}")
    print(f"  JobGroup ID: {result.get('job_group_id', 'N/A')}")
    print(f"  Job IDs: {result.get('job_ids', [])}")
    print(f"  Message: {result['message']}")
    if result.get('errors'):
        print(f"  Errors: {len(result['errors'])} 个")
    if result.get('skipped', 0) > 0:
        print(f"  Skipped: {result['skipped']} 位")
    print(f"{'='*60}")
