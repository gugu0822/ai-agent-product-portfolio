# -*- coding: utf-8 -*-
"""
面试预约Agent - 外呼结果查询模块

查询阿里云智能外呼任务的结果，提取对话过程中的关键信息：
- 候选人选择的预约时间段
- 对话结束标记（号码错误/无意向/已预约/需HR协调/考虑中/未接通）
- 通话详情（通话时长、通话记录）

API: QueryJobs (按JobGroupId查询任务列表及状态)
     DescribeJob (查询单个任务详情，含对话记录)
"""

import os
import sys
import json
import time
from datetime import datetime
from typing import Dict, List, Optional

from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.acs_exception.exceptions import ClientException, ServerException

_current_dir = os.path.dirname(os.path.abspath(__file__))
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)

from config import (
    ALIYUN_INSTANCE_ID,
    ALIYUN_REGION_ID,
    ALIYUN_CALLER_NUMBER,
    BOOKING_RESULT_TAGS,
    SCREENING_RESULT_TAGS,
)


# ========== 客户端复用 ==========


def _get_client():
    """复用 aliyun_caller 的客户端"""
    from aliyun_caller import _get_client as get_aliyun_client

    return get_aliyun_client()


# ========== 查询任务列表 ==========


def query_job_group_results(job_group_id: str, instance_id: str = None) -> Dict:
    """
    查询任务组下所有外呼任务的结果

    Args:
        job_group_id: 任务组ID
        instance_id: 实例ID（可选，默认从配置读取）

    Returns:
        {
            "success": bool,
            "jobs": [
                {
                    "job_id": str,
                    "phone": str,
                    "status": str,           # 任务状态：Completed/Running/Failed
                    "call_status": str,      # 通话状态：Answered/NoAnswer/Busy
                    "call_duration": int,    # 通话时长（秒）
                    "summary": str,          # 对话摘要/结果标记
                    "intent": str,           # 意图标签
                    "hangup_by": str,        # 挂断方：robot/customer
                    "reference_id": str,     # 关联ID
                    "start_time": str,       # 呼叫时间
                    "end_time": str,         # 结束时间
                }
            ],
            "total": int,
            "message": str
        }
    """
    client = _get_client()

    if not instance_id:
        instance_id = ALIYUN_INSTANCE_ID

    if not instance_id:
        return {"success": False, "jobs": [], "total": 0, "message": "实例ID未配置"}

    try:
        from aliyunsdkoutboundbot.request.v20191226.QueryJobsRequest import (
            QueryJobsRequest,
        )

        request = QueryJobsRequest()
        request.set_accept_format("json")
        request.set_protocol_type("https")
        request.set_InstanceId(instance_id)
        request.set_JobGroupId(job_group_id)
        request.set_PageNumber(1)
        request.set_PageSize(100)

        response = client.do_action_with_exception(request)
        result = json.loads(response)

        jobs_data = result.get("Jobs", [])
        if isinstance(jobs_data, dict):
            jobs_list = jobs_data.get("List", []) or jobs_data.get("Job", [])
        elif isinstance(jobs_data, list):
            jobs_list = jobs_data
        else:
            jobs_list = []

        parsed_jobs = []
        for job in jobs_list:
            job_id = job.get("JobId", "")
            # 从 Extras 提取候选人信息
            extras = job.get("Extras", [])
            candidate_name = ""
            for ext in extras:
                if ext.get("Key") == "candidateName":
                    candidate_name = ext.get("Value", "")

            parsed_jobs.append(
                {
                    "job_id": job_id,
                    "phone": job.get("CalledNumber", ""),
                    "name": candidate_name,
                    "status": job.get("Status", ""),
                    "call_status": job.get("CallStatus", ""),
                    "call_duration": job.get("Duration", 0),
                    "summary": job.get("Summary", ""),
                    "intent": job.get("Intent", ""),
                    "hangup_by": job.get("HangupBy", ""),
                    "reference_id": job.get("ReferenceId", ""),
                    "start_time": job.get("StartTime", ""),
                    "end_time": job.get("EndTime", ""),
                }
            )

        # 补充：用 ListJobs API 获取对话记录和通话详情
        try:
            from aliyunsdkoutboundbot.request.v20191226 import ListJobsRequest
            import re as _re

            for pj in parsed_jobs:
                if not pj["job_id"]:
                    continue
                lreq = ListJobsRequest.ListJobsRequest()
                lreq.set_InstanceId(instance_id)
                lreq.set_JobIds([pj["job_id"]])
                lresp = client.do_action_with_exception(lreq)
                ldata = json.loads(lresp)
                ljobs = ldata.get("Jobs", [])
                if ljobs:
                    ljob = ljobs[0]
                    # 补充通话详情
                    if not pj["phone"]:
                        pj["phone"] = ljob.get("CalledNumber", "")
                    if not pj["call_duration"]:
                        pj["call_duration"] = ljob.get("Duration", 0)

                    # 从对话中提取预约时段
                    tasks = ljob.get("Tasks", [])
                    for task in tasks:
                        conv = task.get("Conversation", [])
                        for msg in reversed(conv):
                            if msg.get("Speaker") != "Robot":
                                continue
                            text = msg.get("Script", "")
                            if "已为您预约" not in text and "已预约" not in text:
                                continue
                            date_match = _re.search(
                                r"(?:\d{4}年)?(\d{1,2})月(\d{1,2})[日号]", text
                            )
                            time_match = _re.search(r"(\d{1,2})[:：](\d{1,2})", text)
                            if date_match:
                                date_str = (
                                    f"{date_match.group(1)}月{date_match.group(2)}日"
                                )
                                if time_match:
                                    slot_str = (
                                        f"{time_match.group(1)}:{time_match.group(2)}"
                                    )
                                    pj["summary"] = f"已预约{date_str}{slot_str}"
                                else:
                                    pj["summary"] = f"已预约{date_str}"
                                break
                        break
        except Exception as e:
            pass

        return {
            "success": True,
            "jobs": parsed_jobs,
            "total": len(parsed_jobs),
            "message": f"查询到 {len(parsed_jobs)} 个任务",
        }

    except ServerException as e:
        return {"success": False, "jobs": [], "total": 0, "message": f"API错误: {e}"}
    except ClientException as e:
        return {"success": False, "jobs": [], "total": 0, "message": f"网络错误: {e}"}
    except Exception as e:
        return {"success": False, "jobs": [], "total": 0, "message": f"查询异常: {e}"}


# ========== 解析预约结果 ==========


def parse_booking_result(job: Dict) -> Dict:
    """
    解析单个外呼任务的预约结果

    从 summary 和 intent 字段中提取预约状态

    Returns:
        {
            "phone": str,
            "status": str,          # 预约状态标记
            "status_cn": str,       # 中文状态描述
            "selected_slot": str,   # 选择的时间段（如适用）
            "call_duration": int,   # 通话时长
            "call_answered": bool,  # 是否接通
            "raw_summary": str,     # 原始摘要
        }
    """
    summary = job.get("summary", "") or ""
    intent = job.get("intent", "") or ""
    combined = f"{summary} {intent}"

    # 解析预约状态
    status = "UNKNOWN"
    status_cn = "未知"

    for tag_key, tag_value in BOOKING_RESULT_TAGS.items():
        if tag_value in combined or tag_key in combined:
            status = tag_key
            status_cn = tag_value
            break

    # 如果没有匹配到标记，根据通话状态判断
    if status == "UNKNOWN":
        call_status = job.get("call_status", "")
        if call_status in ("NoAnswer", "Busy", "Failed"):
            status = "UNREACHABLE"
            status_cn = BOOKING_RESULT_TAGS["UNREACHABLE"]

    # 尝试从 summary 中提取选择的时间段
    selected_slot = ""
    if status == "BOOKED":
        # summary 中可能包含 "已预约: 时间段A" 或 "Booked: A" 等
        for slot_label in [
            "A",
            "B",
            "C",
            "时间段A",
            "时间段B",
            "时间段C",
            "slot_a",
            "slot_b",
            "slot_c",
        ]:
            if slot_label in combined:
                selected_slot = slot_label
                break
        # 也可能直接包含具体时间
        if not selected_slot:
            selected_slot = summary.strip()

    return {
        "phone": job.get("phone", ""),
        "status": status,
        "status_cn": status_cn,
        "selected_slot": selected_slot,
        "call_duration": job.get("call_duration", 0),
        "call_answered": job.get("call_status", "") == "Answered",
        "raw_summary": summary,
    }


# ========== 筛选模式 - 结果解析 ==========


def parse_screening_result(job: Dict) -> Dict:
    """
    解析筛选模式的外呼结果

    大模型对话的summary中可能包含的关键信息：
    - 意向城市（城市B/城市A）
    - 实习时长
    - 到岗时间
    - 面试预约结果（日期+时段+线下/远程）
    - 退出原因（号码错误/无意向/实习不足/通勤不便）

    Returns:
        {
            "phone": str,
            "status": str,          # 预约状态标记
            "status_cn": str,       # 中文状态描述
            "selected_slot": str,   # 预约的时间（如适用）
            "call_duration": int,   # 通话时长
            "call_answered": bool,  # 是否接通
            "raw_summary": str,     # 原始摘要
        }
    """
    summary = job.get("summary", "") or ""
    intent = job.get("intent", "") or ""
    combined = f"{summary} {intent}"

    # 解析状态：先匹配 SCREENING_RESULT_TAGS，再匹配 BOOKING_RESULT_TAGS（兼容）
    status = "UNKNOWN"
    status_cn = "未知"

    all_tags = {**SCREENING_RESULT_TAGS, **BOOKING_RESULT_TAGS}
    for tag_key, tag_value in all_tags.items():
        if tag_value in combined or tag_key in combined:
            status = tag_key
            status_cn = tag_value
            break

    # 如果没有匹配到标记，根据通话状态判断
    if status == "UNKNOWN":
        call_status = job.get("call_status", "")
        if call_status in ("NoAnswer", "Busy", "Failed"):
            status = "UNREACHABLE"
            status_cn = all_tags.get("UNREACHABLE", "未接通")

    # 尝试从summary中提取预约时间
    selected_slot = ""
    if status in ("BOOKED", "已预约"):
        # 大模型summary可能包含 "预约7月15日下午3点" 等
        import re

        time_match = re.search(
            r"(\d{1,2}月\d{1,2}日.*?(?:上午|下午|点)\d*(?:分)?)", combined
        )
        if time_match:
            selected_slot = time_match.group(1)
        else:
            selected_slot = summary.strip()[:50]  # 截取前50字符

    return {
        "job_id": job.get("job_id", ""),
        "phone": job.get("phone", ""),
        "name": job.get("name", ""),
        "status": status,
        "status_cn": status_cn,
        "selected_slot": selected_slot,
        "call_duration": job.get("call_duration", 0),
        "call_answered": job.get("call_status", "") == "Answered",
        "raw_summary": summary,
    }


def query_and_summarize_screening(
    job_group_id: str, candidates: List[Dict] = None
) -> Dict:
    """
    查询筛选模式任务组结果并汇总

    汇总维度：已预约/号码错误/无意向/实习不足/通勤不便/未接通/未知

    Returns:
        {
            "success": bool,
            "summary": {...},
            "details": [...],
            "message": str
        }
    """
    result = query_job_group_results(job_group_id)

    if not result["success"]:
        return {
            "success": False,
            "summary": {},
            "details": [],
            "message": result["message"],
        }

    # 构建手机号到姓名的映射
    phone_to_name = {}
    if candidates:
        for c in candidates:
            phone_to_name[c.get("phone", "")] = c.get("name", "未知")

    # 解析每个任务结果
    details = []
    summary_counts = {
        "total": 0,
        "booked": 0,
        "wrong_number": 0,
        "no_interest": 0,
        "internship_fail": 0,
        "commute_fail": 0,
        "need_hr": 0,
        "unreachable": 0,
        "unknown": 0,
    }

    for job in result["jobs"]:
        parsed = parse_screening_result(job)
        # 优先用 phone 匹配，fallback 到 job 自带的 name
        name = phone_to_name.get(parsed["phone"], "")
        if not name:
            name = job.get("name", "未知")
        parsed["name"] = name

        details.append(parsed)
        summary_counts["total"] += 1

        status_key = parsed["status"].lower()
        if status_key == "booked":
            summary_counts["booked"] += 1
        elif status_key == "wrong_number":
            summary_counts["wrong_number"] += 1
        elif status_key == "no_interest":
            summary_counts["no_interest"] += 1
        elif status_key == "internship_fail":
            summary_counts["internship_fail"] += 1
        elif status_key == "commute_fail":
            summary_counts["commute_fail"] += 1
        elif status_key == "need_hr":
            summary_counts["need_hr"] += 1
        elif status_key == "unreachable":
            summary_counts["unreachable"] += 1
        else:
            summary_counts["unknown"] += 1

    return {
        "success": True,
        "summary": summary_counts,
        "details": details,
        "message": f"查询完成: {summary_counts['total']}个任务，已预约{summary_counts['booked']}个",
    }


def print_screening_report(result: Dict):
    """打印筛选模式外呼结果报告"""
    print("\n" + "=" * 60)
    print("  招聘筛选外呼结果报告（大模型对话）")
    print(f"  查询时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    if not result["success"]:
        print(f"\n[FAIL] 查询失败: {result['message']}")
        return

    s = result["summary"]
    print(f"\n  汇总统计:")
    print(f"    总任务数:       {s['total']}")
    print(f"    已预约:         {s['booked']}")
    print(f"    号码错误:       {s['wrong_number']}")
    print(f"    无意向:         {s['no_interest']}")
    print(f"    实习不足不接受: {s['internship_fail']}")
    print(f"    通勤不便:       {s['commute_fail']}")
    print(f"    需HR协调:       {s['need_hr']}")
    print(f"    未接通:         {s['unreachable']}")
    print(f"    未知:           {s['unknown']}")

    print(f"\n  详细结果:")
    print(
        f"  {'姓名':<8} {'手机号':<14} {'状态':<12} {'预约时段':<20} {'通话时长':<10} {'接通'}"
    )
    print(f"  {'-' * 8} {'-' * 14} {'-' * 12} {'-' * 20} {'-' * 10} {'-' * 4}")

    for d in result["details"]:
        duration_str = f"{d['call_duration']}秒" if d["call_duration"] else "-"
        answered_str = "是" if d["call_answered"] else "否"
        slot_display = d["selected_slot"][:18] if d["selected_slot"] else "-"
        print(
            f"  {d['name']:<8} {d['phone']:<14} {d['status_cn']:<12} {slot_display:<20} {duration_str:<10} {answered_str}"
        )

    print(f"\n{'=' * 60}")


# ========== 查询并汇总结果 ==========


def query_and_summarize(job_group_id: str, candidates: List[Dict] = None) -> Dict:
    """
    查询任务组结果并汇总

    Args:
        job_group_id: 任务组ID
        candidates: 候选人列表（可选，用于关联姓名）

    Returns:
        {
            "success": bool,
            "summary": {
                "total": int,
                "booked": int,          # 已预约
                "no_interest": int,     # 无意向
                "wrong_number": int,    # 号码错误
                "need_hr": int,         # 需HR协调
                "considering": int,     # 考虑中
                "unreachable": int,     # 未接通
                "unknown": int,         # 未知
            },
            "details": [
                {
                    "name": str,
                    "phone": str,
                    "status": str,
                    "status_cn": str,
                    "selected_slot": str,
                    "call_duration": int,
                    "call_answered": bool,
                }
            ],
            "message": str
        }
    """
    result = query_job_group_results(job_group_id)

    if not result["success"]:
        return {
            "success": False,
            "summary": {},
            "details": [],
            "message": result["message"],
        }

    # 构建手机号到姓名的映射
    phone_to_name = {}
    if candidates:
        for c in candidates:
            phone_to_name[c.get("phone", "")] = c.get("name", "未知")

    # 解析每个任务结果
    details = []
    summary_counts = {
        "total": 0,
        "booked": 0,
        "no_interest": 0,
        "wrong_number": 0,
        "need_hr": 0,
        "considering": 0,
        "unreachable": 0,
        "unknown": 0,
    }

    for job in result["jobs"]:
        parsed = parse_booking_result(job)

        # 关联候选人姓名
        name = phone_to_name.get(parsed["phone"], "")
        if not name:
            name = job.get("name", "未知")
        parsed["name"] = name

        details.append(parsed)
        summary_counts["total"] += 1

        status_key = parsed["status"].lower()
        if status_key == "booked":
            summary_counts["booked"] += 1
        elif status_key == "no_interest":
            summary_counts["no_interest"] += 1
        elif status_key == "wrong_number":
            summary_counts["wrong_number"] += 1
        elif status_key == "need_hr":
            summary_counts["need_hr"] += 1
        elif status_key == "considering":
            summary_counts["considering"] += 1
        elif status_key == "unreachable":
            summary_counts["unreachable"] += 1
        else:
            summary_counts["unknown"] += 1

    return {
        "success": True,
        "summary": summary_counts,
        "details": details,
        "message": f"查询完成: {summary_counts['total']}个任务，已预约{summary_counts['booked']}个",
    }


# ========== Excel 导出功能 ==========


def extract_detail_from_conversation(job_id, instance_id=None):
    """从 ListJobs 对话记录中提取完整信息"""
    import re as _re
    from aliyunsdkoutboundbot.request.v20191226 import ListJobsRequest

    if not instance_id:
        instance_id = ALIYUN_INSTANCE_ID

    client = _get_client()

    lreq = ListJobsRequest.ListJobsRequest()
    lreq.set_InstanceId(instance_id)
    lreq.set_JobIds([job_id])
    lresp = client.do_action_with_exception(lreq)
    ldata = json.loads(lresp)
    ljobs = ldata.get("Jobs", [])
    if not ljobs:
        return {}

    ljob = ljobs[0]

    # 从 Task 层级提取通话详情
    tasks = ljob.get("Tasks", [])
    task_info = tasks[0] if tasks else {}

    info = {
        "phone": task_info.get("CalledNumber", "") or ljob.get("CalledNumber", ""),
        "call_duration": task_info.get("Duration", 0) or ljob.get("Duration", 0),
        "call_answered": ljob.get("Status", "") == "Succeeded",
    }

    # 从 Extras 提取候选人信息
    extras = ljob.get("Extras", [])
    for ext in extras:
        key = ext.get("Key", "")
        val = ext.get("Value", "")
        if key == "candidateName":
            info["name"] = val
        elif key == "candidateCity":
            info["intent_city"] = val
        elif key == "positionName":
            info["position"] = val

    # 从对话中提取信息
    all_robot_text = ""
    all_contact_text = ""
    conv_text = ""

    for task in tasks:
        conv = task.get("Conversation", [])
        for msg in conv:
            speaker = msg.get("Speaker", "")
            script = msg.get("Script", "")
            conv_text += f"[{speaker}] {script}\n"
            if speaker == "Robot":
                all_robot_text += script + " "
            elif speaker == "Contact":
                all_contact_text += script + " "

    info["conversation"] = conv_text

    # 按轮次定位提取，避免全文拼接后误匹配
    conv_list = []
    for task in tasks:
        conv_list.extend(task.get("Conversation", []))

    # 提取实习时长 - 找机器人问"实习多长时间"后的下一条候选人回复
    info["internship_duration"] = ""
    cn_num_map = {
        "一": "1",
        "二": "2",
        "两": "2",
        "三": "3",
        "四": "4",
        "五": "5",
        "六": "6",
        "七": "7",
        "八": "8",
        "九": "9",
        "十": "10",
    }
    for i, msg in enumerate(conv_list):
        if msg.get("Speaker") == "Robot" and (
            "实习" in msg.get("Script", "")
            and (
                "多长" in msg.get("Script", "")
                or "多久" in msg.get("Script", "")
                or "几个月" in msg.get("Script", "")
            )
        ):
            for j in range(i + 1, min(i + 4, len(conv_list))):
                if conv_list[j].get("Speaker") == "Contact":
                    reply = conv_list[j].get("Script", "")
                    # 匹配阿拉伯数字：3个月、3-6个月
                    dur_m = _re.search(r"(\d+)\s*[-~]\s*(\d+)\s*个?\s*月", reply)
                    if dur_m:
                        info["internship_duration"] = (
                            f"{dur_m.group(1)}-{dur_m.group(2)}个月"
                        )
                        break
                    dur_m = _re.search(r"(\d+)\s*个?\s*月", reply)
                    if dur_m:
                        info["internship_duration"] = dur_m.group(1) + "个月"
                        break
                    # 匹配中文数字：三个月、两三个月
                    dur_m = _re.search(
                        r"([一二两三四五六七八九十]+)\s*[-~]\s*([一二两三四五六七八九十]+)\s*个?\s*月",
                        reply,
                    )
                    if dur_m:
                        n1 = cn_num_map.get(dur_m.group(1), dur_m.group(1))
                        n2 = cn_num_map.get(dur_m.group(2), dur_m.group(2))
                        info["internship_duration"] = f"{n1}-{n2}个月"
                        break
                    dur_m = _re.search(r"([一二两三四五六七八九十]+)\s*个?\s*月", reply)
                    if dur_m:
                        n = cn_num_map.get(dur_m.group(1), dur_m.group(1))
                        info["internship_duration"] = n + "个月"
                        break
            break

    # 提取到岗时间 - 找机器人问"到岗"后的候选人回复，跳过"嗯""哦"等无意义回复
    info["arrival_time"] = ""
    for i, msg in enumerate(conv_list):
        if msg.get("Speaker") == "Robot" and "到岗" in msg.get("Script", ""):
            for j in range(i + 1, min(i + 6, len(conv_list))):
                if conv_list[j].get("Speaker") == "Contact":
                    reply = conv_list[j].get("Script", "").strip()
                    # 跳过"嗯""哦""啊"等无意义回复
                    if (
                        reply in ("嗯", "嗯。", "哦", "啊", "呃", "是的", "对")
                        or len(reply) <= 2
                    ):
                        continue
                    arr_m = _re.search(
                        r"(两天|下?周[一二三四五六日天]|明天|后天|今天|这周|下周|\d+号|\d+日|尽快|随时)",
                        reply,
                    )
                    if arr_m:
                        info["arrival_time"] = arr_m.group(0)
                    else:
                        info["arrival_time"] = reply[:10]
                    break
            break

    # 提取通勤情况 - 找机器人问"通勤"后的下一条候选人回复
    info["commute"] = ""
    for i, msg in enumerate(conv_list):
        if msg.get("Speaker") == "Robot" and "通勤" in msg.get("Script", ""):
            for j in range(i + 1, min(i + 4, len(conv_list))):
                if conv_list[j].get("Speaker") == "Contact":
                    reply = conv_list[j].get("Script", "")
                    if "不方便" in reply or "太远" in reply or "不行" in reply:
                        info["commute"] = "不方便"
                    elif (
                        "方便" in reply
                        or "可以" in reply
                        or "还行" in reply
                        or "还好" in reply
                    ):
                        info["commute"] = "方便"
                    break
            break

    # 判断面试类型 - 机器人提到"远程面试"就是线上
    if "远程面试" in all_robot_text:
        info["interview_type"] = "线上"
    else:
        info["interview_type"] = "线下"

    # 提取预约时间（含中文数字兜底，与 batch_call.py 保持一致）
    CN_NUM_MAP = {
        "零": 0,
        "〇": 0,
        "一": 1,
        "二": 2,
        "两": 2,
        "三": 3,
        "四": 4,
        "五": 5,
        "六": 6,
        "七": 7,
        "八": 8,
        "九": 9,
        "十": 10,
    }

    def _cn_to_int(s):
        if s.isdigit():
            return int(s)
        if "十" in s:
            parts = s.split("十")
            tens = CN_NUM_MAP.get(parts[0], 1) if parts[0] else 1
            ones = CN_NUM_MAP.get(parts[1], 0) if len(parts) > 1 and parts[1] else 0
            return tens * 10 + ones
        val = 0
        for ch in s:
            if ch in CN_NUM_MAP:
                val = val * 10 + CN_NUM_MAP[ch]
            elif ch.isdigit():
                val = val * 10 + int(ch)
        return val

    for msg in reversed(tasks[0].get("Conversation", []) if tasks else []):
        if msg.get("Speaker") != "Robot":
            continue
        text = msg.get("Script", "")
        if "已为您预约" not in text and "已预约" not in text:
            continue
        date_match = _re.search(r"(?:\d{4}年)?(\d{1,2})月(\d{1,2})[日号]", text)
        if not date_match:
            continue

        month = date_match.group(1)
        day = date_match.group(2)
        date_str = f"{month}月{day}日"

        # 时间提取：阿拉伯数字优先，中文数字兜底
        time_match = _re.search(r"(\d{1,2})[:：](\d{1,2})", text)
        if not time_match:
            time_match = _re.search(r"(\d{1,2})点(\d{1,2})\s*分?", text)
        if not time_match:
            time_match = _re.search(r"(\d{1,2})点半", text)
        if not time_match:
            time_match = _re.search(r"(\d{1,2})点(?!\d|半|分)", text)

        if time_match:
            hour = int(time_match.group(1))
            if (
                time_match.lastindex >= 2
                and time_match.group(2)
                and time_match.group(2).isdigit()
            ):
                minute = int(time_match.group(2))
            elif "点半" in text:
                minute = 30
            else:
                minute = 0
            if "下午" in text and hour < 12:
                hour += 12
            slot_str = f"{hour:02d}:{minute:02d}"
            info["booked_date"] = date_str
            info["booked_slot"] = slot_str
            info["booked_time"] = f"{date_str} {slot_str}"
            info["status"] = "BOOKED"
            info["status_cn"] = "已预约"
        else:
            # 中文数字兜底
            cn_match = _re.search(
                r"([一二两三四五六七八九零〇十]{1,3})点([一二两三四五六七八九零〇十]{1,3})\s*分?",
                text,
            )
            if cn_match:
                hour = _cn_to_int(cn_match.group(1))
                minute = _cn_to_int(cn_match.group(2))
                if "下午" in text and hour < 12:
                    hour += 12
                slot_str = f"{hour:02d}:{minute:02d}"
                info["booked_date"] = date_str
                info["booked_slot"] = slot_str
                info["booked_time"] = f"{date_str} {slot_str}"
                info["status"] = "BOOKED"
                info["status_cn"] = "已预约"
            else:
                cn_half = _re.search(r"([一二两三四五六七八九零〇十]{1,3})点半", text)
                if cn_half:
                    hour = _cn_to_int(cn_half.group(1))
                    if "下午" in text and hour < 12:
                        hour += 12
                    info["booked_date"] = date_str
                    info["booked_slot"] = f"{hour:02d}:30"
                    info["booked_time"] = f"{date_str} {hour:02d}:30"
                    info["status"] = "BOOKED"
                    info["status_cn"] = "已预约"
                else:
                    cn_whole = _re.search(
                        r"([一二两三四五六七八九零〇十]{1,3})点整", text
                    )
                    if cn_whole:
                        hour = _cn_to_int(cn_whole.group(1))
                        if "下午" in text and hour < 12:
                            hour += 12
                        info["booked_date"] = date_str
                        info["booked_slot"] = f"{hour:02d}:00"
                        info["booked_time"] = f"{date_str} {hour:02d}:00"
                        info["status"] = "BOOKED"
                        info["status_cn"] = "已预约"
                    else:
                        info["booked_date"] = date_str
                        info["booked_time"] = date_str
                        info["status"] = "BOOKED"
                        info["status_cn"] = "已预约"
        break

    # 如果没有预约，判断其他状态并生成情况概述
    if "status" not in info:
        if (
            "号码错误" in all_robot_text
            or "打错了" in all_contact_text
            or "不是" in all_contact_text
        ):
            info["status"] = "WRONG_NUMBER"
            info["status_cn"] = "号码错误"
            info["status_desc"] = "候选人否认身份或表示打错电话"
        elif "找到了" in all_contact_text or "已入职" in all_contact_text:
            info["status"] = "NO_INTEREST"
            info["status_cn"] = "无意向"
            info["status_desc"] = "候选人已找到工作或已入职"
        elif "不考虑" in all_contact_text or "不想" in all_contact_text:
            info["status"] = "NO_INTEREST"
            info["status_cn"] = "无意向"
            info["status_desc"] = "候选人明确表示不考虑该岗位"
        elif "不方便" in all_contact_text and (
            "稍后" in all_robot_text or "再联系" in all_robot_text or "其他时间" in all_robot_text
        ):
            info["status"] = "CALLBACK_NEEDED"
            info["status_cn"] = "需回拨"
            info["status_desc"] = "候选人表示现在不方便接听，需稍后回拨"
        elif "不方便" in all_contact_text and "通勤" in all_robot_text:
            info["status"] = "COMMUTE_FAIL"
            info["status_cn"] = "通勤不便"
            info["status_desc"] = "候选人表示通勤不方便，放弃面试"
        elif "不能接受" in all_contact_text or "不行" in all_contact_text:
            info["status"] = "INTERNSHIP_FAIL"
            info["status_cn"] = "实习时长不足"
            info["status_desc"] = "候选人实习时长不满足要求"
        elif "考虑一下" in all_contact_text or "考虑考虑" in all_contact_text or "想一想" in all_contact_text:
            info["status"] = "CONSIDERING"
            info["status_cn"] = "考虑中"
            info["status_desc"] = "候选人表示需要考虑，未达成预约"
        elif not info.get("call_answered"):
            info["status"] = "UNREACHABLE"
            info["status_cn"] = "未接通"
            # 区分无人接听和无法接通
            if "无法接通" in all_robot_text or "停机" in all_robot_text or "关机" in all_robot_text:
                info["status_desc"] = "电话无法接通（停机/关机/空号）"
            else:
                info["status_desc"] = "电话无人接听，需回拨"
        else:
            info["status"] = "UNKNOWN"
            info["status_cn"] = "未预约"
            # 判断是否通话中途突然挂断：最后一条机器人有实质性提问但候选人无有效回复
            last_contact_msgs = []
            for m in reversed(conv_list):
                if m.get("Speaker") == "Contact":
                    last_contact_msgs.insert(0, m.get("Script", "").strip())
                    if len(last_contact_msgs) >= 3:
                        break
            # 过滤掉空内容和与J/K列重复的信息（实习时长、到岗时间）
            already_extracted = info.get("internship_duration", "") + info.get("arrival_time", "")
            meaningful_tail = []
            for msg in last_contact_msgs:
                if not msg:
                    continue
                # 跳过已提取到J/K列的内容
                if already_extracted and (
                    any(kw in msg for kw in ["个月", "到岗", "后天", "明天", "下周", "这周", "尽快", "随时"])
                ):
                    continue
                meaningful_tail.append(msg)
            # 判断突然挂断：最后一条Contact消息为空，或对话在机器人提问后突然结束
            last_msg = conv_list[-1] if conv_list else {}
            last_robot_has_question = (
                last_msg.get("Speaker") == "Robot"
                and ("？" in last_msg.get("Script", "") or "?" in last_msg.get("Script", ""))
            )
            last_contact_empty = (
                last_msg.get("Speaker") == "Contact"
                and not last_msg.get("Script", "").strip()
            )
            # 倒数第二条也是Contact空回复（阿里云模式：候选人挂断后Contact会留空消息）
            prev_contact_empty = False
            if len(conv_list) >= 2:
                prev = conv_list[-2]
                if prev.get("Speaker") == "Contact" and not prev.get("Script", "").strip():
                    prev_contact_empty = True

            if last_contact_empty or last_robot_has_question or prev_contact_empty:
                # 通话中途被挂断
                tail_summary = "；".join(meaningful_tail)[:60] if meaningful_tail else ""
                if tail_summary:
                    info["status_desc"] = f"通话中途被挂断，未能完成预约（候选人此前回复：{tail_summary}）"
                else:
                    info["status_desc"] = "通话中途被挂断，未能完成预约"
            else:
                tail = "；".join(meaningful_tail)[:60]
                if tail:
                    info["status_desc"] = f"对话结束未达成预约，候选人末尾回复：{tail}"
                else:
                    info["status_desc"] = "对话结束未达成预约，原因不明"

    return info


def export_results_to_excel(result: Dict, output_path: str = None):
    """
    将外呼结果导出为 Excel 文件（面试邀约格式）

    单 Sheet，12列：
    A:初试时间  B:职位  C:名字  D:电话  E:地区  F:渠道  G:复试邀约时间  H:是否改约  I:复试日期
    J:实习时长  K:到岗时间  L:通勤情况
    """
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    import re as _re

    if not output_path:
        output_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "..",
            "output",
            "外呼结果报告.xlsx",
        )

    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # 样式定义
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin_border = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    booked_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    no_slot_fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
    conflict_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")

    # 从对话记录提取完整信息
    enhanced_details = []
    for job in result.get("details", []):
        job_id = job.get("job_id", "")
        if job_id:
            try:
                detail_info = extract_detail_from_conversation(job_id)
                detail_info["name"] = job.get("name", detail_info.get("name", "未知"))
                enhanced_details.append(detail_info)
            except Exception as e:
                enhanced_details.append(
                    {
                        "name": job.get("name", "未知"),
                        "phone": job.get("phone", ""),
                        "status": job.get("status", "UNKNOWN"),
                        "status_cn": job.get("status_cn", "未知"),
                        "status_desc": "查询对话详情失败",
                        "booked_time": job.get("selected_slot", ""),
                    }
                )
        else:
            enhanced_details.append(job)

    # 冲突检测
    slot_count = {}
    for d in enhanced_details:
        bt = d.get("booked_time", "")
        if bt:
            slot_count[bt] = slot_count.get(bt, 0) + 1
    for d in enhanced_details:
        bt = d.get("booked_time", "")
        d["slot_conflict"] = bt and slot_count.get(bt, 0) > 1

    # ========== 创建 Excel ==========
    wb = Workbook()
    ws = wb.active
    ws.title = "面试邀约"

    # 表头 - 12列
    headers = [
        "初试时间", "职位", "名字", "电话", "地区", "渠道",
        "复试邀约时间", "是否改约", "复试日期",
        "实习时长", "到岗时间", "通勤情况",
    ]
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.value = header
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = thin_border

    # 数据行
    today_str = datetime.now().strftime("%Y-%m-%d")
    for idx, d in enumerate(enhanced_details, 2):
        status = d.get("status", "")
        status_cn = d.get("status_cn", "")
        booked_time = d.get("booked_time", "")
        status_desc = d.get("status_desc", "")

        # A: 初试时间
        ws.cell(row=idx, column=1, value=today_str)

        # B: 职位
        ws.cell(row=idx, column=2, value=d.get("position", ""))

        # C: 名字
        ws.cell(row=idx, column=3, value=d.get("name", "未知"))

        # D: 电话
        phone_val = d.get("phone", "")
        if phone_val:
            ws.cell(row=idx, column=4).value = str(phone_val)
            ws.cell(row=idx, column=4).number_format = "@"

        # E: 地区
        ws.cell(row=idx, column=5, value=d.get("intent_city", ""))

        # F: 渠道
        ws.cell(row=idx, column=6, value="招聘平台")

        # G: 复试邀约时间 - 已预约显示时段，未预约显示情况说明
        if booked_time:
            g_val = booked_time
        elif status_desc:
            g_val = status_desc
        elif status_cn and status_cn != "已预约":
            g_val = status_cn
        else:
            g_val = "未提取到预约信息"
        ws.cell(row=idx, column=7, value=g_val)

        # H: 是否改约
        if status == "BOOKED":
            h_val = ""
        elif status in ("NO_INTEREST", "WRONG_NUMBER", "COMMUTE_FAIL", "INTERNSHIP_FAIL", "UNREACHABLE", "CALLBACK_NEEDED", "CONSIDERING"):
            h_val = "否"
        elif status == "NEED_HR":
            h_val = "是"
        else:
            h_val = "否"
        ws.cell(row=idx, column=8, value=h_val)

        # I: 复试日期
        booked_date = d.get("booked_date", "")
        if booked_date:
            date_m = _re.search(r"(\d{1,2})月(\d{1,2})日", booked_date)
            if date_m:
                try:
                    month = int(date_m.group(1))
                    day = int(date_m.group(2))
                    ws.cell(row=idx, column=9, value=datetime(datetime.now().year, month, day))
                    ws.cell(row=idx, column=9).number_format = "yyyy/m/d"
                except (ValueError, OSError):
                    ws.cell(row=idx, column=9, value=booked_date)
            else:
                ws.cell(row=idx, column=9, value=booked_date)
        else:
            ws.cell(row=idx, column=9, value="")

        # J: 实习时长
        intern = d.get("internship_duration", "")
        ws.cell(row=idx, column=10, value=intern if intern else "未提及")

        # K: 到岗时间
        arrival = d.get("arrival_time", "")
        ws.cell(row=idx, column=11, value=arrival if arrival else "未提及")

        # L: 通勤情况
        commute = d.get("commute", "")
        if commute:
            ws.cell(row=idx, column=12, value=commute)
        elif d.get("interview_type") == "线上":
            ws.cell(row=idx, column=12, value="线上面试")
        else:
            ws.cell(row=idx, column=12, value="未提及")

        # 行样式
        for col in range(1, 13):
            cell = ws.cell(row=idx, column=col)
            cell.border = thin_border
            cell.alignment = Alignment(vertical="center", wrap_text=True)
            if d.get("slot_conflict"):
                cell.fill = conflict_fill
            elif status == "BOOKED":
                cell.fill = booked_fill
            elif not booked_time:
                cell.fill = no_slot_fill

    # 列宽
    col_widths = [12, 22, 10, 14, 8, 10, 35, 10, 12, 12, 12, 12]
    for idx, width in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(idx)].width = width

    wb.save(output_path)
    return output_path


# ========== 打印结果报告 ==========


def print_result_report(result: Dict):
    """打印外呼结果报告"""
    print("\n" + "=" * 60)
    print("  面试预约外呼结果报告")
    print(f"  查询时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    if not result["success"]:
        print(f"\n[FAIL] 查询失败: {result['message']}")
        return

    s = result["summary"]
    print(f"\n  汇总统计:")
    print(f"    总任务数:   {s['total']}")
    print(f"    已预约:     {s['booked']}")
    print(f"    无意向:     {s['no_interest']}")
    print(f"    号码错误:   {s['wrong_number']}")
    print(f"    需HR协调:   {s['need_hr']}")
    print(f"    考虑中:     {s['considering']}")
    print(f"    未接通:     {s['unreachable']}")
    print(f"    未知:       {s['unknown']}")

    print(f"\n  详细结果:")
    print(
        f"  {'姓名':<8} {'手机号':<14} {'状态':<10} {'选择时段':<16} {'通话时长':<10} {'接通'}"
    )
    print(f"  {'-' * 8} {'-' * 14} {'-' * 10} {'-' * 16} {'-' * 10} {'-' * 4}")

    for d in result["details"]:
        duration_str = f"{d['call_duration']}秒" if d["call_duration"] else "-"
        answered_str = "是" if d["call_answered"] else "否"
        print(
            f"  {d['name']:<8} {d['phone']:<14} {d['status_cn']:<10} {d['selected_slot']:<16} {duration_str:<10} {answered_str}"
        )

    print(f"\n{'=' * 60}")


# ========== 主入口 ==========

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="查询外呼结果")
    parser.add_argument("job_group_id", help="任务组ID")
    parser.add_argument("--candidates-file", help="候选人JSON文件路径（用于关联姓名）")
    parser.add_argument(
        "--export-excel", action="store_true", help="导出结果到Excel文件"
    )
    parser.add_argument("--output-path", help="Excel输出文件路径（可选）")
    parser.add_argument(
        "--screening", action="store_true", help="使用筛选模式（大模型对话）解析结果"
    )
    args = parser.parse_args()

    candidates = None
    if args.candidates_file:
        try:
            with open(args.candidates_file, "r", encoding="utf-8") as f:
                candidates = json.load(f)
        except Exception as e:
            print(f"[WARN] 读取候选人文件失败: {e}")

    # 选择查询模式
    if args.screening:
        result = query_and_summarize_screening(args.job_group_id, candidates)
        print_screening_report(result)
    else:
        result = query_and_summarize(args.job_group_id, candidates)
        print_result_report(result)

    # 导出Excel
    if args.export_excel and result.get("success"):
        try:
            output_path = export_results_to_excel(result, args.output_path)
            print(f"\n[OK] Excel report exported: {output_path}")
        except Exception as e:
            print(f"\n[FAIL] Excel export failed: {e}")
