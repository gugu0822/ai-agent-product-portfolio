@echo off
chcp 65001 >nul
title 面试提醒Agent - 预览模式

cd /d "%~dp0.dumate\scripts"
python main.py --dry-run
pause
