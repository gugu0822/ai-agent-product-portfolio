# -*- coding: utf-8 -*-
"""
面试提醒Agent - 输入校验模块

对所有候选人字段进行标准化校验和自动修正，
遇到无法修正的错误时抛出 CandidateValidationError。

标准输入格式（提醒模式）：
  name:           非空字符串，1-30字符
  phone:          11位数字手机号，如 13800138000
  position:       非空字符串，1-100字符
  interview_date: YYYY-MM-DD 格式，如 2026-07-09
  interview_time: HH:MM 格式（24小时制），如 14:30
  email:          可选，标准邮箱格式

预约模式额外字段：
  slot_a_time:    时间段A，格式 "YYYY-MM-DD HH:MM" 或 "M月D日 HH:MM"
  slot_b_time:    时间段B，同上
  slot_c_time:    时间段C，同上
  三个时间段不能重复
"""
import re
from datetime import datetime, date
from typing import Dict, Tuple, Optional


class CandidateValidationError(Exception):
    """候选人数据校验错误"""
    pass


# ========== 手机号校验 ==========

def validate_phone(phone) -> str:
    """
    校验并标准化手机号
    
    标准格式: 11位数字，如 13800138000
    
    自动修正:
      - "138-0013-8000" → "13800138000"
      - "138 0013 8000" → "13800138000"
      - "+86 13800138000" → "13800138000"
      - "+8613800138000" → "13800138000"
      - "8613800138000" → "13800138000"（如果以86开头且共13位）
    
    报错情况:
      - 空值
      - 去除非数字字符后不足11位
      - 去除非数字字符后超过13位
      - 不以1开头
    """
    if phone is None:
        raise CandidateValidationError("手机号为空（None）")
    
    phone_str = str(phone).strip()
    
    if not phone_str:
        raise CandidateValidationError("手机号为空字符串")
    
    # 去除所有非数字字符
    digits_only = re.sub(r'[^\d]', '', phone_str)
    
    # 去除国际区号
    if len(digits_only) > 11:
        if digits_only.startswith('86') and len(digits_only) == 13:
            digits_only = digits_only[2:]
        elif digits_only.startswith('0086') and len(digits_only) == 15:
            digits_only = digits_only[4:]
    
    if len(digits_only) != 11:
        raise CandidateValidationError(
            f"手机号位数不正确: 原始='{phone_str}', 去除非数字后='{digits_only}'（应为11位）"
        )
    
    if not digits_only.startswith('1'):
        raise CandidateValidationError(
            f"手机号格式不正确: '{digits_only}'（中国大陆手机号应以1开头）"
        )
    
    # 中国手机号第二位应为3-9
    second_digit = digits_only[1]
    if second_digit not in '3456789':
        raise CandidateValidationError(
            f"手机号格式不正确: '{digits_only}'（第二位应为3-9）"
        )
    
    return digits_only


# ========== 姓名校验 ==========

def validate_name(name) -> str:
    """
    校验候选人姓名
    
    标准格式: 非空字符串，1-30字符
    
    自动修正:
      - 前后空格去除
      - 中间多余空格压缩为单个
    
    报错情况:
      - 空值
      - 超过30字符
      - 包含特殊符号（<>${}等可能干扰系统的字符）
    """
    if name is None:
        raise CandidateValidationError("姓名为空（None）")
    
    name_str = str(name).strip()
    
    if not name_str:
        raise CandidateValidationError("姓名为空字符串")
    
    # 压缩中间多余空格
    name_str = re.sub(r'\s+', ' ', name_str)
    
    if len(name_str) > 30:
        raise CandidateValidationError(
            f"姓名过长: '{name_str[:10]}...'（{len(name_str)}字符，最多30字符）"
        )
    
    # 检查可能干扰阿里云变量系统的特殊字符
    dangerous_chars = ['$', '{', '}', '<', '>', '`']
    for ch in dangerous_chars:
        if ch in name_str:
            raise CandidateValidationError(
                f"姓名包含特殊字符'{ch}': '{name_str}'（请去除特殊符号）"
            )
    
    return name_str


# ========== 职位校验 ==========

def validate_position(position) -> str:
    """
    校验面试职位
    
    标准格式: 非空字符串，1-100字符
    
    自动修正:
      - 前后空格去除
      - 中间多余空格压缩为单个
    
    报错情况:
      - 空值
      - 超过100字符
      - 包含特殊符号（<>${}等）
    """
    if position is None:
        raise CandidateValidationError("面试职位为空（None）")
    
    pos_str = str(position).strip()
    
    if not pos_str:
        raise CandidateValidationError("面试职位为空字符串")
    
    pos_str = re.sub(r'\s+', ' ', pos_str)
    
    if len(pos_str) > 100:
        raise CandidateValidationError(
            f"职位名称过长: '{pos_str[:10]}...'（{len(pos_str)}字符，最多100字符）"
        )
    
    dangerous_chars = ['$', '{', '}', '<', '>', '`']
    for ch in dangerous_chars:
        if ch in pos_str:
            raise CandidateValidationError(
                f"职位包含特殊字符'{ch}': '{pos_str}'（请去除特殊符号）"
            )
    
    return pos_str


# ========== 日期校验 ==========

# 支持的日期格式列表（按优先级排序）
DATE_FORMATS = [
    "%Y-%m-%d",      # 2026-07-09（标准格式）
    "%Y/%m/%d",      # 2026/07/09
    "%Y.%m.%d",      # 2026.07.09
    "%Y%m%d",        # 20260709
    "%Y年%m月%d日",   # 2026年7月9日（注意：%m会匹配07）
    "%Y-%-m-%-d",    # 2026-7-9（无前导零，Linux有效）
]

# 手动匹配中文日期（Python strptime对中文日期处理不稳定）
CN_DATE_PATTERN = re.compile(r'^(\d{4})年(\d{1,2})月(\d{1,2})日?$')

# 手动匹配 M.D 或 M月D日 格式（无年份，默认当年）
SHORT_DATE_PATTERN = re.compile(r'^(\d{1,2})[./](\d{1,2})$')
SHORT_CN_DATE_PATTERN = re.compile(r'^(\d{1,2})月(\d{1,2})日?$')


def validate_date(date_value, field_name="interview_date") -> Tuple[str, date]:
    """
    校验并标准化面试日期
    
    标准格式: YYYY-MM-DD，如 2026-07-09
    
    自动修正:
      - "2026/07/09" → "2026-07-09"
      - "2026.07.09" → "2026-07-09"
      - "20260709"   → "2026-07-09"
      - "2026年7月9日" → "2026-07-09"
      - "7.9"        → "2026-07-09"（补当年年份）
      - "7月9日"     → "2026-07-09"（补当年年份）
      - 日期对象     → "2026-07-09"
    
    报错情况:
      - 空值
      - 无法识别的格式
      - 无效日期（如2月30日）
    
    Returns:
        (标准化日期字符串 "YYYY-MM-DD", date对象)
    """
    if date_value is None:
        raise CandidateValidationError(f"面试日期为空（None）")
    
    date_str = str(date_value).strip()
    
    if not date_str:
        raise CandidateValidationError(f"面试日期为空字符串")
    
    parsed_date = None
    
    # 尝试中文日期格式
    cn_match = CN_DATE_PATTERN.match(date_str)
    if cn_match:
        try:
            y, m, d = int(cn_match.group(1)), int(cn_match.group(2)), int(cn_match.group(3))
            parsed_date = date(y, m, d)
        except ValueError:
            raise CandidateValidationError(
                f"面试日期无效: '{date_str}'（中文日期解析失败，请检查月份和日期是否合理）"
            )
    
    # 尝试短日期格式（无年份，补当年）
    if parsed_date is None:
        short_match = SHORT_DATE_PATTERN.match(date_str)
        if short_match:
            try:
                m, d = int(short_match.group(1)), int(short_match.group(2))
                parsed_date = date(datetime.now().year, m, d)
            except ValueError:
                raise CandidateValidationError(
                    f"面试日期无效: '{date_str}'（月份或日期不合理）"
                )
    
    if parsed_date is None:
        short_cn_match = SHORT_CN_DATE_PATTERN.match(date_str)
        if short_cn_match:
            try:
                m, d = int(short_cn_match.group(1)), int(short_cn_match.group(2))
                parsed_date = date(datetime.now().year, m, d)
            except ValueError:
                raise CandidateValidationError(
                    f"面试日期无效: '{date_str}'（月份或日期不合理）"
                )
    
    # 尝试标准格式列表
    if parsed_date is None:
        for fmt in DATE_FORMATS:
            try:
                parsed_date = datetime.strptime(date_str, fmt).date()
                break
            except ValueError:
                continue
    
    # 尝试日期对象
    if parsed_date is None and isinstance(date_value, (date, datetime)):
        parsed_date = date_value if isinstance(date_value, date) else date_value.date()
    
    if parsed_date is None:
        raise CandidateValidationError(
            f"面试日期格式无法识别: '{date_str}'\n"
            f"支持的格式: YYYY-MM-DD, YYYY/MM/DD, YYYY.MM.DD, YYYYMMDD, "
            f"YYYY年M月D日, M.D, M月D日\n"
            f"示例: 2026-07-09, 2026/7/9, 7.9, 7月9日"
        )
    
    standardized = parsed_date.strftime("%Y-%m-%d")
    return standardized, parsed_date


# ========== 时间校验 ==========

TIME_PATTERN_HHMM = re.compile(r'^(\d{1,2}):(\d{1,2})$')
TIME_PATTERN_HHMM_NO_SEP = re.compile(r'^(\d{2})(\d{2})$')

# 中文时间匹配
CN_TIME_PATTERN = re.compile(
    r'^(?:上午|下午|AM|PM|am|pm)?\s*(\d{1,2})[点时:：](\d{1,2})?[分]?$'
)


def validate_time(time_value, field_name="interview_time") -> str:
    """
    校验并标准化面试时间
    
    标准格式: HH:MM（24小时制），如 14:30
    
    自动修正:
      - "14:30"   → "14:30"（标准）
      - "14点30分" → "14:30"
      - "14时30分" → "14:30"
      - "下午2点半" → "14:30"（不太可靠，建议用24小时制）
      - "2:30 PM"  → "14:30"
      - "1430"     → "14:30"
      - "14:3"     → "14:30"（补零）
      - "9:00"     → "09:00"（补零）
    
    报错情况:
      - 空值
      - 小时>23或分钟>59
      - 无法识别的格式
    
    Returns:
        标准化时间字符串 "HH:MM"
    """
    if time_value is None:
        raise CandidateValidationError(f"面试时间为空（None）")
    
    time_str = str(time_value).strip()
    
    if not time_str:
        raise CandidateValidationError(f"面试时间为空字符串")
    
    hour, minute = None, None
    is_pm = False
    is_am = False
    
    # 检测上午/下午标记
    lower_str = time_str.lower()
    if '下午' in time_str or 'pm' in lower_str:
        is_pm = True
        time_str = re.sub(r'下午|PM|pm', '', time_str).strip()
    elif '上午' in time_str or 'am' in lower_str:
        is_am = True
        time_str = re.sub(r'上午|AM|am', '', time_str).strip()
    
    # 尝试 HH:MM 格式
    match = TIME_PATTERN_HHMM.match(time_str)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2))
    
    # 尝试 HHMM 格式（无分隔符）
    if hour is None:
        match = TIME_PATTERN_HHMM_NO_SEP.match(time_str)
        if match:
            hour = int(match.group(1))
            minute = int(match.group(2))
    
    # 尝试中文时间格式
    if hour is None:
        match = CN_TIME_PATTERN.match(time_str)
        if match:
            hour = int(match.group(1))
            minute = int(match.group(2)) if match.group(2) else 0
    
    # 尝试纯小时格式（如 "14点"）
    if hour is None:
        hour_only = re.match(r'^(\d{1,2})[点时]$', time_str)
        if hour_only:
            hour = int(hour_only.group(1))
            minute = 0
    
    if hour is None:
        raise CandidateValidationError(
            f"面试时间格式无法识别: '{time_value}'\n"
            f"支持的格式: HH:MM, HH点MM分, HH时MM分, HHMM\n"
            f"示例: 14:30, 14点30分, 1430"
        )
    
    # 上午/下午转换
    if is_pm and hour < 12:
        hour += 12
    if is_am and hour == 12:
        hour = 0
    
    # 范围校验
    if hour < 0 or hour > 23:
        raise CandidateValidationError(
            f"面试时间小时数无效: {hour}（应在0-23之间）"
        )
    if minute < 0 or minute > 59:
        raise CandidateValidationError(
            f"面试时间分钟数无效: {minute}（应在0-59之间）"
        )
    
    return f"{hour:02d}:{minute:02d}"


# ========== 邮箱校验 ==========

EMAIL_PATTERN = re.compile(
    r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
)


def validate_email(email) -> Optional[str]:
    """
    校验邮箱地址（可选字段）
    
    标准格式: user@example.com
    
    Returns:
        标准化邮箱地址，或 None（如果为空）
    
    报错情况:
      - 非空但格式不正确
    """
    if email is None or str(email).strip() == '':
        return None
    
    email_str = str(email).strip()
    
    if not EMAIL_PATTERN.match(email_str):
        raise CandidateValidationError(
            f"邮箱格式不正确: '{email_str}'（标准格式: user@example.com）"
        )
    
    return email_str


# ========== 统一校验入口 ==========

REQUIRED_FIELDS = ['name', 'phone', 'position', 'interview_date', 'interview_time']

# 预约模式额外必填字段
BOOKING_REQUIRED_FIELDS = ['name', 'phone', 'position', 'slot_a_time', 'slot_b_time', 'slot_c_time']

# 筛选模式必填字段（大模型对话，不需要预设时间段）
SCREENING_REQUIRED_FIELDS = ['name', 'phone', 'position']


def validate_candidate(candidate: Dict) -> Dict:
    """
    校验并标准化单个候选人数据
    
    标准输入格式:
      {
        "name": "张三",                    # 必填，1-30字符
        "phone": "13800138000",             # 必填，11位手机号
        "position": "产品实习生",          # 必填，1-100字符
        "interview_date": "2026-07-09",     # 必填，YYYY-MM-DD
        "interview_time": "14:30",          # 必填，HH:MM
        "email": "user@example.com"         # 可选，标准邮箱格式
      }
    
    自动修正:
      - 手机号去除分隔符和国际区号
      - 日期统一为 YYYY-MM-DD
      - 时间统一为 HH:MM（24小时制）
      - 字符串去除前后空格
    
    Returns:
        标准化后的候选人字典
    
    Raises:
        CandidateValidationError: 包含字段名和错误描述
    """
    if not isinstance(candidate, dict):
        raise CandidateValidationError(
            f"候选人数据类型错误: 期望字典，实际{type(candidate).__name__}"
        )
    
    # 检查必填字段是否存在
    missing = [f for f in REQUIRED_FIELDS if f not in candidate or candidate[f] is None]
    if missing:
        raise CandidateValidationError(
            f"缺少必填字段: {', '.join(missing)}\n"
            f"必填字段: {', '.join(REQUIRED_FIELDS)}"
        )
    
    # 逐字段校验
    validated = {}
    
    validated['name'] = validate_name(candidate['name'])
    validated['phone'] = validate_phone(candidate['phone'])
    validated['position'] = validate_position(candidate['position'])
    
    date_str, date_obj = validate_date(candidate['interview_date'])
    validated['interview_date'] = date_str
    
    validated['interview_time'] = validate_time(candidate['interview_time'])
    
    # 可选字段
    validated['email'] = validate_email(candidate.get('email'))
    
    # 保留其他字段
    for k, v in candidate.items():
        if k not in validated:
            validated[k] = v
    
    return validated


def validate_candidates(candidates) -> Tuple[list, list]:
    """
    批量校验候选人列表
    
    Args:
        candidates: 候选人列表
    
    Returns:
        (valid_candidates, errors)
        - valid_candidates: 校验通过的候选人列表（已标准化）
        - errors: 错误列表，每个元素为 {"index": int, "name": str, "error": str}
    """
    if not isinstance(candidates, list):
        return [], [{"index": -1, "name": "N/A", "error": f"候选人列表类型错误: 期望列表，实际{type(candidates).__name__}"}]
    
    if len(candidates) == 0:
        return [], []
    
    valid = []
    errors = []
    
    for idx, candidate in enumerate(candidates):
        name_preview = "未知"
        try:
            if isinstance(candidate, dict):
                name_preview = str(candidate.get('name', '未知'))[:10]
            validated = validate_candidate(candidate)
            valid.append(validated)
        except CandidateValidationError as e:
            errors.append({
                "index": idx,
                "name": name_preview,
                "error": str(e)
            })
    
    return valid, errors


# ========== 预约模式 - 时间段校验 ==========

# 时间段格式：支持 "2026-07-15 14:30"、"7月15日 14:30"、"2026-07-15 14点30分" 等
SLOT_DATETIME_PATTERN = re.compile(
    r'^(\d{4}[-/年]\d{1,2}[-/月]\d{1,2}日?|\d{1,2}月\d{1,2}日?)\s+(\d{1,2}[:点时](\d{1,2})?分?|\d{3,4})$'
)


def validate_slot(slot_value, slot_name="slot") -> str:
    """
    校验并标准化时间段格式
    
    支持的输入格式：
      "2026-07-15 14:30"           → "2026-07-15 14:30"
      "2026/07/15 14:30"           → "2026-07-15 14:30"
      "7月15日 14:30"              → "2026-07-15 14:30"（补当年）
      "2026-07-15 14点30分"        → "2026-07-15 14:30"
      "2026-07-15 1430"            → "2026-07-15 14:30"
    
    Returns:
        标准化字符串 "YYYY-MM-DD HH:MM"
    
    Raises:
        CandidateValidationError
    """
    if slot_value is None:
        raise CandidateValidationError(f"{slot_name}为空（None）")
    
    slot_str = str(slot_value).strip()
    if not slot_str:
        raise CandidateValidationError(f"{slot_name}为空字符串")
    
    # 尝试拆分日期和时间部分
    parts = slot_str.split(None, 1)  # 按空白拆分一次
    if len(parts) != 2:
        raise CandidateValidationError(
            f"{slot_name}格式不正确: '{slot_str}'\n"
            f"应为 '日期 时间' 格式，如 '2026-07-15 14:30'"
        )
    
    date_part, time_part = parts
    
    # 校验日期部分
    date_str, date_obj = validate_date(date_part, field_name=slot_name)
    
    # 校验时间部分
    time_str = validate_time(time_part, field_name=slot_name)
    
    return f"{date_str} {time_str}"


def validate_booking_candidate(candidate: Dict) -> Dict:
    """
    校验预约模式的候选人数据
    
    额外必填字段：
      slot_a_time, slot_b_time, slot_c_time
    
    校验规则：
      - 三个时间段格式正确
      - 三个时间段不能重复
      - 时间段日期不能是过去日期
    """
    if not isinstance(candidate, dict):
        raise CandidateValidationError(
            f"候选人数据类型错误: 期望字典，实际{type(candidate).__name__}"
        )
    
    # 先做基础字段校验（复用 validate_candidate）
    validated = validate_candidate(candidate)
    
    # 校验三个时间段
    missing_slots = [f for f in ['slot_a_time', 'slot_b_time', 'slot_c_time'] 
                     if f not in candidate or candidate[f] is None]
    if missing_slots:
        raise CandidateValidationError(
            f"预约模式缺少时间段字段: {', '.join(missing_slots)}\n"
            f"必填: slot_a_time, slot_b_time, slot_c_time"
        )
    
    slot_a = validate_slot(candidate['slot_a_time'], 'slot_a_time')
    slot_b = validate_slot(candidate['slot_b_time'], 'slot_b_time')
    slot_c = validate_slot(candidate['slot_c_time'], 'slot_c_time')
    
    # 检查时间段是否重复
    slots = [slot_a, slot_b, slot_c]
    for i in range(len(slots)):
        for j in range(i + 1, len(slots)):
            if slots[i] == slots[j]:
                raise CandidateValidationError(
                    f"时间段不能重复: slot_{chr(97+i)}_time 和 slot_{chr(97+j)}_time 都是 '{slots[i]}'"
                )
    
    # 检查时间段是否是过去日期 + 工作日 + 有效时间范围
    today = datetime.now().date()
    weekday_names = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
    
    # 有效时间范围：10:00-11:30 和 13:30-17:00（周一到周五）
    MORNING_START = (10, 0)   # 10:00
    MORNING_END   = (11, 30)  # 11:30
    AFTERNOON_START = (13, 30) # 13:30
    AFTERNOON_END   = (17, 0)  # 17:00
    
    for slot_name, slot_val in [('slot_a_time', slot_a), ('slot_b_time', slot_b), ('slot_c_time', slot_c)]:
        slot_date_str, slot_time_str = slot_val.split(' ')
        try:
            slot_date = datetime.strptime(slot_date_str, "%Y-%m-%d").date()
            if slot_date < today:
                raise CandidateValidationError(
                    f"{slot_name}的日期已过期: '{slot_val}'（日期不能早于今天 {today}）"
                )
            # 检查是否为工作日（周一=0 ~ 周日=6）
            weekday = slot_date.weekday()
            if weekday >= 5:
                raise CandidateValidationError(
                    f"{slot_name}不是工作日: '{slot_val}'（{weekday_names[weekday]}，"
                    f"面试时间仅限周一到周五）"
                )
            # 检查时间是否在有效范围内
            t = datetime.strptime(slot_time_str, "%H:%M")
            time_minutes = t.hour * 60 + t.minute
            morning_start = MORNING_START[0] * 60 + MORNING_START[1]
            morning_end = MORNING_END[0] * 60 + MORNING_END[1]
            afternoon_start = AFTERNOON_START[0] * 60 + AFTERNOON_START[1]
            afternoon_end = AFTERNOON_END[0] * 60 + AFTERNOON_END[1]
            
            if not (morning_start <= time_minutes <= morning_end or 
                    afternoon_start <= time_minutes <= afternoon_end):
                raise CandidateValidationError(
                    f"{slot_name}的时间不在有效范围内: '{slot_val}'\n"
                    f"有效时间段: 10:00-11:30 或 13:30-17:00（工作日）"
                )
        except ValueError:
            pass  # validate_date 已经校验过，这里只是额外检查
    
    validated['slot_a_time'] = slot_a
    validated['slot_b_time'] = slot_b
    validated['slot_c_time'] = slot_c
    
    return validated


def validate_booking_candidates(candidates) -> Tuple[list, list]:
    """
    批量校验预约模式的候选人列表
    
    Returns:
        (valid_candidates, errors)
    """
    if not isinstance(candidates, list):
        return [], [{"index": -1, "name": "N/A", "error": f"候选人列表类型错误: 期望列表，实际{type(candidates).__name__}"}]
    
    if len(candidates) == 0:
        return [], []
    
    valid = []
    errors = []
    
    for idx, candidate in enumerate(candidates):
        name_preview = "未知"
        try:
            if isinstance(candidate, dict):
                name_preview = str(candidate.get('name', '未知'))[:10]
            validated = validate_booking_candidate(candidate)
            valid.append(validated)
        except CandidateValidationError as e:
            errors.append({
                "index": idx,
                "name": name_preview,
                "error": str(e)
            })
    
    return valid, errors


def format_slot_for_tts(slot_str: str) -> str:
    """
    将时间段转换为TTS友好格式
    
    "2026-07-15 14:30" → "7月15日下午2点30分"
    
    日期部分用中文避免TTS读"减号"
    时间部分根据上午/下午自动添加
    """
    try:
        parts = slot_str.split(' ')
        if len(parts) != 2:
            return slot_str
        
        date_part, time_part = parts
        
        # 解析日期
        d = datetime.strptime(date_part, "%Y-%m-%d")
        date_cn = f"{d.month}月{d.day}日"
        
        # 获取星期
        weekdays = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
        weekday_cn = weekdays[d.weekday()]
        
        # 解析时间
        t = datetime.strptime(time_part, "%H:%M")
        hour = t.hour
        minute = t.minute
        
        # 上午/下午转换
        if hour < 12:
            period = "上午"
            display_hour = hour if hour > 0 else 12
        elif hour == 12:
            period = "中午"
            display_hour = 12
        else:
            period = "下午"
            display_hour = hour - 12
        
        if minute == 0:
            time_cn = f"{period}{display_hour}点"
        else:
            time_cn = f"{period}{display_hour}点{minute}分"
        
        return f"{date_cn}{weekday_cn}{time_cn}"
        
    except (ValueError, IndexError):
        return slot_str




def format_date_for_tts(date_str: str) -> str:
    """
    将标准日期转为中文格式供TTS播报
    避免"-"被语音引擎读成"减号"
    
    "2026-07-09" → "2026年7月9日"
    """
    try:
        d = datetime.strptime(date_str, "%Y-%m-%d")
        return f"{d.year}年{d.month}月{d.day}日"
    except ValueError:
        # 如果已经不是标准格式，直接返回原值
        return date_str


def format_time_for_tts(time_str: str) -> str:
    """
    将标准时间转为中文格式供TTS播报
    
    "14:30" → "14点30分"
    "09:00" → "9点"
    "14:00" → "14点"
    """
    try:
        t = datetime.strptime(time_str, "%H:%M")
        if t.minute == 0:
            return f"{t.hour}点"
        else:
            return f"{t.hour}点{t.minute}分"
    except ValueError:
        return time_str


# ========== 筛选模式 - 大模型对话校验 ==========

def validate_screening_candidate(candidate: Dict) -> Dict:
    """
    校验筛选模式的候选人数据
    
    必填字段：name, phone, position
    可选字段：interview_date, interview_time（不校验，兼容提醒模式数据）
    
    与提醒模式的区别：
    - 不需要 interview_date 和 interview_time
    - 不需要 slot_a/b/c_time
    - 时段由 slot_generator 动态生成，不存候选人数据中
    """
    if not isinstance(candidate, dict):
        raise CandidateValidationError(
            f"候选人数据类型错误: 期望字典，实际{type(candidate).__name__}"
        )
    
    # 检查必填字段
    missing = [f for f in SCREENING_REQUIRED_FIELDS 
               if f not in candidate or candidate[f] is None]
    if missing:
        raise CandidateValidationError(
            f"筛选模式缺少必填字段: {', '.join(missing)}\n"
            f"必填字段: {', '.join(SCREENING_REQUIRED_FIELDS)}"
        )
    
    # 逐字段校验
    validated = {}
    
    validated['name'] = validate_name(candidate['name'])
    validated['phone'] = validate_phone(candidate['phone'])
    validated['position'] = validate_position(candidate['position'])
    
    # 保留其他字段（如email等可选字段）
    for k, v in candidate.items():
        if k not in validated:
            validated[k] = v
    
    return validated


def validate_screening_candidates(candidates) -> Tuple[list, list]:
    """
    批量校验筛选模式的候选人列表
    
    Returns:
        (valid_candidates, errors)
    """
    if not isinstance(candidates, list):
        return [], [{"index": -1, "name": "N/A", "error": f"候选人列表类型错误: 期望列表，实际{type(candidates).__name__}"}]
    
    if len(candidates) == 0:
        return [], []
    
    valid = []
    errors = []
    
    for idx, candidate in enumerate(candidates):
        name_preview = "未知"
        try:
            if isinstance(candidate, dict):
                name_preview = str(candidate.get('name', '未知'))[:10]
            validated = validate_screening_candidate(candidate)
            valid.append(validated)
        except CandidateValidationError as e:
            errors.append({
                "index": idx,
                "name": name_preview,
                "error": str(e)
            })
    
    return valid, errors


# ========== 测试 ==========

if __name__ == "__main__":
    print("=" * 60)
    print("  输入校验模块测试")
    print("=" * 60)
    
    test_cases = [
        # (描述, 候选人数据, 期望通过/失败)
        ("标准格式", {
            "name": "张三", "phone": "13800138000",
            "position": "产品实习生", "interview_date": "2026-07-09",
            "interview_time": "14:30"
        }, True),
        ("手机号带分隔符", {
            "name": "张三", "phone": "138-0013-8000",
            "position": "开发工程师", "interview_date": "2026-07-09",
            "interview_time": "14:30"
        }, True),
        ("手机号带国际区号", {
            "name": "李四", "phone": "+86 13800138000",
            "position": "产品经理", "interview_date": "2026/07/09",
            "interview_time": "14:30"
        }, True),
        ("中文日期", {
            "name": "王五", "phone": "13900139000",
            "position": "设计师", "interview_date": "2026年7月9日",
            "interview_time": "14:30"
        }, True),
        ("短日期", {
            "name": "赵六", "phone": "13800138000",
            "position": "测试工程师", "interview_date": "7.9",
            "interview_time": "14:30"
        }, True),
        ("中文短日期", {
            "name": "孙七", "phone": "13800138000",
            "position": "运维工程师", "interview_date": "7月9日",
            "interview_time": "14:30"
        }, True),
        ("中文时间", {
            "name": "周八", "phone": "13800138000",
            "position": "数据分析师", "interview_date": "2026-07-09",
            "interview_time": "14点30分"
        }, True),
        ("无分隔符时间", {
            "name": "吴九", "phone": "13800138000",
            "position": "前端工程师", "interview_date": "2026-07-09",
            "interview_time": "1430"
        }, True),
        ("短时间补零", {
            "name": "郑十", "phone": "13800138000",
            "position": "后端工程师", "interview_date": "2026-07-09",
            "interview_time": "9:00"
        }, True),
        ("手机号过短", {
            "name": "错误1", "phone": "12345",
            "position": "测试", "interview_date": "2026-07-09",
            "interview_time": "14:30"
        }, False),
        ("手机号含字母", {
            "name": "错误2", "phone": "1380013800a",
            "position": "测试", "interview_date": "2026-07-09",
            "interview_time": "14:30"
        }, False),
        ("日期无效", {
            "name": "错误3", "phone": "13800138000",
            "position": "测试", "interview_date": "2026-02-30",
            "interview_time": "14:30"
        }, False),
        ("时间无效", {
            "name": "错误4", "phone": "13800138000",
            "position": "测试", "interview_date": "2026-07-09",
            "interview_time": "25:00"
        }, False),
        ("姓名含特殊字符", {
            "name": "错误${name}", "phone": "13800138000",
            "position": "测试", "interview_date": "2026-07-09",
            "interview_time": "14:30"
        }, False),
        ("缺必填字段", {
            "name": "错误5", "phone": "13800138000",
            "interview_date": "2026-07-09",
            "interview_time": "14:30"
        }, False),
        ("空值", {
            "name": "", "phone": "",
            "position": "", "interview_date": "",
            "interview_time": ""
        }, False),
    ]
    
    passed = 0
    failed = 0
    
    for desc, candidate, expect_pass in test_cases:
        try:
            validated = validate_candidate(candidate)
            if expect_pass:
                print(f"  [PASS] {desc}")
                print(f"         name={validated['name']}, phone={validated['phone']}, "
                      f"date={validated['interview_date']}, time={validated['interview_time']}")
                passed += 1
            else:
                print(f"  [FAIL] {desc} - 预期失败但通过了")
                failed += 1
        except CandidateValidationError as e:
            if not expect_pass:
                print(f"  [PASS] {desc} - 预期失败: {str(e)[:80]}")
                passed += 1
            else:
                print(f"  [FAIL] {desc} - 预期通过但失败了: {str(e)[:80]}")
                failed += 1
    
    print(f"\n{'='*60}")
    print(f"  测试结果: {passed} 通过, {failed} 失败")
    print(f"{'='*60}")
